"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/store/authStore";
import { useProjectsStore } from "@/store/projectsStore";
import { useRouterStore } from "@/store/routerStore";
import { LandingScreen } from "@/components/landing/LandingScreen";
import { LoginScreen } from "@/components/auth/LoginScreen";
import { DashboardScreen } from "@/components/dashboard/DashboardScreen";
import { NewProjectWizard } from "@/components/projects/NewProjectWizard";
import { ProjectDetailScreen } from "@/components/projects/ProjectDetailScreen";
import { ProjectSettingsScreen } from "@/components/projects/ProjectSettingsScreen";
import { WorkspaceScreen } from "@/components/workspace/WorkspaceScreen";
import { ExploreScreen } from "@/components/explore/ExploreScreen";
import { ProfileScreen } from "@/components/profile/ProfileScreen";
import { SettingsScreen } from "@/components/profile/SettingsScreen";
import { AdminScreen } from "@/components/admin/AdminScreen";
import { ToastViewport } from "@/components/shared/ToastViewport";
import { Loader2 } from "lucide-react";

export default function Home() {
  const session = useAuthStore((s) => s.session);
  const authInit = useAuthStore((s) => s.initialized);
  const initAuth = useAuthStore((s) => s.init);
  const route = useRouterStore((s) => s.route);
  const params = useRouterStore((s) => s.params);
  const navKey = useRouterStore((s) => s.navKey);
  const push = useRouterStore((s) => s.push);

  const projects = useProjectsStore((s) => s.projects);
  const loadForUser = useProjectsStore((s) => s.loadForUser);
  const refresh = useProjectsStore((s) => s.refresh);
  const [booting, setBooting] = useState(true);

  /* -------------------------------------------------------- initial boot */
  useEffect(() => {
    (async () => {
      await initAuth();
      setBooting(false);
    })();
  }, [initAuth]);

  /* -------------------------------------------------------- session-aware data loading */
  useEffect(() => {
    if (!session) return;
    if (projects.length === 0) {
      loadForUser(session.user.id);
    }
  }, [session, loadForUser, projects.length]);

  /* -------------------------------------------------------- route guards */
  useEffect(() => {
    if (booting || !authInit) return;
    const publicRoutes = ["landing", "login", "explore"];
    const isPublic = publicRoutes.includes(route);
    if (!session && !isPublic) {
      push("login");
    }
    // If user is signed in and on landing/login, send them to dashboard
    if (session && (route === "landing" || route === "login")) {
      push("dashboard");
    }
  }, [booting, authInit, session, route, push]);

  /* -------------------------------------------------------- periodic refresh for active deployments */
  useEffect(() => {
    const activeDeployment = projects.some(
      (p) =>
        p.deployment &&
        ["queued", "building", "deploying"].includes(p.deployment.status)
    );
    if (!activeDeployment) return;
    const i = setInterval(refresh, 1500);
    return () => clearInterval(i);
  }, [projects, refresh]);

  /* -------------------------------------------------------- render */
  if (booting || !authInit) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 bg-background">
        <Loader2 className="h-5 w-5 animate-spin text-brand" />
        <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Loading RPL Forge
        </p>
      </div>
    );
  }

  let content: React.ReactNode = null;
  switch (route) {
    case "landing":
      content = <LandingScreen />;
      break;
    case "login":
      content = <LoginScreen />;
      break;
    case "dashboard":
      content = session ? <DashboardScreen /> : <LoginScreen />;
      break;
    case "projects_new":
      content = session ? <NewProjectWizard /> : <LoginScreen />;
      break;
    case "project_detail":
      content = session ? (
        <ProjectDetailScreen key={`detail-${params.projectId ?? ""}-${navKey}`} />
      ) : (
        <LoginScreen />
      );
      break;
    case "project_settings":
      content = session ? (
        <ProjectSettingsScreen key={`settings-${params.projectId ?? ""}-${navKey}`} />
      ) : (
        <LoginScreen />
      );
      break;
    case "workspace":
      content = session ? (
        <WorkspaceScreen key={`workspace-${params.projectId ?? ""}-${navKey}`} />
      ) : (
        <LoginScreen />
      );
      break;
    case "explore":
      content = <ExploreScreen />;
      break;
    case "profile":
      content = <ProfileScreen key={`profile-${params.userId ?? ""}-${navKey}`} />;
      break;
    case "settings":
      content = session ? <SettingsScreen /> : <LoginScreen />;
      break;
    case "admin":
      content = session ? <AdminScreen /> : <LoginScreen />;
      break;
    default:
      content = <LandingScreen />;
  }

  return (
    <>
      {content}
      <ToastViewport />
    </>
  );
}
