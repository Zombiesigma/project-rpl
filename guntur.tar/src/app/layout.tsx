import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "RPL Forge — Build. Deploy. Showcase.",
  description:
    "RPL Forge is a digital ecosystem for students in software development. Upload your project, make it live, and keep developing it without leaving the platform.",
  keywords: [
    "RPL Forge",
    "student projects",
    "developer platform",
    "deployment",
    "Next.js",
    "showcase",
  ],
  authors: [{ name: "RPL Forge" }],
  openGraph: {
    title: "RPL Forge — Build. Deploy. Showcase.",
    description:
      "From student projects to real-world impact. Upload, host, edit, and deploy — all in one place.",
    siteName: "RPL Forge",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
        <SonnerToaster position="bottom-right" richColors />
      </body>
    </html>
  );
}
