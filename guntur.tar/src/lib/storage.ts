/**
 * Safe localStorage wrapper. Falls back to in-memory map when localStorage
 * is not available (SSR, restricted environments).
 */

const memoryStore = new Map<string, string>();

function isBrowser() {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

export const storage = {
  get<T>(key: string, fallback: T): T {
    try {
      const raw = isBrowser()
        ? window.localStorage.getItem(key)
        : memoryStore.get(key) ?? null;
      if (raw == null) return fallback;
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  },

  set<T>(key: string, value: T): void {
    try {
      const raw = JSON.stringify(value);
      if (isBrowser()) {
        window.localStorage.setItem(key, raw);
      } else {
        memoryStore.set(key, raw);
      }
    } catch {
      /* ignore quota errors */
    }
  },

  remove(key: string): void {
    if (isBrowser()) window.localStorage.removeItem(key);
    else memoryStore.delete(key);
  },

  has(key: string): boolean {
    if (isBrowser()) return window.localStorage.getItem(key) != null;
    return memoryStore.has(key);
  },
};

export const STORAGE_KEYS = {
  auth: "rplforge.auth.v1",
  users: "rplforge.users.v1",
  projects: "rplforge.projects.v1",
  activity: "rplforge.activity.v1",
  seeded: "rplforge.seeded.v1",
} as const;
