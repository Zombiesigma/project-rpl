import type { ProjectFile } from "@/types/file";

export interface TreeNode {
  file: ProjectFile;
  children: TreeNode[];
}

/**
 * Build a hierarchical tree from a flat list of project files.
 * Folders are created on the fly from intermediate path segments.
 */
export function buildFileTree(files: ProjectFile[]): TreeNode[] {
  const root: TreeNode = { file: { id: "root", projectId: "", path: "", name: "", type: "folder" }, children: [] };

  for (const file of files) {
    const segments = file.path.split("/").filter(Boolean);
    let cursor = root;
    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i];
      const isLeaf = i === segments.length - 1;
      let next = cursor.children.find((c) => c.file.name === seg);
      if (!next) {
        next = {
          file: isLeaf
            ? file
            : {
                id: `${file.projectId}:${segments.slice(0, i + 1).join("/")}`,
                projectId: file.projectId,
                path: segments.slice(0, i + 1).join("/"),
                name: seg,
                type: "folder",
              },
          children: [],
        };
        cursor.children.push(next);
      } else if (isLeaf) {
        // Replace placeholder folder with the real file if it's actually a file
        next.file = file;
      }
      cursor = next;
    }
  }

  // Sort: folders first, then files, alphabetically
  function sortRecursive(node: TreeNode) {
    node.children.sort((a, b) => {
      if (a.file.type !== b.file.type) {
        return a.file.type === "folder" ? -1 : 1;
      }
      return a.file.name.localeCompare(b.file.name);
    });
    node.children.forEach(sortRecursive);
  }
  sortRecursive(root);

  return root.children;
}

export function countFilesAndFolders(files: ProjectFile[]): {
  files: number;
  folders: number;
  totalSize: number;
} {
  let fileCount = 0;
  let folderCount = 0;
  let totalSize = 0;
  for (const f of files) {
    if (f.type === "file") {
      fileCount++;
      totalSize += f.size ?? 0;
    } else {
      folderCount++;
    }
  }
  return { files: fileCount, folders: folderCount, totalSize };
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

export function fileIcon(name: string, type: "file" | "folder"): string {
  if (type === "folder") return "folder";
  const ext = name.split(".").pop()?.toLowerCase();
  return ext ?? "file";
}
