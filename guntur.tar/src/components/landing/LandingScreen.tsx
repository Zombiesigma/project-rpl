"use client";

import { motion } from "framer-motion";
import {
  ArrowRight,
  FolderUp,
  Rocket,
  Globe2,
  Code2,
  Github,
  Database,
  Cloud,
  CheckCircle2,
  Sparkles,
} from "lucide-react";
import { useRouterStore } from "@/store/routerStore";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Logo } from "@/components/layout/Logo";

export function LandingScreen() {
  const push = useRouterStore((s) => s.push);

  return (
    <div className="relative flex min-h-screen flex-col bg-background">
      {/* Public top bar */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <Logo />
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => push("explore")}
              className="hidden sm:inline-flex"
            >
              Explore
            </Button>
            <Button size="sm" onClick={() => push("login")}>
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div aria-hidden className="absolute inset-0 grid-bg opacity-60" />
        <div className="relative mx-auto max-w-7xl px-4 pb-24 pt-16 sm:px-6 sm:pt-24 lg:px-8 lg:pt-32">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="mx-auto max-w-3xl text-center"
          >
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-3 py-1 text-xs font-medium text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-brand" />
              <span>Prototype · For student developers</span>
            </div>
            <h1 className="text-balance text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
              Build. Deploy. <span className="text-brand">Showcase.</span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-balance text-base text-muted-foreground sm:text-lg">
              RPL Forge turns your student projects into real, live experiences.
              Upload your folder, get a live URL, and keep developing — without
              ever touching Git, Vercel, or cloud infrastructure.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button
                size="lg"
                onClick={() => push("login")}
                className="w-full sm:w-auto"
              >
                Start Building
                <ArrowRight className="ml-1.5 h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => push("explore")}
                className="w-full sm:w-auto"
              >
                Explore Projects
              </Button>
            </div>
            <p className="mt-4 text-xs text-muted-foreground">
              Create your project. Upload it. Make it live. Keep developing it.
            </p>
          </motion.div>

          {/* Visual flow */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="mx-auto mt-16 grid max-w-4xl grid-cols-1 gap-3 sm:grid-cols-3 sm:gap-4"
          >
            <FlowCard
              icon={FolderUp}
              label="Project Folder"
              hint="Your local code"
            />
            <FlowArrow />
            <FlowCard
              icon={Cloud}
              label="RPL Forge"
              hint="We handle the rest"
              highlighted
            />
            <FlowArrow className="hidden sm:block" />
            <FlowCard
              icon={Globe2}
              label="Live Website"
              hint="Online in seconds"
              className="hidden sm:block"
            />
          </motion.div>

          <div className="mx-auto mt-12 max-w-4xl">
            <Card className="overflow-hidden border-border bg-card">
              <div className="flex items-center gap-1.5 border-b border-border bg-muted/40 px-4 py-2.5">
                <span className="h-2.5 w-2.5 rounded-full bg-rose-400" />
                <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                <span className="ml-3 font-mono text-xs text-muted-foreground">
                  smart-attendance · live · v1.0
                </span>
              </div>
              <div className="grid grid-cols-12">
                <pre className="col-span-12 overflow-x-auto bg-[#0d1117] p-4 text-xs text-slate-200 sm:col-span-6">
{`// src/app/page.tsx
import { Navbar } from "@/components/Navbar";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <h1>Smart Attendance</h1>
      <p>Powered by ESP32 + face recognition.</p>
    </main>
  );
}`}
                </pre>
                <div className="col-span-12 flex flex-col justify-between gap-3 p-4 sm:col-span-6">
                  <div>
                    <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                      Deployment
                    </p>
                    <p className="mt-1 text-sm font-semibold text-emerald-600 dark:text-emerald-400">
                      ● Live
                    </p>
                    <p className="mt-1 font-mono text-xs text-muted-foreground">
                      https://smart-attendance.rplforge.local
                    </p>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <DeployStep label="Build" status="done" />
                    <DeployStep label="Publish" status="done" />
                    <DeployStep label="Live" status="done" />
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="border-t border-border bg-secondary/30 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
              From folder to live in seconds
            </h2>
            <p className="mt-3 text-muted-foreground">
              No Git, no GitHub Apps, no Vercel dashboards. The complexity is
              hidden behind a clean, focused student experience.
            </p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            <Step
              num="01"
              title="Upload your project"
              description="Pick a local folder. RPL Forge preserves your structure, validates files, and prepares everything for hosting."
              icon={FolderUp}
            />
            <Step
              num="02"
              title="We create the repository"
              description="A managed repository is created automatically. You can browse files, edit code, and commit changes — all inside the workspace."
              icon={Github}
            />
            <Step
              num="03"
              title="It goes live"
              description="A mock deployment runs a realistic build pipeline. When it finishes, your project is online at a deterministic URL."
              icon={Rocket}
            />
          </div>
        </div>
      </section>

      {/* Showcase */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
                Featured student projects
              </h2>
              <p className="mt-2 text-muted-foreground">
                Realistic samples built with the same flow you'll use.
              </p>
            </div>
            <Button variant="ghost" onClick={() => push("explore")}>
              View all
              <ArrowRight className="ml-1.5 h-4 w-4" />
            </Button>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {SHOWCASE.map((s) => (
              <Card
                key={s.name}
                className="cursor-pointer overflow-hidden border-border transition-shadow hover:shadow-md"
                onClick={() => push("explore")}
              >
                <div className="aspect-[16/9] bg-gradient-to-br from-secondary to-muted" />
                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">{s.name}</h3>
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
                      Live
                    </span>
                  </div>
                  <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">
                    {s.description}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-1">
                    {s.tech.map((t) => (
                      <span
                        key={t}
                        className="rounded-md bg-secondary px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Architecture callout */}
      <section className="border-t border-border bg-foreground py-16 text-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-10 md:grid-cols-2">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-background/60">
                Production-ready architecture
              </p>
              <h2 className="mt-2 text-3xl font-bold tracking-tight">
                Built to grow into real infrastructure
              </h2>
              <p className="mt-4 text-background/70">
                The prototype uses clean service adapters so mock systems can be
                swapped for real Firebase, GitHub, and Vercel integrations —
                without touching the student UX.
              </p>
              <div className="mt-6 flex flex-wrap gap-2">
                {[
                  "Firebase Auth",
                  "Firestore",
                  "GitHub App",
                  "Vercel API",
                  "Monaco Editor",
                  "Next.js 16",
                ].map((t) => (
                  <span
                    key={t}
                    className="rounded-md border border-background/20 px-2 py-1 font-mono text-xs text-background/80"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
            <div className="grid gap-3">
              <ArchRow icon={Database} title="Mock Auth → Firebase Auth" />
              <ArchRow icon={Database} title="Mock DB → Firestore" />
              <ArchRow icon={Github} title="Mock Repo → GitHub App" />
              <ArchRow icon={Cloud} title="Mock Deploy → Vercel API" />
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            Ready to forge your project?
          </h2>
          <p className="mt-3 text-muted-foreground">
            Sign in with a demo account and ship your first project in under a
            minute.
          </p>
          <div className="mt-6 flex justify-center">
            <Button size="lg" onClick={() => push("login")}>
              Get Started
              <ArrowRight className="ml-1.5 h-4 w-4" />
            </Button>
          </div>
        </div>
      </section>

      <footer className="mt-auto border-t border-border bg-background">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-4 px-4 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Logo />
            <span className="hidden sm:inline">·</span>
            <span className="hidden sm:inline text-xs">Prototype</span>
          </div>
          <p className="text-xs">From student projects to real-world impact.</p>
        </div>
      </footer>
    </div>
  );
}

/* ---------------------------------- pieces --------------------------------- */

function FlowCard({
  icon: Icon,
  label,
  hint,
  highlighted = false,
  className,
}: {
  icon: typeof FolderUp;
  label: string;
  hint: string;
  highlighted?: boolean;
  className?: string;
}) {
  return (
    <Card
      className={
        "flex flex-col items-center justify-center gap-2 p-6 text-center transition-shadow " +
        (highlighted ? "border-brand/40 shadow-md" : "") +
        (className ?? "")
      }
    >
      <div
        className={
          "flex h-10 w-10 items-center justify-center rounded-lg " +
          (highlighted ? "bg-brand text-brand-foreground" : "bg-secondary")
        }
      >
        <Icon className="h-5 w-5" />
      </div>
      <p className="font-semibold">{label}</p>
      <p className="text-xs text-muted-foreground">{hint}</p>
    </Card>
  );
}

function FlowArrow({ className }: { className?: string }) {
  return (
    <div
      className={
        "flex items-center justify-center text-muted-foreground " + (className ?? "")
      }
      aria-hidden
    >
      <ArrowRight className="hidden h-5 w-5 sm:block" />
      <ArrowRight className="h-5 w-5 rotate-90 sm:hidden" />
    </div>
  );
}

function DeployStep({
  label,
  status,
}: {
  label: string;
  status: "done" | "pending" | "active";
}) {
  return (
    <div className="rounded-md border border-border bg-background px-2 py-1.5 text-center">
      <div className="flex items-center justify-center gap-1">
        {status === "done" ? (
          <CheckCircle2 className="h-3 w-3 text-emerald-500" />
        ) : (
          <span className="h-2 w-2 rounded-full bg-muted-foreground/40" />
        )}
        <span className="text-[10px] font-medium">{label}</span>
      </div>
    </div>
  );
}

function Step({
  num,
  title,
  description,
  icon: Icon,
}: {
  num: string;
  title: string;
  description: string;
  icon: typeof FolderUp;
}) {
  return (
    <div className="relative rounded-xl border border-border bg-card p-6">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
          <Icon className="h-5 w-5" />
        </div>
        <span className="font-mono text-xs text-muted-foreground">{num}</span>
      </div>
      <h3 className="mt-4 text-lg font-semibold">{title}</h3>
      <p className="mt-1.5 text-sm text-muted-foreground">{description}</p>
    </div>
  );
}

function ArchRow({
  icon: Icon,
  title,
}: {
  icon: typeof Database;
  title: string;
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-background/15 bg-background/5 px-4 py-3">
      <Icon className="h-4 w-4 text-background/70" />
      <span className="font-mono text-sm text-background/90">{title}</span>
    </div>
  );
}

const SHOWCASE = [
  {
    name: "Smart Attendance",
    description: "ESP32 + face recognition attendance platform.",
    tech: ["Next.js", "Firebase", "ESP32"],
  },
  {
    name: "School Library System",
    description: "Modern library management for schools.",
    tech: ["Next.js", "Firebase"],
  },
  {
    name: "AI Study Assistant",
    description: "AI-powered chatbot for course material.",
    tech: ["Next.js", "Python", "FastAPI"],
  },
  {
    name: "IoT Temperature Monitor",
    description: "Distributed sensors with real-time dashboard.",
    tech: ["Next.js", "ESP32", "Python"],
  },
  {
    name: "Student Portfolio",
    description: "A fast, minimalist portfolio site.",
    tech: ["Next.js", "Tailwind"],
  },
  {
    name: "School Event Platform",
    description: "Discover and RSVP to school events.",
    tech: ["Next.js", "Firebase"],
  },
];
