"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Search, SlidersHorizontal, FolderGit2 } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { useRouterStore } from "@/store/routerStore";
import { useProjectsStore } from "@/store/projectsStore";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ProjectCard } from "@/components/projects/ProjectCard";
import { EmptyState } from "@/components/shared/EmptyState";
import { PROJECT_CATEGORIES } from "@/types/project";

export function ExploreScreen() {
  const push = useRouterStore((s) => s.push);
  const loadPublic = useProjectsStore((s) => s.loadPublic);
  const projects = useProjectsStore((s) => s.projects);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [tech, setTech] = useState<string>("all");

  useEffect(() => {
    loadPublic();
  }, [loadPublic]);

  const allTechs = useMemo(() => {
    const set = new Set<string>();
    projects.forEach((p) => p.technologies.forEach((t) => set.add(t)));
    return Array.from(set).sort();
  }, [projects]);

  const filtered = useMemo(() => {
    return projects.filter((p) => {
      if (category !== "all" && p.category !== category) return false;
      if (tech !== "all" && !p.technologies.includes(tech)) return false;
      if (query) {
        const q = query.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.technologies.some((t) => t.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [projects, query, category, tech]);

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
            Explore projects
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Browse what other RPL Forge students are building.
          </p>
        </motion.div>

        {/* Filters */}
        <Card className="mt-6 p-3 sm:p-4">
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search projects..."
                className="pl-9"
              />
            </div>
            <div className="flex gap-2">
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger className="w-[180px]">
                  <SlidersHorizontal className="mr-1 h-3.5 w-3.5 text-muted-foreground" />
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  {PROJECT_CATEGORIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={tech} onValueChange={setTech}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Tech" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All tech</SelectItem>
                  {allTechs.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Results count */}
        <div className="mt-4 flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            {filtered.length} project{filtered.length === 1 ? "" : "s"}
          </p>
          {(query || category !== "all" || tech !== "all") && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setQuery("");
                setCategory("all");
                setTech("all");
              }}
            >
              Clear filters
            </Button>
          )}
        </div>

        {/* Grid */}
        {filtered.length === 0 ? (
          <EmptyState
            className="mt-6"
            icon={FolderGit2}
            title="No projects found"
            description="Try a different search term or clear the filters."
          />
        ) : (
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((p) => (
              <ProjectCard
                key={p.id}
                project={p}
                onClick={() => push("project_detail", { projectId: p.id })}
              />
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
