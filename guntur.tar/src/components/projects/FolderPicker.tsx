"use client";

import { useCallback, useRef, useState } from "react";
import { FolderUp, FileText, Folder, Info, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { detectLanguage } from "@/types/file";
import type { ProjectFile } from "@/types/file";
import {
  buildSmartAttendanceFiles,
} from "@/mock/seed";

interface PickedFile {
  path: string;
  name: string;
  content: string;
  size: number;
  isFolder: boolean;
}

export interface PickedProject {
  folderName: string;
  files: PickedFile[];
  totalSize: number;
  fileCount: number;
  folderCount: number;
}

interface FolderPickerProps {
  onPick: (project: PickedProject) => void;
  onDemoPick?: (project: PickedProject) => void;
}

const MAX_FILE_SIZE = 1024 * 1024; // 1MB per file
const IGNORED_DIRS = new Set([
  "node_modules",
  ".git",
  ".next",
  "dist",
  "build",
  ".cache",
  ".turbo",
  ".vercel",
  "coverage",
  ".idea",
  ".vscode",
]);

const IGNORED_FILE_EXT = new Set(["exe", "dll", "so", "dylib", "bin", "png", "jpg", "jpeg", "gif", "webp", "ico", "mp4", "mp3", "pdf", "zip", "tar", "gz", "rar"]);

export function FolderPicker({ onPick, onDemoPick }: FolderPickerProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [picking, setPicking] = useState(false);
  const [showDemoPicker, setShowDemoPicker] = useState(false);

  const handleFiles = useCallback(
    (files: FileList | null) => {
      if (!files || files.length === 0) {
        setError("No files selected. Please pick a project folder.");
        return;
      }
      setError(null);
      setPicking(true);

      // Build a list of text-readable files (skip ignored dirs and binary by ext)
      const fileArray = Array.from(files);
      const accepted: PickedFile[] = [];
      let folderName = "my-project";
      let totalSize = 0;
      let folderCount = 0;
      const folderPaths = new Set<string>();

      // Determine folder name from the first path
      const firstPath = fileArray[0]?.webkitRelativePath || fileArray[0]?.name;
      if (firstPath && firstPath.includes("/")) {
        folderName = firstPath.split("/")[0];
      }

      const filePromises: Promise<PickedFile | null>[] = [];

      for (const file of fileArray) {
        const relPath = file.webkitRelativePath || file.name;
        const segments = relPath.split("/").filter(Boolean);

        // Skip if any segment is in IGNORED_DIRS
        if (segments.some((s, i) => i < segments.length - 1 && IGNORED_DIRS.has(s))) {
          continue;
        }

        // Collect folder paths for counting
        for (let i = 1; i < segments.length; i++) {
          folderPaths.add(segments.slice(0, i).join("/"));
        }

        const ext = segments[segments.length - 1].split(".").pop()?.toLowerCase();
        if (ext && IGNORED_FILE_EXT.has(ext)) continue;

        if (file.size > MAX_FILE_SIZE) continue;

        filePromises.push(
          file.text().then((content) => ({
            path: segments.slice(1).join("/"), // strip top-level folder name
            name: segments[segments.length - 1],
            content,
            size: file.size,
            isFolder: false,
          })).catch(() => null)
        );
      }

      Promise.all(filePromises).then((results) => {
        for (const r of results) {
          if (!r) continue;
          accepted.push(r);
          totalSize += r.size;
        }
        folderCount = folderPaths.size;

        if (accepted.length === 0) {
          setError(
            "No readable text files found in this folder. Try a project with .ts, .tsx, .js, .json, or .md files."
          );
          setPicking(false);
          return;
        }

        onPick({
          folderName,
          files: accepted,
          totalSize,
          fileCount: accepted.length,
          folderCount,
        });
        setPicking(false);
      });
    },
    [onPick]
  );

  const handleDemoSelect = (project: PickedProject) => {
    setShowDemoPicker(false);
    onDemoPick?.(project);
  };

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        // @ts-expect-error – non-standard but widely supported
        webkitdirectory=""
        directory=""
        multiple
        className="hidden"
        onChange={(e) => handleFiles(e.target.files)}
      />

      <Card
        className={cn(
          "border-2 border-dashed border-border p-8 text-center transition-colors",
          picking && "border-brand/40 bg-brand/5",
          error && "border-rose-500/40"
        )}
      >
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-secondary">
          <FolderUp className="h-6 w-6 text-muted-foreground" />
        </div>
        <h3 className="mt-4 text-base font-semibold">
          {picking ? "Reading your project..." : "Choose your project folder"}
        </h3>
        <p className="mx-auto mt-1 max-w-sm text-sm text-muted-foreground">
          We'll preserve your file structure and read source files. Node modules,
          .git, and binary assets are automatically skipped.
        </p>
        <div className="mt-5 flex flex-col items-center justify-center gap-2 sm:flex-row">
          <Button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={picking}
          >
            <FolderUp className="mr-1.5 h-4 w-4" />
            Choose Project Folder
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => setShowDemoPicker((v) => !v)}
            disabled={picking}
          >
            Or pick a demo project
          </Button>
        </div>
        {error && (
          <p className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-rose-500/10 px-2.5 py-1 text-xs text-rose-600 dark:text-rose-400">
            <AlertTriangle className="h-3.5 w-3.5" />
            {error}
          </p>
        )}
      </Card>

      {showDemoPicker && (
        <Card className="mt-4 p-4">
          <p className="mb-3 flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest text-muted-foreground">
            <Info className="h-3 w-3" />
            Demo projects
          </p>
          <div className="grid gap-2 sm:grid-cols-2">
            {DEMO_PROJECTS.map((p) => (
              <button
                key={p.folderName}
                onClick={() => handleDemoSelect(buildPickedProject(p))}
                className="flex items-start gap-3 rounded-lg border border-border bg-card p-3 text-left transition-colors hover:border-brand/40 hover:bg-secondary/60"
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-md bg-secondary">
                  {p.folderName.includes("attendance") ? (
                    <Folder className="h-4 w-4" />
                  ) : (
                    <FileText className="h-4 w-4" />
                  )}
                </span>
                <div className="flex-1">
                  <p className="text-sm font-semibold">{p.label}</p>
                  <p className="text-xs text-muted-foreground">{p.description}</p>
                  <p className="mt-1 font-mono text-[10px] text-muted-foreground">
                    {p.folderName}/
                  </p>
                </div>
              </button>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

/* Demo project definitions ---------------------------------------------- */

interface DemoDef {
  folderName: string;
  label: string;
  description: string;
  builder: (projectId: string) => ProjectFile[];
}

const DEMO_PROJECTS: DemoDef[] = [
  {
    folderName: "smart-attendance",
    label: "Smart Attendance",
    description: "ESP32 + face recognition attendance platform.",
    builder: buildSmartAttendanceFiles,
  },
];

function buildPickedProject(def: DemoDef): PickedProject {
  const tempId = "demo";
  const files = def.builder(tempId);
  const picked: PickedFile[] = files
    .filter((f) => f.type === "file" && f.content !== undefined)
    .map((f) => ({
      path: f.path,
      name: f.name,
      content: f.content ?? "",
      size: f.size ?? f.content?.length ?? 0,
      isFolder: false,
    }));
  const folderCount = new Set(
    picked.map((f) => f.path.split("/").slice(0, -1).join("/")).filter(Boolean)
  ).size;
  const totalSize = picked.reduce((sum, f) => sum + f.size, 0);
  return {
    folderName: def.folderName,
    files: picked,
    totalSize,
    fileCount: picked.length,
    folderCount,
  };
}
