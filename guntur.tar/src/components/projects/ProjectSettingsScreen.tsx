"use client";

import { useMemo, useState } from "react";
import { useRouterStore } from "@/store/routerStore";
import { useProjectsStore } from "@/store/projectsStore";
import { useAuthStore } from "@/store/authStore";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { ArrowLeft, Trash2, Archive } from "lucide-react";
import { PROJECT_CATEGORIES } from "@/types/project";
import { toast } from "@/store/uiStore";
import { EmptyState } from "@/components/shared/EmptyState";
import { CoverUploader } from "@/components/shared/CoverUploader";

export function ProjectSettingsScreen() {
  const params = useRouterStore((s) => s.params);
  const push = useRouterStore((s) => s.push);
  const back = useRouterStore((s) => s.back);
  const projects = useProjectsStore((s) => s.projects);
  const updateProject = useProjectsStore((s) => s.updateProject);
  const deleteProject = useProjectsStore((s) => s.deleteProject);
  const session = useAuthStore((s) => s.session);

  const project = useMemo(
    () => projects.find((p) => p.id === params.projectId),
    [projects, params.projectId]
  );

  // Use a key-based reset instead of setState-in-effect: when project.id changes,
  // the parent remounts this component (via `key`), so initial state is fresh.
  const [name, setName] = useState(project?.name ?? "");
  const [description, setDescription] = useState(project?.description ?? "");
  const [category, setCategory] = useState(project?.category ?? "");
  const [visibility, setVisibility] = useState<"public" | "private">(
    project?.visibility ?? "public"
  );
  const [coverImage, setCoverImage] = useState<string | undefined>(
    project?.coverImage
  );

  if (!project) {
    return (
      <AppShell>
        <div className="mx-auto max-w-3xl px-4 py-16">
          <EmptyState
            title="Project not found"
            description="This project doesn't exist."
            action={<Button onClick={() => push("dashboard")}>Back</Button>}
          />
        </div>
      </AppShell>
    );
  }

  if (session?.user.id !== project.ownerId) {
    return (
      <AppShell>
        <div className="mx-auto max-w-3xl px-4 py-16">
          <EmptyState
            title="Not authorized"
            description="Only the project owner can change settings."
            action={<Button onClick={back}>Back</Button>}
          />
        </div>
      </AppShell>
    );
  }

  const handleSave = async () => {
    await updateProject(project.id, {
      name,
      description,
      category,
      visibility,
      coverImage,
    });
    toast.success("Settings saved");
  };

  const handleDelete = async () => {
    await deleteProject(project.id);
    toast.success("Project deleted");
    push("dashboard");
  };

  const handleArchive = async () => {
    await updateProject(project.id, { status: "archived" });
    toast.success("Project archived");
    push("dashboard");
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6 lg:px-8">
        <button
          onClick={back}
          className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to project
        </button>

        <h1 className="text-2xl font-bold tracking-tight">Project settings</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Manage {project.name}.
        </p>

        <Card className="mt-6 p-6">
          <h2 className="text-sm font-semibold">General</h2>
          <div className="mt-4 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="name">Name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cover">Cover photo</Label>
              <p className="text-xs text-muted-foreground">
                Shown in the Explore grid and on the project page. If removed, a live preview is generated automatically.
              </p>
              <CoverUploader
                value={coverImage}
                onChange={setCoverImage}
                projectName={name || undefined}
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Visibility</Label>
                <div className="flex gap-2">
                  {(["public", "private"] as const).map((v) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => setVisibility(v)}
                      className={
                        "flex-1 rounded-md border px-3 py-2 text-sm font-medium capitalize transition-colors " +
                        (visibility === v
                          ? "border-foreground bg-foreground text-background"
                          : "border-border bg-background hover:bg-secondary")
                      }
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Category</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PROJECT_CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <div className="mt-6 flex justify-end">
            <Button onClick={handleSave}>Save changes</Button>
          </div>
        </Card>

        <Card className="mt-4 border-rose-500/30 p-6">
          <h2 className="text-sm font-semibold text-rose-600 dark:text-rose-400">
            Danger zone
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">
            These actions are permanent. Be careful.
          </p>
          <div className="mt-4 flex flex-col gap-3 sm:flex-row">
            <Button variant="outline" onClick={handleArchive}>
              <Archive className="mr-1.5 h-4 w-4" />
              Archive project
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">
                  <Trash2 className="mr-1.5 h-4 w-4" />
                  Delete project
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete {project.name}?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently remove the project, its repository,
                    files, and deployment history. This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={handleDelete}
                    className="bg-rose-600 hover:bg-rose-700"
                  >
                    Delete forever
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </Card>
      </div>
    </AppShell>
  );
}
