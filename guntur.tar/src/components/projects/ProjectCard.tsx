"use client";

import { motion } from "framer-motion";
import { Globe2, MoreVertical, Code2, Settings as SettingsIcon, ImageIcon } from "lucide-react";
import type { Project } from "@/types/project";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { LivePreview } from "@/components/shared/LivePreview";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useRouterStore } from "@/store/routerStore";
import { Button } from "@/components/ui/button";

interface ProjectCardProps {
  project: Project;
  onClick?: () => void;
  className?: string;
}

export function ProjectCard({ project, onClick, className }: ProjectCardProps) {
  const push = useRouterStore((s) => s.push);
  const hasCover = !!project.coverImage;
  const isLive = project.deployment?.status === "ready" || project.status === "live";

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.25 }}
      className={className}
    >
      <Card
        onClick={onClick}
        className={cn(
          "group cursor-pointer overflow-hidden border-border transition-all hover:shadow-md",
          onClick && "hover:border-brand/40"
        )}
      >
        {/* Thumbnail: cover image OR live preview iframe */}
        <div className="relative aspect-[16/9] overflow-hidden bg-secondary">
          {hasCover ? (
            <img
              src={project.coverImage}
              alt={`Cover for ${project.name}`}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            <div className="pointer-events-none absolute inset-0 scale-[0.78] origin-top-left">
              <LivePreview
                project={project}
                showChrome={false}
                height="100%"
                className="rounded-none border-0"
              />
            </div>
          )}

          {/* Subtle overlay so the status badge always reads */}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/0 via-black/0 to-black/20" />

          <div className="absolute left-3 top-3">
            <StatusBadge status={project.status} kind="project" />
          </div>
          <div className="absolute right-2 top-2">
            <DropdownMenu>
              <DropdownMenuTrigger
                asChild
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  className="flex h-7 w-7 items-center justify-center rounded-md bg-background/80 text-muted-foreground backdrop-blur hover:bg-background hover:text-foreground"
                  aria-label="Project actions"
                >
                  <MoreVertical className="h-4 w-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                onClick={(e) => e.stopPropagation()}
              >
                <DropdownMenuItem
                  onClick={() => push("project_detail", { projectId: project.id })}
                >
                  View project
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => push("workspace", { projectId: project.id })}
                >
                  <Code2 className="mr-2 h-4 w-4" /> Open workspace
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() =>
                    push("project_settings", { projectId: project.id })
                  }
                >
                  <SettingsIcon className="mr-2 h-4 w-4" /> Settings
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Cover/preview badge */}
          <div className="absolute bottom-2 right-2">
            <span className="inline-flex items-center gap-1 rounded-md bg-background/80 px-1.5 py-0.5 font-mono text-[9px] text-muted-foreground backdrop-blur">
              {hasCover ? (
                <>
                  <ImageIcon className="h-2.5 w-2.5" />
                  COVER
                </>
              ) : (
                <>
                  <Globe2 className="h-2.5 w-2.5" />
                  PREVIEW
                </>
              )}
            </span>
          </div>
        </div>

        {/* Body */}
        <div className="p-4">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0 flex-1">
              <h3 className="truncate font-semibold">{project.name}</h3>
              <p className="text-xs text-muted-foreground">
                by @{ownerUsername(project)}
              </p>
            </div>
            {isLive && (
              <Button
                size="sm"
                variant="ghost"
                className="h-7 px-2 text-xs"
                onClick={(e) => {
                  e.stopPropagation();
                  push("project_detail", { projectId: project.id });
                }}
              >
                <Globe2 className="mr-1 h-3 w-3" />
                View
              </Button>
            )}
          </div>
          <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
            {project.description}
          </p>
          <div className="mt-3 flex flex-wrap gap-1">
            {project.technologies.slice(0, 3).map((t) => (
              <span
                key={t}
                className="rounded-md bg-secondary px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground"
              >
                {t}
              </span>
            ))}
            {project.technologies.length > 3 && (
              <span className="rounded-md bg-secondary px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                +{project.technologies.length - 3}
              </span>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}

function ownerUsername(project: Project): string {
  const map: Record<string, string> = {
    user_andi: "andi",
    user_budi: "budi",
    user_citra: "citra",
    user_deni: "deni",
  };
  return map[project.ownerId] ?? "unknown";
}
