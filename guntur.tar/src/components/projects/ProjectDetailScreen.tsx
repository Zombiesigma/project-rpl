"use client";

import { useMemo, useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Code2,
  Globe2,
  Settings as SettingsIcon,
  GitBranch,
  History,
  Users,
  Calendar,
  Share2,
  QrCode as QrIcon,
  Copy,
  Check,
  ExternalLink,
} from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { useRouterStore } from "@/store/routerStore";
import { useProjectsStore } from "@/store/projectsStore";
import { useAuthStore } from "@/store/authStore";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { EmptyState } from "@/components/shared/EmptyState";
import { LivePreview } from "@/components/shared/LivePreview";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "@/store/uiStore";

export function ProjectDetailScreen() {
  const params = useRouterStore((s) => s.params);
  const push = useRouterStore((s) => s.push);
  const back = useRouterStore((s) => s.back);
  const projects = useProjectsStore((s) => s.projects);
  const refresh = useProjectsStore((s) => s.refresh);
  const session = useAuthStore((s) => s.session);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    // Periodically refresh so deployment status updates flow in
    const i = setInterval(refresh, 1500);
    return () => clearInterval(i);
  }, [refresh]);

  const project = useMemo(
    () => projects.find((p) => p.id === params.projectId),
    [projects, params.projectId]
  );

  if (!project) {
    return (
      <AppShell>
        <div className="mx-auto max-w-4xl px-4 py-16">
          <EmptyState
            icon={Code2}
            title="Project not found"
            description="This project doesn't exist or has been deleted."
            action={
              <Button onClick={() => push("dashboard")}>Back to dashboard</Button>
            }
          />
        </div>
      </AppShell>
    );
  }

  const isOwner = session?.user.id === project.ownerId;

  const copyUrl = () => {
    navigator.clipboard?.writeText(project.deployment?.url ?? "");
    setCopied(true);
    toast.success("URL copied to clipboard");
    setTimeout(() => setCopied(false), 1500);
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6 lg:px-8">
        <button
          onClick={back}
          className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </button>

        {/* Header card */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="overflow-hidden">
            {/* Hero: cover image OR live preview */}
            <div className="relative aspect-[16/9] w-full overflow-hidden bg-secondary sm:aspect-[21/9]">
              {project.coverImage ? (
                <img
                  src={project.coverImage}
                  alt={`Cover for ${project.name}`}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="absolute inset-0">
                  <LivePreview
                    project={project}
                    showChrome={true}
                    height="100%"
                    className="h-full rounded-none border-0"
                  />
                </div>
              )}
              {/* Gradient overlay so the title reads on any background */}
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
              <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-background to-transparent" />
            </div>
            <div className="p-5 sm:p-6">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h1 className="text-2xl font-bold tracking-tight">
                      {project.name}
                    </h1>
                    <StatusBadge status={project.status} kind="project" />
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">
                    by @{ownerUsername(project)} · {project.category}
                  </p>
                  <p className="mt-3 max-w-2xl text-sm">
                    {project.description}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-1">
                    {project.technologies.map((t) => (
                      <span
                        key={t}
                        className="rounded-md bg-secondary px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex shrink-0 flex-col gap-2 sm:items-end">
                  {project.deployment?.status === "ready" && (
                    <Button onClick={() => window.open(project.deployment!.url, "_blank")}>
                      <Globe2 className="mr-1.5 h-4 w-4" />
                      Open Website
                    </Button>
                  )}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => push("workspace", { projectId: project.id })}
                    >
                      <Code2 className="mr-1.5 h-4 w-4" />
                      Workspace
                    </Button>
                    {isOwner && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => push("project_settings", { projectId: project.id })}
                      >
                        <SettingsIcon className="mr-1.5 h-4 w-4" />
                        Settings
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* URL bar */}
        {project.deployment && (
          <Card className="mt-4 p-4">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">
                  Live URL
                </p>
                <p className="mt-0.5 truncate font-mono text-sm">
                  {project.deployment.url}
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={copyUrl}>
                  {copied ? (
                    <Check className="mr-1 h-3.5 w-3.5 text-emerald-500" />
                  ) : (
                    <Copy className="mr-1 h-3.5 w-3.5" />
                  )}
                  Copy
                </Button>
                <QRDialog url={project.deployment.url} projectName={project.name} />
              </div>
            </div>
          </Card>
        )}

        {/* Tabs */}
        <Tabs defaultValue="overview" className="mt-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="preview">
              <Globe2 className="mr-1 h-3.5 w-3.5" />
              Live Preview
            </TabsTrigger>
            <TabsTrigger value="versions">
              <History className="mr-1 h-3.5 w-3.5" />
              Versions
            </TabsTrigger>
            <TabsTrigger value="commits">
              <GitBranch className="mr-1 h-3.5 w-3.5" />
              Commits
            </TabsTrigger>
            <TabsTrigger value="members">
              <Users className="mr-1 h-3.5 w-3.5" />
              Members
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card className="p-5">
                <h3 className="text-sm font-semibold">Project information</h3>
                <dl className="mt-3 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Repository</dt>
                    <dd className="font-mono text-xs">
                      {project.repository?.name ?? "—"}
                    </dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Default branch</dt>
                    <dd className="font-mono text-xs">
                      {project.repository?.defaultBranch ?? "main"}
                    </dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Deployment</dt>
                    <dd>
                      {project.deployment ? (
                        <StatusBadge
                          status={project.deployment.status}
                          kind="deployment"
                        />
                      ) : (
                        "—"
                      )}
                    </dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Version</dt>
                    <dd className="font-mono text-xs">
                      {project.versions[0]?.tag ?? "v1.0.0"}
                    </dd>
                  </div>
                  <div className="flex justify-between">
                    <dt className="text-muted-foreground">Created</dt>
                    <dd className="flex items-center gap-1 text-xs">
                      <Calendar className="h-3 w-3" />
                      {new Date(project.createdAt).toLocaleDateString()}
                    </dd>
                  </div>
                </dl>
              </Card>
              <Card className="p-5">
                <h3 className="text-sm font-semibold">README</h3>
                <div className="mt-3 max-h-64 overflow-y-auto scrollbar-thin rounded-md border border-border bg-[#0d1117] p-3 font-mono text-xs text-slate-200">
                  {readReadme(project) ?? "No README.md found."}
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="preview" className="mt-4">
            <Card className="overflow-hidden">
              <div className="flex items-center justify-between border-b border-border px-5 py-3">
                <div>
                  <h3 className="text-sm font-semibold">Live preview</h3>
                  <p className="text-xs text-muted-foreground">
                    Auto-generated from project metadata. {project.coverImage && "Cover photo overrides this in the hero above."}
                  </p>
                </div>
                {project.deployment?.status === "ready" && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(project.deployment!.url, "_blank")}
                  >
                    <ExternalLink className="mr-1 h-3.5 w-3.5" />
                    Open live URL
                  </Button>
                )}
              </div>
              <div className="p-4">
                <LivePreview
                  project={project}
                  showChrome={true}
                  height={420}
                  className="w-full"
                />
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="versions" className="mt-4">
            <Card>
              <div className="border-b border-border px-5 py-3">
                <h3 className="text-sm font-semibold">Version history</h3>
              </div>
              <ul className="divide-y divide-border">
                {project.versions.map((v) => (
                  <li key={v.id} className="flex items-center justify-between px-5 py-3">
                    <div>
                      <p className="font-mono text-sm font-medium">{v.tag}</p>
                      <p className="text-xs text-muted-foreground">{v.label}</p>
                    </div>
                    <span className="font-mono text-xs text-muted-foreground">
                      {new Date(v.createdAt).toLocaleString()}
                    </span>
                  </li>
                ))}
                {project.versions.length === 0 && (
                  <li className="px-5 py-6 text-center text-sm text-muted-foreground">
                    No versions yet.
                  </li>
                )}
              </ul>
            </Card>
          </TabsContent>

          <TabsContent value="commits" className="mt-4">
            <Card>
              <div className="border-b border-border px-5 py-3">
                <h3 className="text-sm font-semibold">Commits</h3>
              </div>
              <ul className="divide-y divide-border">
                {project.commits.map((c) => (
                  <li key={c.id} className="px-5 py-3">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-medium">{c.message}</p>
                      <span className="font-mono text-xs text-muted-foreground">
                        {timeAgo(c.createdAt)}
                      </span>
                    </div>
                    <p className="mt-0.5 font-mono text-[10px] text-muted-foreground">
                      {c.id.slice(0, 10)} · changed:{" "}
                      {c.changedFiles.slice(0, 3).join(", ")}
                      {c.changedFiles.length > 3 && " ..."}
                    </p>
                  </li>
                ))}
              </ul>
            </Card>
          </TabsContent>

          <TabsContent value="members" className="mt-4">
            <Card>
              <div className="border-b border-border px-5 py-3">
                <h3 className="text-sm font-semibold">Project members</h3>
              </div>
              <ul className="divide-y divide-border">
                {project.members.map((m) => (
                  <li
                    key={m.userId}
                    className="flex items-center justify-between px-5 py-3"
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary text-xs font-semibold">
                        {m.userId.replace("user_", "").slice(0, 2).toUpperCase()}
                      </span>
                      <div>
                        <p className="text-sm font-medium capitalize">
                          @{memberUsername(m.userId)}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Added {timeAgo(m.addedAt)}
                        </p>
                      </div>
                    </div>
                    <span className="rounded-full border border-border px-2 py-0.5 text-xs capitalize">
                      {m.role}
                    </span>
                  </li>
                ))}
              </ul>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Timeline (project legacy) */}
        <Card className="mt-6 p-5">
          <h3 className="text-sm font-semibold">Project legacy</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            RPL Forge projects can continue across generations of students.
          </p>
          <ol className="mt-4 grid gap-3 sm:grid-cols-3">
            <LegacyItem year="2026" version="v1.0" author="Andi" />
            <LegacyItem year="2027" version="v2.0" author="Budi" muted />
            <LegacyItem year="2028" version="v3.0" author="Citra" muted />
          </ol>
        </Card>
      </div>
    </AppShell>
  );
}

function LegacyItem({
  year,
  version,
  author,
  muted,
}: {
  year: string;
  version: string;
  author: string;
  muted?: boolean;
}) {
  return (
    <li
      className={
        "rounded-lg border p-3 text-sm " +
        (muted ? "border-dashed border-border opacity-60" : "border-border bg-card")
      }
    >
      <p className="font-mono text-xs text-muted-foreground">{year}</p>
      <p className="mt-1 font-semibold">
        {version} — {author}
      </p>
    </li>
  );
}

function QRDialog({ url, projectName }: { url: string; projectName: string }) {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <QrIcon className="mr-1 h-3.5 w-3.5" />
          Generate QR
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle>Share {projectName}</DialogTitle>
          <DialogDescription>
            Scan this QR code to open the live project on a phone.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col items-center gap-3 py-4">
          <div className="rounded-xl border border-border bg-white p-4">
            <QRCodeSVG value={url} size={180} />
          </div>
          <p className="font-mono text-xs text-muted-foreground">{url}</p>
          <Button
            variant="outline"
            size="sm"
            className="mt-2"
            onClick={() => window.open(url, "_blank")}
          >
            <ExternalLink className="mr-1 h-3.5 w-3.5" />
            Open URL
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ownerUsername(project: { ownerId: string }): string {
  const map: Record<string, string> = {
    user_andi: "andi",
    user_budi: "budi",
    user_citra: "citra",
    user_deni: "deni",
  };
  return map[project.ownerId] ?? "unknown";
}

function memberUsername(userId: string): string {
  return ownerUsername({ ownerId: userId });
}

function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  const diff = Date.now() - then;
  const min = Math.floor(diff / 60000);
  if (min < 1) return "just now";
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  return `${day}d ago`;
}

function readReadme(project: { files: { path: string; content?: string }[] }): string | null {
  const readme = project.files.find((f) => f.path.toLowerCase() === "readme.md");
  return readme?.content ?? null;
}
