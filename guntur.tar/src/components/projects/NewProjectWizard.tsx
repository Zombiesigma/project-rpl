"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Folder,
  FileText,
  ChevronRight,
  ChevronDown,
  FolderUp,
  Loader2,
} from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useRouterStore } from "@/store/routerStore";
import { useAuthStore } from "@/store/authStore";
import { useProjectsStore, attachRepository } from "@/store/projectsStore";
import { toast } from "@/store/uiStore";
import {
  PROJECT_CATEGORIES,
  PROJECT_TECHNOLOGY_SUGGESTIONS,
} from "@/types/project";
import { detectLanguage } from "@/types/file";
import type { ProjectFile } from "@/types/file";
import { FolderPicker, type PickedProject } from "./FolderPicker";
import { buildFileTree, countFilesAndFolders, formatFileSize, type TreeNode } from "@/lib/fileTree";
import { cn } from "@/lib/utils";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { CoverUploader } from "@/components/shared/CoverUploader";
import { repositoryService } from "@/services/mockRepositoryService";
import { deploymentService } from "@/services/mockDeploymentService";
import { projectRepository, logActivity } from "@/services/mockProjectService";

type Step = "info" | "folder" | "preview" | "uploading" | "done";

interface UploadStage {
  id:
    | "reading"
    | "validating"
    | "creating_repo"
    | "preparing_hosting"
    | "deploying";
  label: string;
  description: string;
  duration: number; // ms
}

const UPLOAD_STAGES: UploadStage[] = [
  {
    id: "reading",
    label: "Reading files",
    description: "Parsing your project structure",
    duration: 700,
  },
  {
    id: "validating",
    label: "Validating project",
    description: "Checking structure and paths",
    duration: 900,
  },
  {
    id: "creating_repo",
    label: "Creating repository",
    description: "Provisioning rpl-forge/{slug}",
    duration: 1100,
  },
  {
    id: "preparing_hosting",
    label: "Preparing hosting",
    description: "Allocating mock edge slot",
    duration: 900,
  },
  {
    id: "deploying",
    label: "Deploying",
    description: "Building and publishing",
    duration: 1500,
  },
];

const VALIDATION_CHECKS = [
  "Project contains files",
  "Project has plausible structure",
  "package.json found (or equivalent)",
  "No invalid paths",
  "No duplicate paths",
  "File sizes within limits",
];

export function NewProjectWizard() {
  const push = useRouterStore((s) => s.push);
  const session = useAuthStore((s) => s.session);
  const createProject = useProjectsStore((s) => s.createProject);
  const refresh = useProjectsStore((s) => s.refresh);

  const [step, setStep] = useState<Step>("info");
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<string>("Web Application");
  const [technologies, setTechnologies] = useState<string[]>([]);
  const [techInput, setTechInput] = useState("");
  const [visibility, setVisibility] = useState<"public" | "private">("public");
  const [coverImage, setCoverImage] = useState<string | undefined>(undefined);
  const [picked, setPicked] = useState<PickedProject | null>(null);
  const [currentStage, setCurrentStage] = useState(0);
  const [completedStages, setCompletedStages] = useState<Set<number>>(new Set());
  const [validationChecks, setValidationChecks] = useState<number>(0);
  const [createdProjectId, setCreatedProjectId] = useState<string | null>(null);

  if (!session) return null;

  const addTech = (tech: string) => {
    const trimmed = tech.trim();
    if (!trimmed) return;
    if (technologies.includes(trimmed)) return;
    setTechnologies((t) => [...t, trimmed]);
    setTechInput("");
  };

  const removeTech = (tech: string) => {
    setTechnologies((t) => t.filter((x) => x !== tech));
  };

  const handleInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Project name is required");
      return;
    }
    setStep("folder");
  };

  const handlePick = (project: PickedProject) => {
    setPicked(project);
    setStep("preview");
  };

  const handleDemoPick = (project: PickedProject) => {
    if (!name.trim()) {
      // Auto-fill name from folder name
      setName(project.folderName.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()));
    }
    setPicked(project);
    setStep("preview");
  };

  const handleUpload = async () => {
    if (!picked) return;
    setStep("uploading");
    setCurrentStage(0);
    setCompletedStages(new Set());
    setValidationChecks(0);

    // Run validation checks (purely cosmetic)
    for (let i = 0; i < VALIDATION_CHECKS.length; i++) {
      await new Promise((r) => setTimeout(r, 180));
      setValidationChecks(i + 1);
    }

    // Run upload stages
    for (let i = 0; i < UPLOAD_STAGES.length; i++) {
      setCurrentStage(i);
      await new Promise((r) => setTimeout(r, UPLOAD_STAGES[i].duration));
      setCompletedStages((prev) => new Set([...prev, i]));
    }

    // Actually create the project now
    const slug = slugify(name);
    const files: ProjectFile[] = picked.files.map((f) => ({
      id: `temp:${f.path}`,
      projectId: "temp",
      path: f.path,
      name: f.name,
      type: "file",
      language: detectLanguage(f.name),
      content: f.content,
      size: f.size,
    }));

    const project = await createProject({
      name: name.trim(),
      description: description.trim(),
      category,
      technologies: technologies.length ? technologies : ["Next.js"],
      visibility,
      ownerId: session.user.id,
      files,
      coverImage,
    });

    // Attach repository
    await attachRepository(project.id, slug);
    logActivity({
      type: "create",
      userId: session.user.id,
      projectId: project.id,
      message: `${session.user.name.split(" ")[0]} created ${project.name}`,
    });

    // Trigger mock deployment (will run in background)
    await deploymentService.createDeployment(project.id);
    await refresh();

    setCreatedProjectId(project.id);
    setStep("done");
    toast.success("Your project is live!", "View the public page to share it.");
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Step indicator */}
        <Stepper current={step} />

        <div className="mt-8">
          {step === "info" && (
            <InfoStep
              name={name}
              setName={setName}
              description={description}
              setDescription={setDescription}
              category={category}
              setCategory={setCategory}
              technologies={technologies}
              techInput={techInput}
              setTechInput={setTechInput}
              addTech={addTech}
              removeTech={removeTech}
              visibility={visibility}
              setVisibility={setVisibility}
              coverImage={coverImage}
              setCoverImage={setCoverImage}
              onSubmit={handleInfoSubmit}
              onBack={() => push("dashboard")}
            />
          )}

          {step === "folder" && (
            <FolderStep
              onPick={handlePick}
              onDemoPick={handleDemoPick}
              onBack={() => setStep("info")}
            />
          )}

          {step === "preview" && picked && (
            <PreviewStep
              picked={picked}
              onBack={() => setStep("folder")}
              onUpload={handleUpload}
              name={name}
              category={category}
            />
          )}

          {step === "uploading" && (
            <UploadingStep
              currentStage={currentStage}
              completedStages={completedStages}
              validationChecks={validationChecks}
            />
          )}

          {step === "done" && createdProjectId && (
            <DoneStep
              projectId={createdProjectId}
              projectName={name}
              slug={slugify(name)}
            />
          )}
        </div>
      </div>
    </AppShell>
  );
}

/* ----------------------------------------------------------------- */
/* Stepper                                                           */
/* ----------------------------------------------------------------- */

function Stepper({ current }: { current: Step }) {
  const steps: { id: Step; label: string }[] = [
    { id: "info", label: "Project info" },
    { id: "folder", label: "Folder" },
    { id: "preview", label: "Preview" },
    { id: "uploading", label: "Processing" },
    { id: "done", label: "Live" },
  ];
  const currentIndex = steps.findIndex((s) => s.id === current);
  return (
    <ol className="flex items-center gap-2 text-xs">
      {steps.map((s, i) => {
        const done = i < currentIndex;
        const active = i === currentIndex;
        return (
          <li key={s.id} className="flex items-center gap-2">
            <span
              className={cn(
                "flex h-6 w-6 items-center justify-center rounded-full border font-mono text-[10px]",
                done && "border-brand/40 bg-brand/10 text-brand",
                active && "border-foreground bg-foreground text-background",
                !done && !active && "border-border bg-background text-muted-foreground"
              )}
            >
              {done ? <Check className="h-3 w-3" /> : i + 1}
            </span>
            <span
              className={cn(
                "hidden font-medium sm:inline",
                active ? "text-foreground" : "text-muted-foreground"
              )}
            >
              {s.label}
            </span>
            {i < steps.length - 1 && (
              <span className="mx-1 h-px w-6 bg-border sm:w-8" />
            )}
          </li>
        );
      })}
    </ol>
  );
}

/* ----------------------------------------------------------------- */
/* Step 1: project info                                              */
/* ----------------------------------------------------------------- */

function InfoStep(props: {
  name: string;
  setName: (v: string) => void;
  description: string;
  setDescription: (v: string) => void;
  category: string;
  setCategory: (v: string) => void;
  technologies: string[];
  techInput: string;
  setTechInput: (v: string) => void;
  addTech: (v: string) => void;
  removeTech: (v: string) => void;
  visibility: "public" | "private";
  setVisibility: (v: "public" | "private") => void;
  coverImage?: string;
  setCoverImage: (v: string | undefined) => void;
  onSubmit: (e: React.FormEvent) => void;
  onBack: () => void;
}) {
  return (
    <Card className="p-6 sm:p-8">
      <h1 className="text-xl font-semibold">Project information</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Tell RPL Forge what you're building. You can change this later.
      </p>
      <form className="mt-6 space-y-5" onSubmit={props.onSubmit}>
        <div className="space-y-1.5">
          <Label htmlFor="name">Project Name</Label>
          <Input
            id="name"
            value={props.name}
            onChange={(e) => props.setName(e.target.value)}
            placeholder="Smart Attendance"
            required
            autoFocus
          />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={props.description}
            onChange={(e) => props.setDescription(e.target.value)}
            placeholder="A student attendance platform."
            rows={3}
          />
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="cover">Cover photo</Label>
          <p className="text-xs text-muted-foreground">
            Optional. Shown in the Explore grid and project page. If skipped, RPL Forge generates a live preview automatically.
          </p>
          <CoverUploader
            value={props.coverImage}
            onChange={props.setCoverImage}
            projectName={props.name || undefined}
          />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="category">Category</Label>
            <Select value={props.category} onValueChange={props.setCategory}>
              <SelectTrigger id="category">
                <SelectValue placeholder="Pick a category" />
              </SelectTrigger>
              <SelectContent>
                {PROJECT_CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>Visibility</Label>
            <div className="flex gap-2">
              {(["public", "private"] as const).map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => props.setVisibility(v)}
                  className={cn(
                    "flex-1 rounded-md border px-3 py-2 text-sm font-medium capitalize transition-colors",
                    props.visibility === v
                      ? "border-foreground bg-foreground text-background"
                      : "border-border bg-background hover:bg-secondary"
                  )}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <Label htmlFor="tech">Technologies</Label>
          <div className="flex gap-2">
            <Input
              id="tech"
              value={props.techInput}
              onChange={(e) => props.setTechInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  props.addTech(props.techInput);
                }
              }}
              placeholder="Type and press Enter"
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => props.addTech(props.techInput)}
            >
              Add
            </Button>
          </div>
          {props.technologies.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {props.technologies.map((t) => (
                <span
                  key={t}
                  className="inline-flex items-center gap-1 rounded-md bg-secondary px-2 py-0.5 font-mono text-xs"
                >
                  {t}
                  <button
                    type="button"
                    onClick={() => props.removeTech(t)}
                    className="ml-0.5 text-muted-foreground hover:text-foreground"
                    aria-label={`Remove ${t}`}
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}
          <div className="flex flex-wrap gap-1 pt-1">
            {PROJECT_TECHNOLOGY_SUGGESTIONS.filter(
              (s) => !props.technologies.includes(s)
            )
              .slice(0, 8)
              .map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => props.addTech(s)}
                  className="rounded-md border border-border px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground hover:text-foreground"
                >
                  + {s}
                </button>
              ))}
          </div>
        </div>

        <div className="flex items-center justify-between pt-4">
          <Button type="button" variant="ghost" onClick={props.onBack}>
            <ArrowLeft className="mr-1.5 h-4 w-4" />
            Cancel
          </Button>
          <Button type="submit">
            Continue
            <ArrowRight className="ml-1.5 h-4 w-4" />
          </Button>
        </div>
      </form>
    </Card>
  );
}

/* ----------------------------------------------------------------- */
/* Step 2: folder selection                                          */
/* ----------------------------------------------------------------- */

function FolderStep({
  onPick,
  onDemoPick,
  onBack,
}: {
  onPick: (p: PickedProject) => void;
  onDemoPick: (p: PickedProject) => void;
  onBack: () => void;
}) {
  return (
    <Card className="p-6 sm:p-8">
      <h1 className="text-xl font-semibold">Select your project folder</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Pick the root folder of your project. We'll preserve the file structure
        and read source files into the workspace.
      </p>
      <div className="mt-6">
        <FolderPicker onPick={onPick} onDemoPick={onDemoPick} />
      </div>
      <div className="mt-6 flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="mr-1.5 h-4 w-4" />
          Back
        </Button>
      </div>
    </Card>
  );
}

/* ----------------------------------------------------------------- */
/* Step 3: upload preview                                            */
/* ----------------------------------------------------------------- */

function PreviewStep({
  picked,
  onBack,
  onUpload,
  name,
  category,
}: {
  picked: PickedProject;
  onBack: () => void;
  onUpload: () => void;
  name: string;
  category: string;
}) {
  const stats = countFilesAndFolders(
    picked.files.map((f) => ({
      ...f,
      type: "file" as const,
      projectId: "",
      id: f.path,
    }))
  );

  // build a tree from the picked files
  const tree = buildFileTree(
    picked.files.map((f) => ({
      ...f,
      type: "file" as const,
      projectId: "",
      id: f.path,
    }))
  );

  return (
    <Card className="p-6 sm:p-8">
      <h1 className="text-xl font-semibold">Project selected</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Review your project before uploading. You can change folders if something
        looks wrong.
      </p>

      <div className="mt-6 flex flex-wrap items-center gap-3 rounded-lg border border-border bg-secondary/40 p-4">
        <Folder className="h-6 w-6 text-brand" />
        <div className="min-w-0 flex-1">
          <p className="font-mono text-sm font-medium">{picked.folderName}/</p>
          <p className="text-xs text-muted-foreground">
            {picked.fileCount} files · {picked.folderCount} folders ·{" "}
            {formatFileSize(picked.totalSize)}
          </p>
        </div>
        <div className="text-right text-xs text-muted-foreground">
          <p>Target project</p>
          <p className="font-medium text-foreground">{name}</p>
          <p>{category}</p>
        </div>
      </div>

      <Collapsible defaultOpen className="mt-4">
        <CollapsibleTrigger className="group flex w-full items-center justify-between rounded-md border border-border bg-card px-3 py-2 text-sm font-medium">
          <span>File preview</span>
          <ChevronDown className="h-4 w-4 transition-transform group-data-[state=open]:rotate-180" />
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="mt-2 max-h-80 overflow-y-auto scrollbar-thin rounded-md border border-border bg-[#0d1117] p-3 font-mono text-xs text-slate-200">
            <p className="text-slate-400">📁 {picked.folderName}/</p>
            <TreeViewTree nodes={tree} depth={1} />
          </div>
        </CollapsibleContent>
      </Collapsible>

      <div className="mt-6 flex items-center justify-between">
        <Button variant="ghost" onClick={onBack}>
          <ArrowLeft className="mr-1.5 h-4 w-4" />
          Change Folder
        </Button>
        <Button onClick={onUpload}>
          <FolderUp className="mr-1.5 h-4 w-4" />
          Upload Project
        </Button>
      </div>
    </Card>
  );
}

function TreeViewTree({ nodes, depth }: { nodes: TreeNode[]; depth: number }) {
  return (
    <ul>
      {nodes.map((node) => (
        <li key={node.file.path}>
          <div
            className="flex items-center gap-1.5"
            style={{ paddingLeft: `${depth * 14}px` }}
          >
            {node.file.type === "folder" ? (
              <>
                <ChevronRight className="h-3 w-3 text-slate-500" />
                <Folder className="h-3 w-3 text-sky-400" />
              </>
            ) : (
              <>
                <span className="w-3" />
                <FileText className="h-3 w-3 text-slate-400" />
              </>
            )}
            <span className={node.file.type === "folder" ? "text-slate-200" : "text-slate-300"}>
              {node.file.name}
            </span>
          </div>
          {node.children.length > 0 && (
            <TreeViewTree nodes={node.children} depth={depth + 1} />
          )}
        </li>
      ))}
    </ul>
  );
}

/* ----------------------------------------------------------------- */
/* Step 4: uploading                                                  */
/* ----------------------------------------------------------------- */

function UploadingStep({
  currentStage,
  completedStages,
  validationChecks,
}: {
  currentStage: number;
  completedStages: Set<number>;
  validationChecks: number;
}) {
  return (
    <Card className="p-8">
      <div className="flex items-center gap-3">
        <Loader2 className="h-5 w-5 animate-spin text-brand" />
        <div>
          <h1 className="text-lg font-semibold">Preparing your project...</h1>
          <p className="text-sm text-muted-foreground">
            This usually takes less than 10 seconds.
          </p>
        </div>
      </div>

      {/* Validation checks */}
      <div className="mt-6 rounded-lg border border-border bg-card p-4">
        <p className="mb-3 text-xs font-medium uppercase tracking-widest text-muted-foreground">
          Project validation
        </p>
        <ul className="space-y-2">
          {VALIDATION_CHECKS.map((check, i) => {
            const done = i < validationChecks;
            const active = i === validationChecks;
            return (
              <li key={check} className="flex items-center gap-2 text-sm">
                {done ? (
                  <Check className="h-4 w-4 text-emerald-500" />
                ) : active ? (
                  <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                ) : (
                  <span className="h-4 w-4 rounded-full border border-border" />
                )}
                <span className={done ? "text-foreground" : "text-muted-foreground"}>
                  {check}
                </span>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Upload stages */}
      <div className="mt-4 rounded-lg border border-border bg-card p-4">
        <p className="mb-3 text-xs font-medium uppercase tracking-widest text-muted-foreground">
          Deployment pipeline
        </p>
        <ul className="space-y-2">
          {UPLOAD_STAGES.map((stage, i) => {
            const done = completedStages.has(i);
            const active = i === currentStage && !done;
            return (
              <motion.li
                key={stage.id}
                layout
                className="flex items-center gap-3 text-sm"
              >
                {done ? (
                  <Check className="h-4 w-4 text-emerald-500" />
                ) : active ? (
                  <Loader2 className="h-4 w-4 animate-spin text-brand" />
                ) : (
                  <span className="h-4 w-4 rounded-full border border-border" />
                )}
                <div className="flex-1">
                  <p className={done || active ? "text-foreground" : "text-muted-foreground"}>
                    {stage.label}
                  </p>
                  <p className="text-xs text-muted-foreground">{stage.description}</p>
                </div>
              </motion.li>
            );
          })}
        </ul>
      </div>
    </Card>
  );
}

/* ----------------------------------------------------------------- */
/* Step 5: success                                                    */
/* ----------------------------------------------------------------- */

function DoneStep({
  projectId,
  projectName,
  slug,
}: {
  projectId: string;
  projectName: string;
  slug: string;
}) {
  const push = useRouterStore((s) => s.push);
  return (
    <Card className="overflow-hidden">
      <div className="bg-gradient-to-br from-emerald-500/10 to-brand/10 p-8 text-center sm:p-12">
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 14 }}
          className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500 text-white shadow-lg shadow-emerald-500/30"
        >
          <Check className="h-8 w-8" />
        </motion.div>
        <h1 className="mt-5 text-2xl font-bold tracking-tight sm:text-3xl">
          Your project is live
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {projectName} ·{" "}
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-2 py-0.5 text-xs font-medium text-emerald-600 dark:text-emerald-400">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
            LIVE
          </span>
        </p>
        <p className="mt-4 inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-3 py-1.5 font-mono text-xs">
          https://{slug}.rplforge.local
        </p>
        <div className="mt-6 flex flex-col items-center justify-center gap-2 sm:flex-row">
          <Button onClick={() => push("project_detail", { projectId })}>
            View Project
          </Button>
          <Button variant="outline" onClick={() => push("workspace", { projectId })}>
            Open Workspace
          </Button>
          <Button variant="ghost" onClick={() => push("dashboard")}>
            Back to Dashboard
          </Button>
        </div>
      </div>
    </Card>
  );
}

/* ----------------------------------------------------------------- */
/* helpers                                                            */
/* ----------------------------------------------------------------- */

function slugify(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}
