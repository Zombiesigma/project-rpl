"use client";

import { AppShell } from "@/components/layout/AppShell";
import { useRouterStore } from "@/store/routerStore";
import { useAuthStore } from "@/store/authStore";
import { useUIStore } from "@/store/uiStore";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Sun, Moon, LogOut, User as UserIcon, Bell, Globe } from "lucide-react";
import { toast } from "@/store/uiStore";

export function SettingsScreen() {
  const push = useRouterStore((s) => s.push);
  const session = useAuthStore((s) => s.session);
  const signOut = useAuthStore((s) => s.signOut);
  const theme = useUIStore((s) => s.theme);
  const toggleTheme = useUIStore((s) => s.toggleTheme);

  if (!session) return null;

  const handleSignOut = async () => {
    await signOut();
    toast.info("Signed out");
    push("landing");
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Manage your RPL Forge preferences.
        </p>

        <Card className="mt-6 p-6">
          <h2 className="text-sm font-semibold">Profile</h2>
          <div className="mt-4 flex items-center gap-4">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-secondary text-sm font-semibold">
              {session.user.name
                .split(" ")
                .map((n) => n[0])
                .slice(0, 2)
                .join("")}
            </span>
            <div className="flex-1">
              <p className="font-medium">{session.user.name}</p>
              <p className="text-xs text-muted-foreground">
                @{session.user.username} · {session.user.email}
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={() => push("profile", { userId: session.user.id })}>
              <UserIcon className="mr-1 h-3.5 w-3.5" />
              View profile
            </Button>
          </div>
        </Card>

        <Card className="mt-4 p-6">
          <h2 className="text-sm font-semibold">Appearance</h2>
          <div className="mt-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="dark" className="text-sm font-medium">
                  Dark mode
                </Label>
                <p className="text-xs text-muted-foreground">
                  Toggle the dark theme across the platform.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Sun className="h-4 w-4 text-muted-foreground" />
                <Switch
                  id="dark"
                  checked={theme === "dark"}
                  onCheckedChange={toggleTheme}
                />
                <Moon className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>
          </div>
        </Card>

        <Card className="mt-4 p-6">
          <h2 className="text-sm font-semibold">Notifications</h2>
          <div className="mt-4 space-y-3">
            <ToggleRow
              label="Deployment updates"
              description="Get notified when deployments succeed or fail."
              defaultChecked
            />
            <ToggleRow
              label="Project comments"
              description="Receive a notification when someone comments on your project."
              defaultChecked
            />
            <ToggleRow
              label="Weekly digest"
              description="A summary of new projects and activity each week."
            />
          </div>
        </Card>

        <Card className="mt-4 border-rose-500/30 p-6">
          <h2 className="text-sm font-semibold text-rose-600 dark:text-rose-400">
            Account
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Sign out of RPL Forge on this device.
          </p>
          <Button variant="outline" className="mt-3" onClick={handleSignOut}>
            <LogOut className="mr-1.5 h-4 w-4" />
            Sign out
          </Button>
        </Card>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          <Globe className="mr-1 inline h-3 w-3" />
          RPL Forge prototype · mock GitHub · mock Vercel · mock Firebase
        </p>
      </div>
    </AppShell>
  );
}

function ToggleRow({
  label,
  description,
  defaultChecked,
}: {
  label: string;
  description: string;
  defaultChecked?: boolean;
}) {
  return (
    <div className="flex items-center justify-between">
      <div>
        <Label className="text-sm font-medium">{label}</Label>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      <Switch defaultChecked={defaultChecked} />
    </div>
  );
}
