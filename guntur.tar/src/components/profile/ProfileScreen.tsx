"use client";

import { useEffect, useMemo } from "react";
import { motion } from "framer-motion";
import { AppShell } from "@/components/layout/AppShell";
import { useRouterStore } from "@/store/routerStore";
import { useProjectsStore } from "@/store/projectsStore";
import { useAuthStore } from "@/store/authStore";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ProjectCard } from "@/components/projects/ProjectCard";
import { DEMO_USERS } from "@/mock/seed";
import { ArrowLeft } from "lucide-react";

export function ProfileScreen() {
  const params = useRouterStore((s) => s.params);
  const push = useRouterStore((s) => s.push);
  const back = useRouterStore((s) => s.back);
  const session = useAuthStore((s) => s.session);
  const loadForUser = useProjectsStore((s) => s.loadForUser);
  const projects = useProjectsStore((s) => s.projects);

  const userId = params.userId ?? session?.user.id;
  const user = useMemo(
    () => DEMO_USERS.find((u) => u.id === userId) ?? session?.user,
    [userId, session]
  );

  useEffect(() => {
    if (userId) loadForUser(userId);
  }, [userId, loadForUser]);

  if (!user) {
    return (
      <AppShell>
        <div className="mx-auto max-w-3xl px-4 py-16 text-center">
          <h1 className="text-lg font-semibold">User not found</h1>
          <Button className="mt-4" onClick={() => push("dashboard")}>
            Back to dashboard
          </Button>
        </div>
      </AppShell>
    );
  }

  const userProjects = projects.filter(
    (p) => p.ownerId === user.id || p.members.some((m) => m.userId === user.id)
  );
  const liveCount = userProjects.filter((p) => p.status === "live").length;

  return (
    <AppShell>
      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
        <button
          onClick={back}
          className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Back
        </button>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="overflow-hidden">
            <div className="h-24 bg-gradient-to-br from-secondary via-muted to-secondary sm:h-32">
              <div aria-hidden className="absolute inset-0 grid-bg opacity-40" />
            </div>
            <div className="px-5 pb-5 sm:px-6">
              <div className="flex flex-col items-start gap-4 sm:flex-row sm:items-end">
                <Avatar className="-mt-10 h-20 w-20 border-4 border-background">
                  <AvatarFallback className="bg-foreground text-xl font-semibold text-background">
                    {user.name
                      .split(" ")
                      .map((n) => n[0])
                      .slice(0, 2)
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h1 className="text-2xl font-bold tracking-tight">{user.name}</h1>
                  <p className="text-sm text-muted-foreground">@{user.username}</p>
                </div>
                {session?.user.id === user.id && (
                  <Button variant="outline" onClick={() => push("settings")}>
                    Edit profile
                  </Button>
                )}
              </div>
              {user.bio && (
                <p className="mt-3 max-w-2xl text-sm">{user.bio}</p>
              )}
              <div className="mt-3 flex flex-wrap gap-1">
                {(user.skills ?? []).map((s) => (
                  <span
                    key={s}
                    className="rounded-md bg-secondary px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground"
                  >
                    {s}
                  </span>
                ))}
              </div>
              <div className="mt-4 grid grid-cols-3 gap-3 border-t border-border pt-4 text-sm">
                <Stat label="Projects" value={userProjects.length} />
                <Stat label="Live" value={liveCount} />
                <Stat label="Contributions" value={userProjects.length * 2} />
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Projects */}
        <section className="mt-8">
          <h2 className="text-lg font-semibold">Projects</h2>
          {userProjects.length === 0 ? (
            <p className="mt-3 text-sm text-muted-foreground">
              This user has no projects yet.
            </p>
          ) : (
            <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {userProjects.map((p) => (
                <ProjectCard
                  key={p.id}
                  project={p}
                  onClick={() => push("project_detail", { projectId: p.id })}
                />
              ))}
            </div>
          )}
        </section>
      </div>
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <p className="text-2xl font-semibold tabular-nums">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
