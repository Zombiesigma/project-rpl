"use client";

import { Compass, FolderGit2, Home, User as UserIcon, Plus } from "lucide-react";
import { useRouterStore, type RouteName } from "@/store/routerStore";
import { useAuthStore } from "@/store/authStore";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface MobileNavItem {
  label: string;
  route: RouteName;
  icon: typeof Home;
}

const ITEMS: MobileNavItem[] = [
  { label: "Home", route: "dashboard", icon: Home },
  { label: "Projects", route: "dashboard", icon: FolderGit2 },
  { label: "Explore", route: "explore", icon: Compass },
  { label: "Profile", route: "profile", icon: UserIcon },
];

export function MobileTabBar() {
  const route = useRouterStore((s) => s.route);
  const push = useRouterStore((s) => s.push);
  const session = useAuthStore((s) => s.session);
  if (!session) return null;

  return (
    <nav
      aria-label="Mobile bottom navigation"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 backdrop-blur md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div className="grid grid-cols-5 items-center px-2 py-1">
        {ITEMS.slice(0, 2).map((item) => {
          const Icon = item.icon;
          const active = route === item.route;
          return (
            <button
              key={item.label}
              onClick={() => push(item.route)}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 rounded-md py-1.5 text-[10px] font-medium",
                active ? "text-foreground" : "text-muted-foreground"
              )}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </button>
          );
        })}
        {/* Center CTA */}
        <div className="flex justify-center">
          <Button
            size="icon"
            onClick={() => push("projects_new")}
            className="h-11 w-11 rounded-full shadow-md"
            aria-label="New project"
          >
            <Plus className="h-5 w-5" />
          </Button>
        </div>
        {ITEMS.slice(2).map((item) => {
          const Icon = item.icon;
          const active = route === item.route;
          return (
            <button
              key={item.label}
              onClick={() =>
                push(item.route, item.route === "profile" ? { userId: session.user.id } : undefined)
              }
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 rounded-md py-1.5 text-[10px] font-medium",
                active ? "text-foreground" : "text-muted-foreground"
              )}
            >
              <Icon className="h-5 w-5" />
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
