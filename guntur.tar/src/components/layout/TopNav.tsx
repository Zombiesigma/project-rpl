"use client";

import { useEffect } from "react";
import Link from "next/link";
import {
  LayoutDashboard,
  FolderGit2,
  Compass,
  Code2,
  User as UserIcon,
  Settings,
  Plus,
  LogOut,
  Sun,
  Moon,
  Shield,
} from "lucide-react";
import { useRouterStore, type RouteName } from "@/store/routerStore";
import { useAuthStore } from "@/store/authStore";
import { useUIStore } from "@/store/uiStore";
import { cn } from "@/lib/utils";
import { Logo } from "./Logo";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
  SheetClose,
} from "@/components/ui/sheet";
import { Menu } from "lucide-react";

interface NavItem {
  label: string;
  route: RouteName;
  icon: typeof LayoutDashboard;
}

const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", route: "dashboard", icon: LayoutDashboard },
  { label: "Projects", route: "dashboard", icon: FolderGit2 },
  { label: "Explore", route: "explore", icon: Compass },
  { label: "Workspace", route: "workspace", icon: Code2 },
];

interface TopNavProps {
  variant?: "public" | "app";
}

export function TopNav({ variant = "app" }: TopNavProps) {
  const route = useRouterStore((s) => s.route);
  const push = useRouterStore((s) => s.push);
  const session = useAuthStore((s) => s.session);
  const signOut = useAuthStore((s) => s.signOut);
  const theme = useUIStore((s) => s.theme);
  const toggleTheme = useUIStore((s) => s.toggleTheme);

  useEffect(() => {
    // Make sure theme class is in sync on mount
    if (typeof document !== "undefined") {
      document.documentElement.classList.toggle("dark", theme === "dark");
    }
  }, [theme, route]);

  const handleSignOut = async () => {
    await signOut();
    push("landing");
  };

  const handleNav = (r: RouteName) => push(r);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        {/* Left: logo */}
        <button
          onClick={() => handleNav(session ? "dashboard" : "landing")}
          className="flex items-center gap-2"
          aria-label="RPL Forge home"
        >
          <Logo />
        </button>

        {/* Center: nav (desktop only) */}
        {variant === "app" && session && (
          <nav className="hidden md:flex items-center gap-1" aria-label="Main navigation">
            {NAV_ITEMS.map((item) => {
              const active = route === item.route;
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={() => handleNav(item.route)}
                  className={cn(
                    "inline-flex items-center gap-2 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                    active
                      ? "bg-secondary text-foreground"
                      : "text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        )}

        {variant === "public" && (
          <nav className="hidden md:flex items-center gap-1" aria-label="Public navigation">
            <button
              onClick={() => push("explore")}
              className="inline-flex items-center gap-2 rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground hover:bg-secondary/60 hover:text-foreground"
            >
              <Compass className="h-4 w-4" />
              Explore
            </button>
          </nav>
        )}

        {/* Right: actions */}
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="h-9 w-9"
          >
            {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          </Button>

          {session ? (
            <Button
              size="sm"
              onClick={() => push("projects_new")}
              className="hidden sm:inline-flex"
            >
              <Plus className="mr-1.5 h-4 w-4" />
              New Project
            </Button>
          ) : (
            <Button
              size="sm"
              onClick={() => push("login")}
              className="hidden sm:inline-flex"
            >
              Sign In
            </Button>
          )}

          {session && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className="ml-1 flex items-center gap-2 rounded-full p-0.5 ring-offset-background hover:ring-2 hover:ring-ring"
                  aria-label="Open user menu"
                >
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-secondary text-xs font-semibold">
                      {session.user.name
                        .split(" ")
                        .map((n) => n[0])
                        .slice(0, 2)
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col">
                    <span className="text-sm font-medium">{session.user.name}</span>
                    <span className="text-xs text-muted-foreground">
                      @{session.user.username}
                    </span>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => push("profile", { userId: session.user.id })}>
                  <UserIcon className="mr-2 h-4 w-4" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => push("settings")}>
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </DropdownMenuItem>
                {session.user.role === "admin" && (
                  <DropdownMenuItem onClick={() => push("admin")}>
                    <Shield className="mr-2 h-4 w-4" />
                    Admin
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          {/* Mobile nav trigger */}
          {session && (
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden" aria-label="Open menu">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72 p-4">
                <SheetTitle className="px-2 pb-4">
                  <Logo />
                </SheetTitle>
                <nav className="flex flex-col gap-1" aria-label="Mobile navigation">
                  {NAV_ITEMS.map((item) => {
                    const Icon = item.icon;
                    return (
                      <SheetClose asChild key={item.label}>
                        <button
                          onClick={() => handleNav(item.route)}
                          className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-secondary hover:text-foreground"
                        >
                          <Icon className="h-4 w-4" />
                          {item.label}
                        </button>
                      </SheetClose>
                    );
                  })}
                  <SheetClose asChild>
                    <button
                      onClick={() => push("projects_new")}
                      className="mt-2 inline-flex items-center gap-2 rounded-md bg-foreground px-3 py-2 text-sm font-medium text-background"
                    >
                      <Plus className="h-4 w-4" />
                      New Project
                    </button>
                  </SheetClose>
                </nav>
              </SheetContent>
            </Sheet>
          )}
        </div>
      </div>
    </header>
  );
}
