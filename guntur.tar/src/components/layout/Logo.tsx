"use client";

import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  showWordmark?: boolean;
}

export function Logo({ className, showWordmark = true }: LogoProps) {
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <span
        aria-hidden
        className="relative inline-flex h-7 w-7 items-center justify-center rounded-md bg-foreground text-background"
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none">
          <path
            d="M5 4 L5 20 L9 20 L9 14 L13 14 L17 20 L21 20 L17 13.5 C19 12.8 20 11.3 20 9 C20 5.5 17.7 4 13.5 4 L5 4 Z M9 11 L9 7 L13.5 7 C15.4 7 16.2 7.8 16.2 9 C16.2 10.2 15.4 11 13.5 11 L9 11 Z"
            fill="currentColor"
          />
        </svg>
        <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-brand ring-2 ring-background" />
      </span>
      {showWordmark && (
        <span className="font-semibold tracking-tight">
          RPL <span className="text-brand">Forge</span>
        </span>
      )}
    </div>
  );
}
