"use client";

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border bg-background">
      <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-4 px-4 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:px-6 lg:px-8">
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs uppercase tracking-widest text-foreground">
            RPL Forge
          </span>
          <span className="hidden sm:inline">·</span>
          <span className="hidden sm:inline">Prototype</span>
        </div>
        <p className="text-xs">
          Build. Deploy. Showcase. — From student projects to real-world impact.
        </p>
        <p className="text-xs">
          Mock GitHub · Mock Vercel · Mock Firebase
        </p>
      </div>
    </footer>
  );
}
