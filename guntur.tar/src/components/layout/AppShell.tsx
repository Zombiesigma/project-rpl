"use client";

import { TopNav } from "./TopNav";
import { Footer } from "./Footer";
import { MobileTabBar } from "./MobileTabBar";

interface AppShellProps {
  children: React.ReactNode;
  variant?: "public" | "app";
  /** Whether to render the mobile bottom tab bar (defaults to true for app variant). */
  showTabBar?: boolean;
  /** Whether to constrain content width to a max container. */
  fullWidth?: boolean;
}

export function AppShell({
  children,
  variant = "app",
  showTabBar = true,
  fullWidth = false,
}: AppShellProps) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <TopNav variant={variant} />
      <main
        className={
          fullWidth
            ? "flex-1 w-full pb-16 md:pb-0"
            : "flex-1 w-full pb-16 md:pb-0"
        }
      >
        {children}
      </main>
      <Footer />
      {variant === "app" && showTabBar && <MobileTabBar />}
    </div>
  );
}
