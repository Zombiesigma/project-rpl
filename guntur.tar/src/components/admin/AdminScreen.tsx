"use client";

import { useEffect, useMemo } from "react";
import {
  Users,
  FolderGit2,
  Globe2,
  Rocket,
  AlertCircle,
  Activity,
} from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { useRouterStore } from "@/store/routerStore";
import { useProjectsStore } from "@/store/projectsStore";
import { useAuthStore } from "@/store/authStore";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/shared/EmptyState";
import { DEMO_USERS } from "@/mock/seed";

export function AdminScreen() {
  const push = useRouterStore((s) => s.push);
  const session = useAuthStore((s) => s.session);
  const loadAll = useProjectsStore((s) => s.loadAll);
  const projects = useProjectsStore((s) => s.projects);
  const activity = useProjectsStore((s) => s.activity);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const stats = useMemo(() => {
    const live = projects.filter((p) => p.status === "live").length;
    const failed = projects.filter((p) => p.status === "failed").length;
    return {
      users: DEMO_USERS.length,
      projects: projects.length,
      live,
      failed,
    };
  }, [projects]);

  if (!session) return null;

  if (session.user.role !== "admin") {
    return (
      <AppShell>
        <div className="mx-auto max-w-3xl px-4 py-16">
          <EmptyState
            icon={AlertCircle}
            title="Admin access required"
            description="This page is only available to admin users. Sign in as an admin demo user to view it."
            action={<Button onClick={() => push("dashboard")}>Back to dashboard</Button>}
          />
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold tracking-tight">Admin overview</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          System-wide stats for the RPL Forge prototype.
        </p>

        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
          <StatCard label="Total users" value={stats.users} icon={Users} />
          <StatCard label="Total projects" value={stats.projects} icon={FolderGit2} />
          <StatCard label="Live projects" value={stats.live} icon={Globe2} />
          <StatCard
            label="Failed"
            value={stats.failed}
            icon={AlertCircle}
            tone={stats.failed > 0 ? "warn" : "default"}
          />
        </div>

        <div className="mt-8 grid gap-4 lg:grid-cols-2">
          <Card>
            <div className="border-b border-border px-5 py-3">
              <h3 className="flex items-center gap-2 text-sm font-semibold">
                <Activity className="h-4 w-4 text-muted-foreground" />
                Recent activity
              </h3>
            </div>
            <ul className="divide-y divide-border">
              {activity.slice(0, 10).map((a) => (
                <li key={a.id} className="flex items-center justify-between px-5 py-3">
                  <span className="text-sm">{a.message}</span>
                  <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                    {new Date(a.timestamp).toLocaleTimeString()}
                  </span>
                </li>
              ))}
              {activity.length === 0 && (
                <li className="px-5 py-6 text-center text-sm text-muted-foreground">
                  No activity yet.
                </li>
              )}
            </ul>
          </Card>

          <Card>
            <div className="border-b border-border px-5 py-3">
              <h3 className="flex items-center gap-2 text-sm font-semibold">
                <Rocket className="h-4 w-4 text-muted-foreground" />
                Project status breakdown
              </h3>
            </div>
            <ul className="divide-y divide-border">
              {Object.entries(
                projects.reduce<Record<string, number>>((acc, p) => {
                  acc[p.status] = (acc[p.status] ?? 0) + 1;
                  return acc;
                }, {})
              ).map(([status, count]) => (
                <li
                  key={status}
                  className="flex items-center justify-between px-5 py-3"
                >
                  <span className="text-sm capitalize">{status}</span>
                  <span className="font-mono text-sm font-semibold">{count}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}

function StatCard({
  label,
  value,
  icon: Icon,
  tone = "default",
}: {
  label: string;
  value: number;
  icon: typeof Users;
  tone?: "default" | "warn";
}) {
  return (
    <Card
      className={
        "p-4 sm:p-5 " + (tone === "warn" && value > 0 ? "border-amber-500/30" : "")
      }
    >
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </p>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <p className="mt-2 text-2xl font-semibold tabular-nums sm:text-3xl">
        {value}
      </p>
    </Card>
  );
}
