"use client";

import { cn } from "@/lib/utils";
import { PROJECT_STATUS_META, type ProjectStatus } from "@/types/project";
import { DEPLOYMENT_STATUS_META, type DeploymentStatus } from "@/types/deployment";

interface StatusBadgeProps {
  status: ProjectStatus | DeploymentStatus;
  kind?: "project" | "deployment";
  className?: string;
  showDot?: boolean;
}

export function StatusBadge({
  status,
  kind = "project",
  className,
  showDot = true,
}: StatusBadgeProps) {
  const meta =
    kind === "project"
      ? PROJECT_STATUS_META[status as ProjectStatus]
      : DEPLOYMENT_STATUS_META[status as DeploymentStatus];

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium",
        meta.badge,
        className
      )}
    >
      {showDot && <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} />}
      {meta.label}
    </span>
  );
}
