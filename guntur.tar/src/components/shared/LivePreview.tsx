"use client";

import { useMemo } from "react";
import type { Project } from "@/types/project";

interface LivePreviewProps {
  project: Pick<Project, "name" | "description" | "technologies" | "category" | "slug" | "status">;
  /** Render scale (1 = full size, 0.5 = half). Used for thumbnails. */
  className?: string;
  /** Whether to show the mock browser chrome (address bar). */
  showChrome?: boolean;
  /** Override the iframe height. */
  height?: number | string;
  /** Sandbox attribute — defaults to allowing scripts but not same-origin. */
  sandbox?: string;
}

/**
 * Generates a deterministic, visually distinct HTML preview for a project
 * based on its metadata. The preview is rendered inside a sandboxed iframe
 * using srcDoc so it cannot access the parent page.
 *
 * Each project gets a unique color palette derived from its slug, so the
 * Explore grid feels alive even without a real deployed site.
 */
export function LivePreview({
  project,
  className,
  showChrome = true,
  height = 220,
}: LivePreviewProps) {
  const html = useMemo(() => generatePreviewHtml(project), [project]);
  const url = `https://${project.slug}.rplforge.local`;

  return (
    <div
      className={
        "overflow-hidden rounded-lg border border-border bg-background " +
        (className ?? "")
      }
      style={{ height }}
    >
      {showChrome && (
        <div className="flex items-center gap-1.5 border-b border-border bg-muted/60 px-2.5 py-1.5">
          <span className="h-2 w-2 rounded-full bg-rose-400" />
          <span className="h-2 w-2 rounded-full bg-amber-400" />
          <span className="h-2 w-2 rounded-full bg-emerald-400" />
          <div className="ml-2 flex-1 truncate rounded-md bg-background px-2 py-0.5 font-mono text-[10px] text-muted-foreground">
            {url}
          </div>
        </div>
      )}
      <iframe
        title={`Live preview of ${project.name}`}
        srcDoc={html}
        sandbox="allow-scripts"
        className="block h-full w-full border-0 bg-white"
        style={{
          // Subtract chrome height when shown
          height: showChrome ? "calc(100% - 28px)" : "100%",
        }}
        loading="lazy"
      />
    </div>
  );
}

/* ----------------------------------------------------------------- */
/* HTML generator                                                    */
/* ----------------------------------------------------------------- */

const PALETTES = [
  { bg: "#0f172a", surface: "#1e293b", text: "#f1f5f9", accent: "#10b981", muted: "#94a3b8" },
  { bg: "#1a1a2e", surface: "#16213e", text: "#eaeaea", accent: "#0f3460", muted: "#a0a0b0" },
  { bg: "#fef3c7", surface: "#ffffff", text: "#1f2937", accent: "#f59e0b", muted: "#6b7280" },
  { bg: "#ecfdf5", surface: "#ffffff", text: "#064e3b", accent: "#10b981", muted: "#6b7280" },
  { bg: "#fef2f2", surface: "#ffffff", text: "#7f1d1d", accent: "#ef4444", muted: "#6b7280" },
  { bg: "#eff6ff", surface: "#ffffff", text: "#1e3a8a", accent: "#3b82f6", muted: "#6b7280" },
  { bg: "#faf5ff", surface: "#ffffff", text: "#581c87", accent: "#a855f7", muted: "#6b7280" },
  { bg: "#0c0a09", surface: "#1c1917", text: "#fafaf9", accent: "#f97316", muted: "#a8a29e" },
];

function pickPalette(slug: string) {
  let hash = 0;
  for (let i = 0; i < slug.length; i++) {
    hash = (hash * 31 + slug.charCodeAt(i)) >>> 0;
  }
  return PALETTES[hash % PALETTES.length];
}

function generatePreviewHtml(
  project: Pick<Project, "name" | "description" | "technologies" | "category" | "slug" | "status">
): string {
  const p = pickPalette(project.slug);
  const initials = project.name
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  const techBadges = project.technologies
    .slice(0, 5)
    .map(
      (t) =>
        `<span style="display:inline-block;padding:3px 8px;border-radius:6px;background:${p.surface};color:${p.muted};font-size:10px;font-family:ui-monospace,monospace;border:1px solid ${p.accent}22;">${escapeHtml(t)}</span>`
    )
    .join(" ");
  const isLive = project.status === "live";
  const statusDot = isLive
    ? `<span style="display:inline-flex;align-items:center;gap:5px;font-size:10px;color:${p.accent};font-weight:600;"><span style="width:6px;height:6px;border-radius:50%;background:${p.accent};box-shadow:0 0 6px ${p.accent};"></span>LIVE</span>`
    : `<span style="display:inline-flex;align-items:center;gap:5px;font-size:10px;color:${p.muted};font-weight:600;"><span style="width:6px;height:6px;border-radius:50%;background:${p.muted};"></span>${project.status.toUpperCase()}</span>`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body {
    background: ${p.bg};
    color: ${p.text};
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
    font-size: 13px;
    line-height: 1.5;
    overflow: hidden;
    width: 100%;
    height: 100%;
  }
  .nav {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 16px;
    border-bottom: 1px solid ${p.accent}22;
    background: ${p.bg};
  }
  .brand {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 700;
    font-size: 12px;
  }
  .logo {
    width: 22px; height: 22px;
    border-radius: 5px;
    background: ${p.accent};
    color: ${p.bg};
    display: flex; align-items: center; justify-content: center;
    font-weight: 800; font-size: 10px;
  }
  .nav-links { display: flex; gap: 12px; font-size: 10px; color: ${p.muted}; }
  .nav-links span:hover { color: ${p.text}; }
  .hero {
    padding: 22px 16px 18px;
    text-align: center;
  }
  .hero h1 {
    font-size: 20px;
    font-weight: 800;
    letter-spacing: -0.02em;
    margin-bottom: 6px;
    background: linear-gradient(135deg, ${p.text} 0%, ${p.accent} 100%);
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  .hero p {
    color: ${p.muted};
    font-size: 11px;
    max-width: 280px;
    margin: 0 auto 12px;
  }
  .cta {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 6px;
    background: ${p.accent};
    color: ${p.bg};
    font-size: 10px;
    font-weight: 700;
    text-decoration: none;
  }
  .tech {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    justify-content: center;
    padding: 0 16px 16px;
  }
  .cards {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
    padding: 0 16px 16px;
  }
  .card {
    background: ${p.surface};
    border-radius: 6px;
    padding: 10px;
    border: 1px solid ${p.accent}11;
  }
  .card-num {
    font-size: 16px;
    font-weight: 800;
    color: ${p.accent};
  }
  .card-label {
    font-size: 9px;
    color: ${p.muted};
    margin-top: 2px;
  }
  .footer {
    position: absolute;
    bottom: 0; left: 0; right: 0;
    padding: 6px 16px;
    border-top: 1px solid ${p.accent}11;
    background: ${p.bg};
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 9px;
    color: ${p.muted};
  }
  /* Subtle entrance animation */
  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(6px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .hero, .tech, .cards { animation: fadeUp 0.5s ease-out both; }
  .tech { animation-delay: 0.1s; }
  .cards { animation-delay: 0.2s; }
</style>
</head>
<body>
  <nav class="nav">
    <div class="brand">
      <span class="logo">${initials}</span>
      <span>${escapeHtml(project.name)}</span>
    </div>
    <div class="nav-links">
      <span>Home</span>
      <span>About</span>
      <span>Contact</span>
    </div>
  </nav>

  <section class="hero">
    <h1>${escapeHtml(project.name)}</h1>
    <p>${escapeHtml(project.description || "A student project built with RPL Forge.")}</p>
    <a class="cta" href="#">Get Started →</a>
  </section>

  <div class="tech">${techBadges}</div>

  <div class="cards">
    <div class="card"><div class="card-num">${project.technologies.length || 0}</div><div class="card-label">Stack</div></div>
    <div class="card"><div class="card-num">v1.0</div><div class="card-label">Version</div></div>
    <div class="card"><div class="card-num">${project.category?.split(" ")[0] ?? "App"}</div><div class="card-label">Category</div></div>
  </div>

  <div class="footer">
    <span>© ${new Date().getFullYear()} ${escapeHtml(project.name)}</span>
    ${statusDot}
  </div>
</body>
</html>`;
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
