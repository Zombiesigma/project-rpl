"use client";

import { useRef, useState, useCallback } from "react";
import { ImagePlus, X, Loader2, Image as ImageIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "@/store/uiStore";

interface CoverUploaderProps {
  /** Current cover image as base64 data URL, or undefined. */
  value?: string;
  /** Called when a new image is selected (resized base64) or removed. */
  onChange: (value: string | undefined) => void;
  /** Optional aspect ratio hint for the drop zone. */
  aspect?: "16/9" | "3/2" | "1/1";
  className?: string;
  /** Project name shown as placeholder text. */
  projectName?: string;
}

const MAX_WIDTH = 1200;
const MAX_HEIGHT = 675;
const QUALITY = 0.82;

/**
 * Resizes an image file to fit within MAX_WIDTH x MAX_HEIGHT and returns
 * a JPEG/PNG data URL. We resize on the client so localStorage doesn't
 * blow up — raw phone photos can be 5MB+, the resized version is ~50-150KB.
 */
async function resizeImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Please select an image file (PNG, JPG, or WebP)."));
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      reject(new Error("Image is too large (max 10MB)."));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Failed to read file."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("Failed to load image."));
      img.onload = () => {
        let { width, height } = img;
        // Preserve aspect ratio, fit within MAX_WIDTH x MAX_HEIGHT
        const ratio = Math.min(MAX_WIDTH / width, MAX_HEIGHT / height, 1);
        width = Math.round(width * ratio);
        height = Math.round(height * ratio);

        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("Canvas not supported."));
          return;
        }
        // White background for transparent PNGs being converted to JPEG
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        // Use PNG for small images with transparency, JPEG for photos
        const isPng = file.type === "image/png";
        const dataUrl = isPng
          ? canvas.toDataURL("image/png")
          : canvas.toDataURL("image/jpeg", QUALITY);
        resolve(dataUrl);
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  });
}

export function CoverUploader({
  value,
  onChange,
  aspect = "16/9",
  className,
  projectName,
}: CoverUploaderProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  const handleFile = useCallback(
    async (file: File) => {
      setLoading(true);
      try {
        const dataUrl = await resizeImage(file);
        onChange(dataUrl);
        toast.success("Cover photo updated");
      } catch (err) {
        toast.error(
          "Upload failed",
          err instanceof Error ? err.message : undefined
        );
      } finally {
        setLoading(false);
      }
    },
    [onChange]
  );

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    // Reset so selecting the same file again re-triggers
    e.target.value = "";
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  const handleRemove = () => {
    onChange(undefined);
    toast.info("Cover photo removed");
  };

  const aspectClass =
    aspect === "16/9"
      ? "aspect-[16/9]"
      : aspect === "3/2"
      ? "aspect-[3/2]"
      : "aspect-square";

  return (
    <div className={cn("w-full", className)}>
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={handleInputChange}
      />

      {value ? (
        <div
          className={cn(
            "group relative overflow-hidden rounded-lg border border-border",
            aspectClass
          )}
        >
          <img
            src={value}
            alt={projectName ? `Cover for ${projectName}` : "Cover photo"}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center gap-2 bg-black/50 opacity-0 transition-opacity group-hover:opacity-100">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              disabled={loading}
              className="inline-flex items-center gap-1.5 rounded-md bg-background px-3 py-1.5 text-xs font-medium hover:bg-secondary"
            >
              {loading ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <ImagePlus className="h-3.5 w-3.5" />
              )}
              Replace
            </button>
            <button
              type="button"
              onClick={handleRemove}
              disabled={loading}
              className="inline-flex items-center gap-1.5 rounded-md bg-rose-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-rose-700"
            >
              <X className="h-3.5 w-3.5" />
              Remove
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          disabled={loading}
          className={cn(
            "flex w-full flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed transition-colors",
            aspectClass,
            dragOver
              ? "border-brand bg-brand/5"
              : "border-border bg-muted/30 hover:bg-muted/60 hover:border-brand/40"
          )}
        >
          {loading ? (
            <Loader2 className="h-6 w-6 animate-spin text-brand" />
          ) : (
            <ImagePlus className="h-6 w-6 text-muted-foreground" />
          )}
          <span className="text-xs font-medium">
            {loading ? "Processing..." : "Upload cover photo"}
          </span>
          <span className="text-[10px] text-muted-foreground">
            PNG, JPG, or WebP · max 10MB · 16:9 recommended
          </span>
        </button>
      )}
    </div>
  );
}
