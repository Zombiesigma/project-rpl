"use client";

import { motion } from "framer-motion";
import {
  FolderUp,
  Globe2,
  Rocket,
  GitBranch,
  Activity as ActivityIcon,
  Plus,
  ArrowRight,
  Clock,
} from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { useProjectsStore } from "@/store/projectsStore";
import { useRouterStore } from "@/store/routerStore";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { EmptyState } from "@/components/shared/EmptyState";
import { ProjectCard } from "@/components/projects/ProjectCard";
import { useMemo } from "react";

export function DashboardScreen() {
  const session = useAuthStore((s) => s.session);
  const projects = useProjectsStore((s) => s.projects);
  const activity = useProjectsStore((s) => s.activity);
  const push = useRouterStore((s) => s.push);

  const stats = useMemo(() => {
    const total = projects.length;
    const live = projects.filter((p) => p.status === "live").length;
    const deploying = projects.filter((p) => p.status === "deploying").length;
    const contributions = activity.filter((a) => a.userId === session?.user.id).length;
    return { total, live, deploying, contributions };
  }, [projects, activity, session]);

  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour < 11) return "Good morning";
    if (hour < 17) return "Good afternoon";
    return "Good evening";
  }, []);

  if (!session) return null;

  return (
    <AppShell>
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Greeting */}
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center"
        >
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
              {greeting}
            </p>
            <h1 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">
              {session.user.name.split(" ")[0]}. Ready to build something?
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              You have {stats.total} project{stats.total === 1 ? "" : "s"} ·{" "}
              {stats.live} live · {stats.deploying} deploying
            </p>
          </div>
          <Button onClick={() => push("projects_new")}>
            <Plus className="mr-1.5 h-4 w-4" />
            New Project
          </Button>
        </motion.div>

        {/* Stats grid */}
        <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4 sm:gap-4">
          <StatCard
            label="Projects"
            value={stats.total}
            icon={FolderUp}
          />
          <StatCard label="Live" value={stats.live} icon={Globe2} />
          <StatCard
            label="Deployments"
            value={stats.total + stats.deploying}
            icon={Rocket}
            sublabel={`${stats.deploying} active`}
          />
          <StatCard
            label="Contributions"
            value={stats.contributions}
            icon={GitBranch}
          />
        </div>

        {/* Recent projects */}
        <section className="mt-10">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Recent projects</h2>
            <Button variant="ghost" size="sm" onClick={() => push("explore")}>
              Browse all
              <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </div>
          {projects.length === 0 ? (
            <EmptyState
              className="mt-4"
              icon={FolderUp}
              title="You don't have any projects yet"
              description="Build something amazing. Upload your project folder and watch it go live."
              action={
                <Button onClick={() => push("projects_new")}>
                  <Plus className="mr-1.5 h-4 w-4" />
                  New Project
                </Button>
              }
            />
          ) : (
            <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {projects.slice(0, 6).map((p) => (
                <ProjectCard
                  key={p.id}
                  project={p}
                  onClick={() => push("project_detail", { projectId: p.id })}
                />
              ))}
            </div>
          )}
        </section>

        {/* Activity feed */}
        <section className="mt-10 grid gap-4 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <div className="flex items-center justify-between border-b border-border px-5 py-4">
              <h3 className="flex items-center gap-2 text-sm font-semibold">
                <ActivityIcon className="h-4 w-4 text-muted-foreground" />
                Recent activity
              </h3>
              <span className="text-xs text-muted-foreground">
                {activity.length} entries
              </span>
            </div>
            <ul className="divide-y divide-border">
              {activity.slice(0, 8).map((a) => (
                <li key={a.id} className="flex items-center justify-between px-5 py-3">
                  <div className="flex items-center gap-3">
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary text-xs font-semibold">
                      {a.userId.replace("user_", "").slice(0, 2).toUpperCase()}
                    </span>
                    <span className="text-sm">{a.message}</span>
                  </div>
                  <span className="flex items-center gap-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {timeAgo(a.timestamp)}
                  </span>
                </li>
              ))}
              {activity.length === 0 && (
                <li className="px-5 py-6 text-center text-sm text-muted-foreground">
                  No activity yet.
                </li>
              )}
            </ul>
          </Card>

          {/* What's next */}
          <Card>
            <div className="border-b border-border px-5 py-4">
              <h3 className="text-sm font-semibold">What to do next</h3>
            </div>
            <div className="p-5">
              <ol className="space-y-3">
                <NextStep
                  num="1"
                  title="Upload a project"
                  description="Pick a local folder and RPL Forge handles the rest."
                  cta="New Project"
                  onClick={() => push("projects_new")}
                />
                <NextStep
                  num="2"
                  title="Open the workspace"
                  description="Edit code, save, commit, and redeploy."
                  cta="Open Workspace"
                  onClick={() =>
                    projects[0] &&
                    push("workspace", { projectId: projects[0].id })
                  }
                  disabled={projects.length === 0}
                />
                <NextStep
                  num="3"
                  title="Share your work"
                  description="Open the public project page and grab a QR code."
                  cta="Explore"
                  onClick={() => push("explore")}
                />
              </ol>
            </div>
          </Card>
        </section>
      </div>
    </AppShell>
  );
}

function StatCard({
  label,
  value,
  icon: Icon,
  sublabel,
}: {
  label: string;
  value: number;
  icon: typeof FolderUp;
  sublabel?: string;
}) {
  return (
    <Card className="p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </p>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <p className="mt-2 text-2xl font-semibold tabular-nums sm:text-3xl">
        {value}
      </p>
      {sublabel && (
        <p className="mt-0.5 text-xs text-muted-foreground">{sublabel}</p>
      )}
    </Card>
  );
}

function NextStep({
  num,
  title,
  description,
  cta,
  onClick,
  disabled,
}: {
  num: string;
  title: string;
  description: string;
  cta: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <li className="flex items-start gap-3">
      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-secondary font-mono text-xs font-semibold">
        {num}
      </span>
      <div className="flex-1">
        <p className="text-sm font-medium">{title}</p>
        <p className="text-xs text-muted-foreground">{description}</p>
        <button
          onClick={onClick}
          disabled={disabled}
          className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-brand disabled:opacity-40"
        >
          {cta}
          <ArrowRight className="h-3 w-3" />
        </button>
      </div>
    </li>
  );
}

function timeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  const diff = Date.now() - then;
  const min = Math.floor(diff / 60000);
  if (min < 1) return "just now";
  if (min < 60) return `${min}m ago`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.floor(hr / 24);
  return `${day}d ago`;
}
