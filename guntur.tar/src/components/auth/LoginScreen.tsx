"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowRight, KeyRound, Mail, ShieldCheck, User as UserIcon, Zap } from "lucide-react";
import { useAuthStore } from "@/store/authStore";
import { useRouterStore } from "@/store/routerStore";
import { useProjectsStore } from "@/store/projectsStore";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/layout/Logo";
import { DEMO_USERS } from "@/mock/seed";
import { toast } from "@/store/uiStore";

export function LoginScreen() {
  const signIn = useAuthStore((s) => s.signIn);
  const signInWithGoogle = useAuthStore((s) => s.signInWithGoogle);
  const signInAs = useAuthStore((s) => s.signInAs);
  const loading = useAuthStore((s) => s.loading);
  const error = useAuthStore((s) => s.error);
  const clearError = useAuthStore((s) => s.clearError);
  const push = useRouterStore((s) => s.push);
  const loadForUser = useProjectsStore((s) => s.loadForUser);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    return () => clearError();
  }, [clearError]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const session = await signIn(email, password);
      await loadForUser(session.user.id);
      toast.success(`Welcome back, ${session.user.name.split(" ")[0]}!`);
      push("dashboard");
    } catch {
      // error is already in store
    }
  };

  const handleGoogle = async () => {
    try {
      const session = await signInWithGoogle();
      await loadForUser(session.user.id);
      toast.success(`Signed in as ${session.user.name.split(" ")[0]}`);
      push("dashboard");
    } catch {
      /* ignore */
    }
  };

  const handleDemo = async (userId: string) => {
    try {
      const session = await signInAs(userId);
      await loadForUser(session.user.id);
      toast.success(`Signed in as ${session.user.name.split(" ")[0]}`);
      push("dashboard");
    } catch {
      /* ignore */
    }
  };

  return (
    <div className="relative flex min-h-screen flex-col bg-background">
      <div aria-hidden className="absolute inset-0 grid-bg opacity-50" />
      <header className="relative z-10 mx-auto flex h-14 w-full max-w-7xl items-center justify-between px-4 sm:px-6">
        <button onClick={() => push("landing")} aria-label="Back to home">
          <Logo />
        </button>
        <Button variant="ghost" size="sm" onClick={() => push("landing")}>
          Back to home
        </Button>
      </header>

      <main className="relative z-10 mx-auto flex w-full max-w-7xl flex-1 items-center px-4 pb-12 sm:px-6">
        <div className="grid w-full gap-8 lg:grid-cols-2 lg:gap-16">
          {/* Left: marketing column */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
            className="hidden lg:flex lg:flex-col lg:justify-center"
          >
            <p className="font-mono text-xs uppercase tracking-widest text-brand">
              Welcome to RPL Forge
            </p>
            <h1 className="mt-3 text-4xl font-bold tracking-tight">
              Sign in and ship your project today.
            </h1>
            <p className="mt-4 max-w-md text-muted-foreground">
              Use one of the demo accounts below to explore the full prototype
              experience — upload, deploy, edit, and redeploy, all without any
              real GitHub or Vercel setup.
            </p>
            <ul className="mt-6 space-y-3 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-brand" />
                Live in under a minute
              </li>
              <li className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-brand" />
                No real credentials required
              </li>
              <li className="flex items-center gap-2">
                <UserIcon className="h-4 w-4 text-brand" />
                Four demo students to switch between
              </li>
            </ul>
          </motion.div>

          {/* Right: form column */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35, delay: 0.05 }}
            className="flex flex-col justify-center"
          >
            <Card className="border-border p-6 sm:p-8">
              <h2 className="text-xl font-semibold">Sign in to RPL Forge</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Use any demo account or your demo email.
              </p>

              <form className="mt-6 space-y-4" onSubmit={handleSignIn}>
                <div className="space-y-1.5">
                  <Label htmlFor="email" className="text-xs font-medium">
                    Email
                  </Label>
                  <div className="relative">
                    <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      autoComplete="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="andi@rplforge.dev"
                      className="pl-9"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="password" className="text-xs font-medium">
                    Password
                  </Label>
                  <div className="relative">
                    <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      id="password"
                      type="password"
                      autoComplete="current-password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="pl-9"
                    />
                  </div>
                </div>

                {error && (
                  <p
                    role="alert"
                    className="rounded-md border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-xs text-rose-600 dark:text-rose-400"
                  >
                    {error}
                  </p>
                )}

                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? "Signing in..." : "Sign In"}
                  {!loading && <ArrowRight className="ml-1.5 h-4 w-4" />}
                </Button>
              </form>

              <div className="relative my-5">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-[10px] uppercase tracking-widest text-muted-foreground">
                  <span className="bg-card px-2">or</span>
                </div>
              </div>

              <Button
                variant="outline"
                className="w-full"
                onClick={handleGoogle}
                disabled={loading}
              >
                <GoogleIcon className="mr-2 h-4 w-4" />
                Continue with Google
              </Button>
            </Card>

            {/* Demo accounts */}
            <div className="mt-6">
              <p className="mb-2 text-xs font-medium uppercase tracking-widest text-muted-foreground">
                Demo accounts (one click)
              </p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {DEMO_USERS.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => handleDemo(u.id)}
                    disabled={loading}
                    className="flex flex-col items-start gap-1 rounded-lg border border-border bg-card p-3 text-left transition-colors hover:border-brand/40 hover:bg-secondary/60 disabled:opacity-50"
                  >
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary text-xs font-semibold">
                      {u.name
                        .split(" ")
                        .map((n) => n[0])
                        .slice(0, 2)
                        .join("")}
                    </span>
                    <span className="text-sm font-medium">{u.name.split(" ")[0]}</span>
                    <span className="font-mono text-[10px] text-muted-foreground">
                      @{u.username}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden>
      <path
        fill="currentColor"
        d="M21.35 11.1H12v3.8h5.35c-.55 2.45-2.6 4.05-5.35 4.05-3.2 0-5.85-2.65-5.85-5.85S8.8 7.25 12 7.25c1.45 0 2.75.5 3.8 1.45l2.85-2.85C17 4 14.7 3 12 3 7 3 3 7 3 12s4 9 9 9c5.2 0 8.7-3.65 8.7-8.8 0-.45-.05-.8-.35-1.1z"
      />
    </svg>
  );
}
