"use client";

import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { GitBranch } from "lucide-react";

interface CommitDialogProps {
  open: boolean;
  onClose: () => void;
  onCommit: (message: string) => void;
  changedFiles: string[];
  defaultMessage?: string;
}

export function CommitDialog({
  open,
  onClose,
  onCommit,
  changedFiles,
  defaultMessage,
}: CommitDialogProps) {
  // Initialize state from props; the `key` on the parent ensures a fresh
  // mount each time the dialog is opened, so initial state is correct.
  const [message, setMessage] = useState(defaultMessage ?? "");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    onCommit(message.trim());
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <GitBranch className="h-4 w-4 text-brand" />
            Commit & deploy
          </DialogTitle>
          <DialogDescription>
            Write a short message describing your changes. We'll create a
            simulated commit and trigger a new deployment.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="mt-2 space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="message">Commit message</Label>
            <Input
              id="message"
              autoFocus
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Update homepage hero section"
            />
          </div>
          {changedFiles.length > 0 && (
            <div>
              <p className="mb-1 text-xs font-medium uppercase tracking-widest text-muted-foreground">
                Changed files ({changedFiles.length})
              </p>
              <ul className="max-h-32 overflow-y-auto scrollbar-thin rounded-md border border-border bg-muted/40 p-2 font-mono text-[10px]">
                {changedFiles.map((f) => (
                  <li key={f} className="truncate text-muted-foreground">
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={!message.trim()}>
              Commit & Deploy
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
