"use client";

import { useEffect, useRef, useState } from "react";
import Editor, { type OnMount } from "@monaco-editor/react";
import { X, Circle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ProjectFile } from "@/types/file";

export interface EditorTab {
  path: string;
  name: string;
  language: string;
  original: string;        // last saved content
  draft: string;           // current editor content
  dirty: boolean;
}

interface EditorPanelProps {
  tabs: EditorTab[];
  activePath?: string;
  onActivate: (path: string) => void;
  onClose: (path: string) => void;
  onChange: (path: string, value: string) => void;
  /** Called when the editor mounts — exposes monaco instance. */
  onMount?: OnMount;
}

export function EditorPanel({
  tabs,
  activePath,
  onActivate,
  onClose,
  onChange,
  onMount,
}: EditorPanelProps) {
  const activeTab = tabs.find((t) => t.path === activePath);
  const editorRef = useRef<Parameters<OnMount>[0] | null>(null);

  // When the active tab changes, restore its draft into the editor
  useEffect(() => {
    if (!editorRef.current || !activeTab) return;
    const model = editorRef.current.getModel();
    if (!model) return;
    if (model.getValue() !== activeTab.draft) {
      model.setValue(activeTab.draft);
    }
  }, [activePath, activeTab]);

  const handleMount: OnMount = (editor, monaco) => {
    editorRef.current = editor;
    // Define a custom dark theme that matches the workspace chrome
    monaco.editor.defineTheme("rplforge-dark", {
      base: "vs-dark",
      inherit: true,
      rules: [],
      colors: {
        "editor.background": "#0d1117",
        "editor.lineHighlightBackground": "#1a2029",
        "editorLineNumber.foreground": "#4a5568",
        "editorLineNumber.activeForeground": "#cbd5e0",
        "editorCursor.foreground": "#10b981",
        "editor.selectionBackground": "#1f2937",
        "editorIndentGuide.background1": "#1a2029",
      },
    });
    monaco.editor.setTheme("rplforge-dark");
    onMount?.(editor, monaco);
  };

  return (
    <div className="flex h-full flex-col bg-[#0d1117]">
      {/* Tabs */}
      <div className="flex shrink-0 items-stretch overflow-x-auto border-b border-slate-800 bg-[#161b22] scrollbar-thin">
        {tabs.length === 0 && (
          <div className="flex h-9 items-center px-4 text-xs text-slate-500">
            No file open. Pick one from the explorer.
          </div>
        )}
        {tabs.map((tab) => {
          const active = tab.path === activePath;
          return (
            <div
              key={tab.path}
              onClick={() => onActivate(tab.path)}
              className={cn(
                "group flex h-9 cursor-pointer items-center gap-2 border-r border-slate-800 px-3 text-xs",
                active
                  ? "bg-[#0d1117] text-slate-100"
                  : "bg-transparent text-slate-400 hover:bg-slate-800/40"
              )}
            >
              {tab.dirty && (
                <Circle className="h-2 w-2 fill-current text-amber-400" />
              )}
              <span className="font-mono">{tab.name}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onClose(tab.path);
                }}
                aria-label={`Close ${tab.name}`}
                className="ml-1 flex h-4 w-4 items-center justify-center rounded text-slate-500 hover:bg-slate-700 hover:text-slate-200"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Editor */}
      <div className="relative flex-1">
        {activeTab ? (
          <Editor
            height="100%"
            path={activeTab.path}
            defaultLanguage={activeTab.language}
            defaultValue={activeTab.draft}
            value={activeTab.draft}
            theme="rplforge-dark"
            onMount={handleMount}
            onChange={(value) => {
              if (value !== undefined && activeTab) {
                onChange(activeTab.path, value);
              }
            }}
            options={{
              fontSize: 13,
              fontFamily: "var(--font-geist-mono), monospace",
              fontLigatures: true,
              minimap: { enabled: false },
              lineNumbers: "on",
              renderLineHighlight: "all",
              scrollBeyondLastLine: false,
              smoothScrolling: true,
              tabSize: 2,
              wordWrap: "on",
              automaticLayout: true,
              padding: { top: 12, bottom: 12 },
              scrollbar: {
                verticalScrollbarSize: 10,
                horizontalScrollbarSize: 10,
              },
            }}
          />
        ) : (
          <div className="flex h-full items-center justify-center text-xs text-slate-500">
            <div className="text-center">
              <p className="font-mono">RPL Forge Workspace</p>
              <p className="mt-1 text-slate-600">
                Open a file from the explorer to start editing.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* Helper to convert a ProjectFile to an EditorTab. */
export function toEditorTab(file: ProjectFile): EditorTab {
  const content = file.content ?? "";
  return {
    path: file.path,
    name: file.name,
    language: file.language ?? "plaintext",
    original: content,
    draft: content,
    dirty: false,
  };
}
