"use client";

import { motion, AnimatePresence } from "framer-motion";
import { Check, Loader2, X, AlertCircle } from "lucide-react";
import type { Deployment, DeploymentStatus } from "@/types/deployment";
import { DEPLOYMENT_STATUS_META } from "@/types/deployment";
import { cn } from "@/lib/utils";

interface DeployProgressProps {
  deployment: Deployment | null;
  /** Optional: stage labels for the saving → commit → deploy flow. */
  savingFlow?: {
    show: boolean;
    savingDone: boolean;
    commitDone: boolean;
  };
  onClose?: () => void;
}

const STAGE_LABELS: { status: DeploymentStatus; label: string }[] = [
  { status: "queued", label: "Queued" },
  { status: "building", label: "Building" },
  { status: "deploying", label: "Publishing" },
  { status: "ready", label: "Live" },
];

export function DeployProgress({
  deployment,
  savingFlow,
  onClose,
}: DeployProgressProps) {
  if (!deployment && !savingFlow?.show) return null;

  const currentStatusIdx = deployment
    ? STAGE_LABELS.findIndex((s) => s.status === deployment.status)
    : -1;
  const failed = deployment?.status === "failed";

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      className="fixed bottom-4 right-4 z-50 w-full max-w-sm rounded-lg border border-border bg-card p-4 shadow-xl"
      role="dialog"
      aria-live="polite"
    >
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold">
          {failed
            ? "Deployment failed"
            : deployment?.status === "ready"
            ? "Deployment ready"
            : "Deploying changes..."}
        </p>
        {(deployment?.status === "ready" || failed) && onClose && (
          <button
            onClick={onClose}
            aria-label="Close"
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Saving flow steps */}
      {savingFlow?.show && (
        <ul className="mt-3 space-y-1.5">
          <FlowRow
            label="Changes saved"
            done={savingFlow.savingDone}
            active={!savingFlow.savingDone}
          />
          <FlowRow
            label="Commit created"
            done={savingFlow.commitDone}
            active={savingFlow.savingDone && !savingFlow.commitDone}
          />
        </ul>
      )}

      {/* Deployment stages */}
      {deployment && (
        <ul className="mt-3 space-y-1.5">
          {STAGE_LABELS.map((stage, i) => {
            const done = !failed && i < currentStatusIdx;
            const active = !failed && i === currentStatusIdx && deployment.status !== "ready";
            const isFinal =
              !failed && stage.status === "ready" && deployment.status === "ready";
            return (
              <FlowRow
                key={stage.status}
                label={stage.label}
                done={done || isFinal}
                active={active}
                failed={failed && i === currentStatusIdx}
              />
            );
          })}
        </ul>
      )}

      {/* Latest log line */}
      {deployment && deployment.logs.length > 0 && (
        <div className="mt-3 rounded-md border border-border bg-[#0d1117] p-2 font-mono text-[10px] text-slate-300">
          <p className="truncate">
            <span className="text-slate-500">$</span>{" "}
            {deployment.logs[deployment.logs.length - 1].message}
          </p>
        </div>
      )}

      {/* Failed message */}
      {failed && deployment?.error && (
        <p className="mt-2 inline-flex items-center gap-1 text-xs text-rose-600 dark:text-rose-400">
          <AlertCircle className="h-3 w-3" />
          {deployment.error}
        </p>
      )}
    </motion.div>
  );
}

function FlowRow({
  label,
  done,
  active,
  failed,
}: {
  label: string;
  done: boolean;
  active: boolean;
  failed?: boolean;
}) {
  return (
    <li className="flex items-center gap-2 text-xs">
      {done ? (
        <Check className="h-3.5 w-3.5 text-emerald-500" />
      ) : active ? (
        <Loader2 className="h-3.5 w-3.5 animate-spin text-brand" />
      ) : failed ? (
        <X className="h-3.5 w-3.5 text-rose-500" />
      ) : (
        <span className="h-3.5 w-3.5 rounded-full border border-border" />
      )}
      <span
        className={cn(
          done || active ? "text-foreground" : "text-muted-foreground",
          failed && "text-rose-600 dark:text-rose-400"
        )}
      >
        {label}
      </span>
    </li>
  );
}
