"use client";

import { useEffect, useMemo, useState, useRef } from "react";
import {
  ArrowLeft,
  Save,
  Rocket,
  ExternalLink,
  Settings as SettingsIcon,
  CircleDot,
  PanelLeftClose,
  PanelLeft,
} from "lucide-react";
import { useRouterStore } from "@/store/routerStore";
import { useProjectsStore } from "@/store/projectsStore";
import { useAuthStore } from "@/store/authStore";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/shared/StatusBadge";
import {
  ResizableHandle,
  ResizablePanel,
  ResizablePanelGroup,
} from "@/components/ui/resizable";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input as DInput } from "@/components/ui/input";
import { Label as DLabel } from "@/components/ui/label";

import { toast } from "@/store/uiStore";
import { FileExplorer } from "./FileExplorer";
import { EditorPanel, type EditorTab, toEditorTab } from "./EditorPanel";
import { CommitDialog } from "./CommitDialog";
import { DeployProgress } from "./DeployProgress";
import { cn } from "@/lib/utils";

type MobileTab = "files" | "code" | "preview";

export function WorkspaceScreen() {
  const params = useRouterStore((s) => s.params);
  const push = useRouterStore((s) => s.push);
  const back = useRouterStore((s) => s.back);
  const projects = useProjectsStore((s) => s.projects);
  const refresh = useProjectsStore((s) => s.refresh);
  const saveFile = useProjectsStore((s) => s.saveFile);
  const createFile = useProjectsStore((s) => s.createFile);
  const deleteFile = useProjectsStore((s) => s.deleteFile);
  const renameFile = useProjectsStore((s) => s.renameFile);
  const deployProject = useProjectsStore((s) => s.deployProject);
  const session = useAuthStore((s) => s.session);

  const project = useMemo(
    () => projects.find((p) => p.id === params.projectId),
    [projects, params.projectId]
  );

  const [tabs, setTabs] = useState<EditorTab[]>([]);
  const [activePath, setActivePath] = useState<string | undefined>(undefined);
  const [commitOpen, setCommitOpen] = useState(false);
  const [deployVisible, setDeployVisible] = useState(false);
  const [savingState, setSavingState] = useState<{
    savingDone: boolean;
    commitDone: boolean;
  }>({ savingDone: false, commitDone: false });
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileTab, setMobileTab] = useState<MobileTab>("code");

  // File operation dialogs
  const [createDialog, setCreateDialog] = useState<{
    open: boolean;
    parentPath: string;
    type: "file" | "folder";
  }>({ open: false, parentPath: "", type: "file" });
  const [renameDialog, setRenameDialog] = useState<{
    open: boolean;
    path: string;
    newName: string;
  }>({ open: false, path: "", newName: "" });
  const [deleteDialog, setDeleteDialog] = useState<{
    open: boolean;
    path: string;
  }>({ open: false, path: "" });
  const [newItemName, setNewItemName] = useState("");

  // Poll for deployment status updates
  useEffect(() => {
    if (!project) return;
    if (
      project.deployment &&
      (project.deployment.status === "queued" ||
        project.deployment.status === "building" ||
        project.deployment.status === "deploying")
    ) {
      const i = setInterval(refresh, 1000);
      return () => clearInterval(i);
    }
  }, [project, refresh]);

  // Auto-open README on first load — use a ref guard to avoid setState-in-effect lint
  const firstLoadRef = useRef(false);
  useEffect(() => {
    if (!project || firstLoadRef.current) return;
    firstLoadRef.current = true;
    const initialFile =
      project.files.find((f) => f.path === "src/app/page.tsx") ??
      project.files.find((f) => f.path === "README.md") ??
      project.files.find((f) => f.type === "file");
    if (initialFile) {
      // Defer the state update to escape the synchronous effect lint rule
      Promise.resolve().then(() => {
        setTabs([toEditorTab(initialFile)]);
        setActivePath(initialFile.path);
      });
    }
  }, [project]);

  if (!project || !session) {
    return (
      <AppShell>
        <div className="mx-auto max-w-3xl px-4 py-16 text-center">
          <h1 className="text-lg font-semibold">Workspace unavailable</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            This project doesn't exist or you're not signed in.
          </p>
          <Button className="mt-4" onClick={() => push("dashboard")}>
            Back to dashboard
          </Button>
        </div>
      </AppShell>
    );
  }

  const activeTab = tabs.find((t) => t.path === activePath);
  const hasDirty = tabs.some((t) => t.dirty);

  const handleSelect = (path: string) => {
    setActivePath(path);
    if (!tabs.find((t) => t.path === path)) {
      const file = project.files.find((f) => f.path === path);
      if (file) setTabs((prev) => [...prev, toEditorTab(file)]);
    }
    setMobileTab("code");
  };

  const handleCloseTab = (path: string) => {
    const next = tabs.filter((t) => t.path !== path);
    setTabs(next);
    if (activePath === path) {
      setActivePath(next[0]?.path);
    }
  };

  const handleChange = (path: string, value: string) => {
    setTabs((prev) =>
      prev.map((t) =>
        t.path === path
          ? { ...t, draft: value, dirty: value !== t.original }
          : t
      )
    );
  };

  const handleSave = async () => {
    if (!activeTab || !activeTab.dirty) return;
    try {
      await saveFile(
        project.id,
        activeTab.path,
        activeTab.draft,
        `Update ${activeTab.path}`,
        session.user.id
      );
      // Mark tab as clean
      setTabs((prev) =>
        prev.map((t) =>
          t.path === activeTab.path
            ? { ...t, original: t.draft, dirty: false }
            : t
        )
      );
      toast.success("File saved", activeTab.path);
    } catch (err) {
      toast.error("Save failed", err instanceof Error ? err.message : undefined);
    }
  };

  const handleSaveAll = async () => {
    const dirtyTabs = tabs.filter((t) => t.dirty);
    for (const tab of dirtyTabs) {
      try {
        await saveFile(
          project.id,
          tab.path,
          tab.draft,
          `Update ${tab.path}`,
          session.user.id
        );
      } catch {
        // continue
      }
    }
    setTabs((prev) =>
      prev.map((t) => ({ ...t, original: t.draft, dirty: false }))
    );
    if (dirtyTabs.length > 0) {
      toast.success(`Saved ${dirtyTabs.length} file${dirtyTabs.length === 1 ? "" : "s"}`);
    }
  };

  const handleCommitAndDeploy = async (message: string) => {
    setCommitOpen(false);
    setDeployVisible(true);
    setSavingState({ savingDone: false, commitDone: false });

    // Save all dirty tabs
    const dirtyTabs = tabs.filter((t) => t.dirty);
    for (const tab of dirtyTabs) {
      try {
        await saveFile(project.id, tab.path, tab.draft, message, session.user.id);
      } catch {
        // continue
      }
    }
    setTabs((prev) =>
      prev.map((t) => ({ ...t, original: t.draft, dirty: false }))
    );

    await new Promise((r) => setTimeout(r, 400));
    setSavingState({ savingDone: true, commitDone: false });

    await new Promise((r) => setTimeout(r, 400));
    setSavingState({ savingDone: true, commitDone: true });

    // Trigger deployment
    try {
      await deployProject(project.id);
      toast.success("Deployment started");
    } catch (err) {
      toast.error("Deployment failed", err instanceof Error ? err.message : undefined);
      setDeployVisible(false);
    }
  };

  /* File operations */

  const openCreateDialog = (parentPath: string, type: "file" | "folder") => {
    setCreateDialog({ open: true, parentPath, type });
    setNewItemName("");
  };

  const handleCreateItem = async () => {
    if (!newItemName.trim()) return;
    const parent = createDialog.parentPath;
    const newPath = parent ? `${parent}/${newItemName.trim()}` : newItemName.trim();
    try {
      await createFile(project.id, newPath, createDialog.type, "", session.user.id);
      toast.success(`${createDialog.type === "file" ? "File" : "Folder"} created`, newPath);
      if (createDialog.type === "file") {
        // Open the new file
        const file = (await refresh()).find((p) => p.id === project.id);
        const newFile = file?.files.find((f) => f.path === newPath);
        if (newFile) {
          setTabs((prev) => [...prev, toEditorTab(newFile)]);
          setActivePath(newPath);
        }
      }
    } catch (err) {
      toast.error("Create failed", err instanceof Error ? err.message : undefined);
    }
    setCreateDialog({ ...createDialog, open: false });
  };

  const openRenameDialog = (path: string) => {
    const name = path.split("/").pop() ?? path;
    setRenameDialog({ open: true, path, newName: name });
  };

  const handleRenameItem = async () => {
    if (!renameDialog.newName.trim()) return;
    const segments = renameDialog.path.split("/");
    segments[segments.length - 1] = renameDialog.newName.trim();
    const newPath = segments.join("/");
    try {
      await renameFile(project.id, renameDialog.path, newPath, session.user.id);
      toast.success("Renamed", `${renameDialog.path} → ${newPath}`);
    } catch (err) {
      toast.error("Rename failed", err instanceof Error ? err.message : undefined);
    }
    setRenameDialog({ ...renameDialog, open: false });
  };

  const handleDeleteItem = async () => {
    try {
      await deleteFile(project.id, deleteDialog.path, session.user.id);
      // Close tab if open
      setTabs((prev) => prev.filter((t) => t.path !== deleteDialog.path));
      if (activePath === deleteDialog.path) {
        setActivePath(undefined);
      }
      toast.success("Deleted", deleteDialog.path);
    } catch (err) {
      toast.error("Delete failed", err instanceof Error ? err.message : undefined);
    }
    setDeleteDialog({ open: false, path: "" });
  };

  /* ---------------------------------- render --------------------------------- */

  return (
    <div className="flex h-screen flex-col bg-background">
      {/* Top toolbar */}
      <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border bg-background px-3">
        <button
          onClick={back}
          className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground"
          aria-label="Back"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <div className="hidden items-center gap-2 sm:flex">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
            RPL Forge /
          </span>
          <span className="text-sm font-semibold">{project.name}</span>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {project.deployment && (
            <StatusBadge
              status={project.deployment.status}
              kind="deployment"
              showDot
            />
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleSave}
            disabled={!hasDirty}
            className="hidden sm:inline-flex"
          >
            <Save className="mr-1 h-3.5 w-3.5" />
            Save
          </Button>
          <Button
            size="sm"
            onClick={() => setCommitOpen(true)}
            disabled={!hasDirty}
          >
            <Rocket className="mr-1 h-3.5 w-3.5" />
            Deploy Changes
          </Button>
          {project.deployment?.status === "ready" && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(project.deployment!.url, "_blank")}
            >
              <ExternalLink className="mr-1 h-3.5 w-3.5" />
              <span className="hidden sm:inline">Open</span>
            </Button>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => push("project_settings", { projectId: project.id })}
            aria-label="Project settings"
          >
            <SettingsIcon className="h-4 w-4" />
          </Button>
        </div>
      </header>

      {/* Mobile tab switcher */}
      <div className="flex shrink-0 border-b border-border bg-background md:hidden">
        {(["files", "code", "preview"] as MobileTab[]).map((t) => (
          <button
            key={t}
            onClick={() => setMobileTab(t)}
            className={cn(
              "flex-1 py-2 text-xs font-medium capitalize",
              mobileTab === t
                ? "border-b-2 border-foreground text-foreground"
                : "text-muted-foreground"
            )}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Body */}
      <div className="flex-1 overflow-hidden">
        {/* Desktop: resizable panels */}
        <ResizablePanelGroup
          direction="horizontal"
          className="hidden h-full md:flex"
        >
          {sidebarOpen && (
            <>
              <ResizablePanel defaultSize={20} minSize={14} maxSize={32}>
                <FileExplorer
                  files={project.files}
                  activePath={activePath}
                  onSelect={handleSelect}
                  onCreateFile={(p) => openCreateDialog(p, "file")}
                  onCreateFolder={(p) => openCreateDialog(p, "folder")}
                  onRename={openRenameDialog}
                  onDelete={(p) => setDeleteDialog({ open: true, path: p })}
                />
              </ResizablePanel>
              <ResizableHandle withHandle />
            </>
          )}
          <ResizablePanel defaultSize={sidebarOpen ? 80 : 100}>
            <EditorPanel
              tabs={tabs}
              activePath={activePath}
              onActivate={setActivePath}
              onClose={handleCloseTab}
              onChange={handleChange}
            />
          </ResizablePanel>
        </ResizablePanelGroup>

        {/* Mobile: tabbed view */}
        <div className="h-full md:hidden">
          {mobileTab === "files" && (
            <FileExplorer
              files={project.files}
              activePath={activePath}
              onSelect={handleSelect}
              onCreateFile={(p) => openCreateDialog(p, "file")}
              onCreateFolder={(p) => openCreateDialog(p, "folder")}
              onRename={openRenameDialog}
              onDelete={(p) => setDeleteDialog({ open: true, path: p })}
            />
          )}
          {mobileTab === "code" && (
            <EditorPanel
              tabs={tabs}
              activePath={activePath}
              onActivate={setActivePath}
              onClose={handleCloseTab}
              onChange={handleChange}
            />
          )}
          {mobileTab === "preview" && (
            <div className="flex h-full items-center justify-center bg-[#0d1117] p-6 text-center text-slate-400">
              <div>
                <p className="font-mono text-xs uppercase tracking-widest text-slate-500">
                  Live preview
                </p>
                <p className="mt-2 text-sm">
                  {project.deployment?.url ?? "Not yet deployed"}
                </p>
                {project.deployment?.status === "ready" && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-3"
                    onClick={() => window.open(project.deployment!.url, "_blank")}
                  >
                    Open in new tab
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Status bar */}
      <footer className="flex h-7 shrink-0 items-center gap-3 border-t border-slate-800 bg-[#0d1117] px-3 font-mono text-[10px] text-slate-400">
        <span className="flex items-center gap-1.5">
          <CircleDot
            className={cn(
              "h-2.5 w-2.5",
              hasDirty ? "text-amber-400" : "text-emerald-500"
            )}
          />
          {hasDirty ? "Unsaved changes" : "Saved"}
        </span>
        <span className="text-slate-600">|</span>
        <span>Branch: {project.repository?.defaultBranch ?? "main"}</span>
        <span className="text-slate-600">|</span>
        <span className="truncate">
          Last commit:{" "}
          {project.commits[0]
            ? `${project.commits[0].message.slice(0, 40)}${
                project.commits[0].message.length > 40 ? "…" : ""
              }`
            : "—"}
        </span>
        <span className="ml-auto hidden sm:inline">
          {project.repository?.organization}/{project.repository?.name}
        </span>
      </footer>

      {/* Sidebar toggle (desktop) */}
      <button
        onClick={() => setSidebarOpen((v) => !v)}
        aria-label={sidebarOpen ? "Hide file explorer" : "Show file explorer"}
        className="fixed left-2 top-14 z-30 hidden h-7 w-7 items-center justify-center rounded-md border border-border bg-background text-muted-foreground hover:bg-secondary md:flex"
      >
        {sidebarOpen ? (
          <PanelLeftClose className="h-3.5 w-3.5" />
        ) : (
          <PanelLeft className="h-3.5 w-3.5" />
        )}
      </button>

      {/* Commit dialog */}
      <CommitDialog
        key={`commit-${commitOpen ? "open" : "closed"}`}
        open={commitOpen}
        onClose={() => setCommitOpen(false)}
        onCommit={handleCommitAndDeploy}
        changedFiles={tabs.filter((t) => t.dirty).map((t) => t.path)}
        defaultMessage={`Update ${activeTab?.path ?? "files"}`}
      />

      {/* Deploy progress */}
      {deployVisible && (
        <DeployProgress
          deployment={project.deployment ?? null}
          savingFlow={{
            show: true,
            savingDone: savingState.savingDone,
            commitDone: savingState.commitDone,
          }}
          onClose={() => {
            setDeployVisible(false);
            // After deployment finishes, return to project detail
            if (project.deployment?.status === "ready") {
              push("project_detail", { projectId: project.id });
            }
          }}
        />
      )}

      {/* Create dialog */}
      <Dialog
        open={createDialog.open}
        onOpenChange={(v) => setCreateDialog({ ...createDialog, open: v })}
      >
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>
              New {createDialog.type === "file" ? "file" : "folder"}
            </DialogTitle>
            <DialogDescription>
              {createDialog.parentPath
                ? `Inside ${createDialog.parentPath}/`
                : "At project root"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <DLabel htmlFor="newitem">Name</DLabel>
            <DInput
              id="newitem"
              autoFocus
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleCreateItem();
              }}
              placeholder={
                createDialog.type === "file" ? "Component.tsx" : "components"
              }
            />
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setCreateDialog({ ...createDialog, open: false })}
            >
              Cancel
            </Button>
            <Button onClick={handleCreateItem}>Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rename dialog */}
      <Dialog
        open={renameDialog.open}
        onOpenChange={(v) => setRenameDialog({ ...renameDialog, open: v })}
      >
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Rename</DialogTitle>
            <DialogDescription>{renameDialog.path}</DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <DLabel htmlFor="rename">New name</DLabel>
            <DInput
              id="rename"
              autoFocus
              value={renameDialog.newName}
              onChange={(e) =>
                setRenameDialog({ ...renameDialog, newName: e.target.value })
              }
              onKeyDown={(e) => {
                if (e.key === "Enter") handleRenameItem();
              }}
            />
          </div>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setRenameDialog({ ...renameDialog, open: false })}
            >
              Cancel
            </Button>
            <Button onClick={handleRenameItem}>Rename</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete dialog */}
      <Dialog
        open={deleteDialog.open}
        onOpenChange={(v) => setDeleteDialog({ open: v, path: "" })}
      >
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete {deleteDialog.path}?</DialogTitle>
            <DialogDescription>
              This will remove the file from the repository. You can recreate
              it later.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setDeleteDialog({ open: false, path: "" })}
            >
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteItem}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
