"use client";

import { useMemo, useState } from "react";
import {
  ChevronRight,
  ChevronDown,
  Folder,
  FileText,
  FilePlus,
  FolderPlus,
  Search,
  Trash2,
  Pencil,
} from "lucide-react";
import type { ProjectFile } from "@/types/file";
import { buildFileTree, type TreeNode } from "@/lib/fileTree";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuTrigger,
} from "@/components/ui/context-menu";

interface FileExplorerProps {
  files: ProjectFile[];
  activePath?: string;
  onSelect: (path: string) => void;
  onCreateFile: (parentPath: string) => void;
  onCreateFolder: (parentPath: string) => void;
  onRename: (path: string) => void;
  onDelete: (path: string) => void;
}

export function FileExplorer({
  files,
  activePath,
  onSelect,
  onCreateFile,
  onCreateFolder,
  onRename,
  onDelete,
}: FileExplorerProps) {
  const [query, setQuery] = useState("");
  const tree = useMemo(() => {
    const filtered = query
      ? files.filter((f) =>
          f.path.toLowerCase().includes(query.toLowerCase())
        )
      : files;
    return buildFileTree(filtered);
  }, [files, query]);

  return (
    <div className="flex h-full flex-col bg-[#0d1117] text-slate-200">
      {/* Toolbar */}
      <div className="flex items-center gap-1 border-b border-slate-800 px-2 py-1.5">
        <span className="px-1 text-[10px] font-semibold uppercase tracking-widest text-slate-500">
          Explorer
        </span>
        <div className="ml-auto flex items-center gap-0.5">
          <button
            onClick={() => onCreateFile("")}
            title="New file"
            className="flex h-6 w-6 items-center justify-center rounded text-slate-400 hover:bg-slate-800 hover:text-slate-100"
          >
            <FilePlus className="h-3.5 w-3.5" />
          </button>
          <button
            onClick={() => onCreateFolder("")}
            title="New folder"
            className="flex h-6 w-6 items-center justify-center rounded text-slate-400 hover:bg-slate-800 hover:text-slate-100"
          >
            <FolderPlus className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="border-b border-slate-800 p-2">
        <div className="relative">
          <Search className="pointer-events-none absolute left-2 top-1/2 h-3 w-3 -translate-y-1/2 text-slate-500" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search files..."
            className="h-7 border-slate-700 bg-slate-900 pl-7 text-xs text-slate-200 placeholder:text-slate-500"
          />
        </div>
      </div>

      {/* Tree */}
      <div className="flex-1 overflow-y-auto scrollbar-thin py-1">
        {tree.length === 0 ? (
          <p className="px-3 py-4 text-xs text-slate-500">
            {query ? "No matching files." : "This project has no files."}
          </p>
        ) : (
          <ul>
            {tree.map((node) => (
              <TreeItem
                key={node.file.path}
                node={node}
                depth={0}
                activePath={activePath}
                onSelect={onSelect}
                onCreateFile={onCreateFile}
                onCreateFolder={onCreateFolder}
                onRename={onRename}
                onDelete={onDelete}
              />
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function TreeItem({
  node,
  depth,
  activePath,
  onSelect,
  onCreateFile,
  onCreateFolder,
  onRename,
  onDelete,
}: {
  node: TreeNode;
  depth: number;
  activePath?: string;
  onSelect: (path: string) => void;
  onCreateFile: (parentPath: string) => void;
  onCreateFolder: (parentPath: string) => void;
  onRename: (path: string) => void;
  onDelete: (path: string) => void;
}) {
  const [expanded, setExpanded] = useState(true);
  const isFolder = node.file.type === "folder";
  const active = node.file.path === activePath;

  const handleClick = () => {
    if (isFolder) {
      setExpanded((v) => !v);
    } else {
      onSelect(node.file.path);
    }
  };

  return (
    <li>
      <ContextMenu>
        <ContextMenuTrigger asChild>
          <button
            onClick={handleClick}
            className={cn(
              "flex w-full items-center gap-1 py-0.5 pr-2 text-left text-xs",
              active
                ? "bg-slate-800 text-slate-100"
                : "text-slate-300 hover:bg-slate-800/60"
            )}
            style={{ paddingLeft: `${depth * 12 + 8}px` }}
          >
            {isFolder ? (
              <>
                {expanded ? (
                  <ChevronDown className="h-3 w-3 shrink-0 text-slate-500" />
                ) : (
                  <ChevronRight className="h-3 w-3 shrink-0 text-slate-500" />
                )}
                <Folder className="h-3.5 w-3.5 shrink-0 text-sky-400" />
              </>
            ) : (
              <>
                <span className="w-3 shrink-0" />
                <FileText className="h-3.5 w-3.5 shrink-0 text-slate-400" />
              </>
            )}
            <span className="truncate">{node.file.name}</span>
          </button>
        </ContextMenuTrigger>
        <ContextMenuContent>
          {isFolder && (
            <>
              <ContextMenuItem onClick={() => onCreateFile(node.file.path)}>
                <FilePlus className="mr-2 h-3.5 w-3.5" />
                New file
              </ContextMenuItem>
              <ContextMenuItem onClick={() => onCreateFolder(node.file.path)}>
                <FolderPlus className="mr-2 h-3.5 w-3.5" />
                New folder
              </ContextMenuItem>
            </>
          )}
          <ContextMenuItem onClick={() => onRename(node.file.path)}>
            <Pencil className="mr-2 h-3.5 w-3.5" />
            Rename
          </ContextMenuItem>
          <ContextMenuItem
            onClick={() => onDelete(node.file.path)}
            className="text-rose-600 focus:text-rose-700"
          >
            <Trash2 className="mr-2 h-3.5 w-3.5" />
            Delete
          </ContextMenuItem>
        </ContextMenuContent>
      </ContextMenu>

      {isFolder && expanded && node.children.length > 0 && (
        <ul>
          {node.children.map((child) => (
            <TreeItem
              key={child.file.path}
              node={child}
              depth={depth + 1}
              activePath={activePath}
              onSelect={onSelect}
              onCreateFile={onCreateFile}
              onCreateFolder={onCreateFolder}
              onRename={onRename}
              onDelete={onDelete}
            />
          ))}
        </ul>
      )}
    </li>
  );
}
