/**
 * Realistic seed data for RPL Forge prototype.
 * This includes demo users and pre-built projects with realistic file trees
 * and source code, so the workspace editor and explore catalog feel alive.
 */

import type { User } from "@/types/user";
import type { Project } from "@/types/project";
import type { ProjectFile } from "@/types/file";
import type { Repository, Commit, Version } from "@/types/repository";
import type { Deployment } from "@/types/deployment";
import { detectLanguage } from "@/types/file";

export const DEMO_USERS: User[] = [
  {
    id: "user_andi",
    name: "Andi Pratama",
    username: "andi",
    email: "andi@rplforge.dev",
    bio: "Building things for the web. Loves clean UX and simple architectures.",
    classLevel: "5 Semester",
    generation: "2024",
    role: "student",
    skills: ["Web Development", "IoT", "JavaScript", "React", "Next.js"],
    createdAt: "2024-08-12T07:30:00.000Z",
  },
  {
    id: "user_budi",
    name: "Budi Santoso",
    username: "budi",
    email: "budi@rplforge.dev",
    bio: "Backend & systems tinkerer. Coffee-driven developer.",
    classLevel: "5 Semester",
    generation: "2024",
    role: "student",
    skills: ["Backend", "Node.js", "PostgreSQL", "DevOps"],
    createdAt: "2024-08-13T08:00:00.000Z",
  },
  {
    id: "user_citra",
    name: "Citra Lestari",
    username: "citra",
    email: "citra@rplforge.dev",
    bio: "Designer who codes. Currently obsessed with motion design.",
    classLevel: "3 Semester",
    generation: "2025",
    role: "student",
    skills: ["UI/UX", "React", "Tailwind", "Framer Motion"],
    createdAt: "2025-02-04T03:15:00.000Z",
  },
  {
    id: "user_deni",
    name: "Deni Wahyudi",
    username: "deni",
    email: "deni@rplforge.dev",
    bio: "AI/ML student. Tensorflow, PyTorch, and a lot of notebooks.",
    classLevel: "7 Semester",
    generation: "2023",
    role: "student",
    skills: ["AI", "Python", "TensorFlow", "FastAPI"],
    createdAt: "2023-09-22T01:00:00.000Z",
  },
];

/* ----------------------------------------------------------------- */
/* File helpers                                                      */
/* ----------------------------------------------------------------- */

function file(
  projectId: string,
  path: string,
  content = "",
  type: "file" | "folder" = "file"
): ProjectFile {
  const name = path.split("/").filter(Boolean).pop() ?? path;
  return {
    id: `${projectId}:${path}`,
    projectId,
    path,
    name,
    type,
    content: type === "file" ? content : undefined,
    language: type === "file" ? detectLanguage(name) : undefined,
    size: type === "file" ? content.length : undefined,
  };
}

function folder(projectId: string, path: string): ProjectFile {
  return file(projectId, path, "", "folder");
}

/* ----------------------------------------------------------------- */
/* Sample source code                                                */
/* ----------------------------------------------------------------- */

const SMART_ATTENDANCE_PAGE_TSX = `import { Navbar } from "@/components/Navbar";
import { AttendanceCard } from "@/components/AttendanceCard";
import { StatsCard } from "@/components/StatsCard";

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-50">
      <Navbar />
      <section className="mx-auto max-w-6xl px-6 py-12">
        <h1 className="text-4xl font-bold tracking-tight text-slate-900">
          Smart Attendance
        </h1>
        <p className="mt-2 text-slate-600">
          A student attendance platform powered by ESP32 + facial recognition.
        </p>

        <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-3">
          <StatsCard label="Present" value={32} />
          <StatsCard label="Absent" value={4} />
          <StatsCard label="Late" value={2} />
        </div>

        <div className="mt-10 grid gap-4 md:grid-cols-2">
          <AttendanceCard name="Andi Pratama" status="present" time="07:55" />
          <AttendanceCard name="Budi Santoso" status="late" time="08:05" />
          <AttendanceCard name="Citra Lestari" status="present" time="07:58" />
          <AttendanceCard name="Deni Wahyudi" status="absent" time="-" />
        </div>
      </section>
    </main>
  );
}
`;

const SMART_ATTENDANCE_NAVBAR_TSX = `export function Navbar() {
  return (
    <header className="border-b bg-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <div className="flex items-center gap-2">
          <span className="h-8 w-8 rounded-md bg-slate-900" />
          <span className="font-semibold">Smart Attendance</span>
        </div>
        <nav className="flex items-center gap-6 text-sm text-slate-600">
          <a href="#">Dashboard</a>
          <a href="#">Students</a>
          <a href="#">Reports</a>
          <button className="rounded-md bg-slate-900 px-3 py-1.5 text-white">
            Sign Out
          </button>
        </nav>
      </div>
    </header>
  );
}
`;

const SMART_ATTENDANCE_CARD_TSX = `interface AttendanceCardProps {
  name: string;
  status: "present" | "absent" | "late";
  time: string;
}

const STATUS_STYLES = {
  present: "bg-emerald-500/10 text-emerald-600",
  absent: "bg-rose-500/10 text-rose-600",
  late: "bg-amber-500/10 text-amber-600",
};

export function AttendanceCard({ name, status, time }: AttendanceCardProps) {
  return (
    <div className="rounded-xl border bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <p className="font-medium">{name}</p>
        <span className={\`rounded-full px-2 py-0.5 text-xs \${STATUS_STYLES[status]}\`}>
          {status}
        </span>
      </div>
      <p className="mt-2 text-sm text-slate-500">Checked in at {time}</p>
    </div>
  );
}
`;

const SMART_ATTENDANCE_STATS_TSX = `interface StatsCardProps {
  label: string;
  value: number;
}

export function StatsCard({ label, value }: StatsCardProps) {
  return (
    <div className="rounded-xl border bg-white p-4">
      <p className="text-sm text-slate-500">{label}</p>
      <p className="mt-1 text-3xl font-semibold">{value}</p>
    </div>
  );
}
`;

const SMART_ATTENDANCE_LAYOUT_TSX = `import "./globals.css";

export const metadata = {
  title: "Smart Attendance",
  description: "Student attendance platform",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
`;

const SMART_ATTENDANCE_UTILS_TS = `export function cn(...classes: (string | undefined | false)[]) {
  return classes.filter(Boolean).join(" ");
}

export function formatDate(date: Date) {
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(date);
}
`;

const SMART_ATTENDANCE_PACKAGE_JSON = `{
  "name": "smart-attendance",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "next": "^15.0.0",
    "react": "^19.0.0",
    "react-dom": "^19.0.0"
  },
  "devDependencies": {
    "@types/node": "^22.0.0",
    "@types/react": "^19.0.0",
    "typescript": "^5.0.0"
  }
}
`;

const SMART_ATTENDANCE_README = `# Smart Attendance

A student attendance platform that uses ESP32 + face recognition to automatically mark attendance.

## Features

- Real-time attendance dashboard
- ESP32 device integration
- Face recognition powered by TensorFlow.js
- Weekly attendance reports

## Tech Stack

- Next.js 15
- Firebase (Auth + Firestore)
- ESP32 firmware (C++)
- TensorFlow.js

## Run Locally

\`\`\`bash
npm install
npm run dev
\`\`\`

Open http://localhost:3000
`;

const SMART_ATTENDANCE_TSCONFIG = `{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [{ "name": "next" }]
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx"],
  "exclude": ["node_modules"]
}
`;

const SMART_ATTENDANCE_LOGO_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none">
  <rect width="64" height="64" rx="12" fill="#0f172a"/>
  <path d="M20 32 L28 40 L44 24" stroke="#10b981" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
`;

/* ----------------------------------------------------------------- */
/* Build file trees                                                  */
/* ----------------------------------------------------------------- */

export function buildSmartAttendanceFiles(projectId: string): ProjectFile[] {
  const f = (path: string, content = "") => file(projectId, path, content);
  const d = (path: string) => folder(projectId, path);
  return [
    d("src"),
    d("src/app"),
    f("src/app/page.tsx", SMART_ATTENDANCE_PAGE_TSX),
    f("src/app/layout.tsx", SMART_ATTENDANCE_LAYOUT_TSX),
    d("src/components"),
    f("src/components/Navbar.tsx", SMART_ATTENDANCE_NAVBAR_TSX),
    f("src/components/AttendanceCard.tsx", SMART_ATTENDANCE_CARD_TSX),
    f("src/components/StatsCard.tsx", SMART_ATTENDANCE_STATS_TSX),
    d("src/lib"),
    f("src/lib/utils.ts", SMART_ATTENDANCE_UTILS_TS),
    d("public"),
    f("public/logo.svg", SMART_ATTENDANCE_LOGO_SVG),
    f("package.json", SMART_ATTENDANCE_PACKAGE_JSON),
    f("README.md", SMART_ATTENDANCE_README),
    f("tsconfig.json", SMART_ATTENDANCE_TSCONFIG),
  ];
}

/* Library System files ---------------------------------------------------- */

const LIBRARY_PAGE_TSX = `import { BookList } from "@/components/BookList";

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-50 p-6">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">School Library System</h1>
        <p className="text-slate-600">Browse, borrow, and return books.</p>
      </header>
      <BookList />
    </main>
  );
}
`;

const LIBRARY_BOOKLIST_TSX = `"use client";
import { useState } from "react";

const BOOKS = [
  { id: 1, title: "Clean Code", author: "Robert C. Martin", available: true },
  { id: 2, title: "The Pragmatic Programmer", author: "Hunt & Thomas", available: false },
  { id: 3, title: "Refactoring", author: "Martin Fowler", available: true },
];

export function BookList() {
  const [borrowed, setBorrowed] = useState<number[]>([]);
  return (
    <ul className="grid gap-3 md:grid-cols-2">
      {BOOKS.map((book) => (
        <li
          key={book.id}
          className="flex items-center justify-between rounded-lg border bg-white p-4"
        >
          <div>
            <p className="font-medium">{book.title}</p>
            <p className="text-sm text-slate-500">{book.author}</p>
          </div>
          <button
            disabled={!book.available || borrowed.includes(book.id)}
            onClick={() => setBorrowed((b) => [...b, book.id])}
            className="rounded-md bg-slate-900 px-3 py-1.5 text-sm text-white disabled:opacity-40"
          >
            {borrowed.includes(book.id) ? "Borrowed" : "Borrow"}
          </button>
        </li>
      ))}
    </ul>
  );
}
`;

const LIBRARY_PACKAGE_JSON = `{
  "name": "library-system",
  "version": "2.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build"
  },
  "dependencies": {
    "next": "^15.0.0",
    "react": "^19.0.0"
  }
}
`;

const LIBRARY_README = `# School Library System

A modern library management system for schools.

## Features
- Book catalog
- Borrow/return tracking
- Student accounts
- Overdue notifications

## Stack
- Next.js + TypeScript
- Firebase Firestore
- Tailwind CSS
`;

export function buildLibraryFiles(projectId: string): ProjectFile[] {
  const f = (path: string, content = "") => file(projectId, path, content);
  const d = (path: string) => folder(projectId, path);
  return [
    d("src"),
    d("src/app"),
    f("src/app/page.tsx", LIBRARY_PAGE_TSX),
    d("src/components"),
    f("src/components/BookList.tsx", LIBRARY_BOOKLIST_TSX),
    f("package.json", LIBRARY_PACKAGE_JSON),
    f("README.md", LIBRARY_README),
  ];
}

/* IoT Monitor files ------------------------------------------------------- */

const IOT_PAGE_TSX = `import { SensorChart } from "@/components/SensorChart";

const SENSORS = [
  { id: "temp-lab", label: "Lab Temperature", unit: "°C" },
  { id: "humid-lab", label: "Lab Humidity", unit: "%" },
  { id: "temp-class", label: "Classroom Temperature", unit: "°C" },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-950 p-6 text-slate-100">
      <h1 className="text-3xl font-bold">IoT Temperature Monitor</h1>
      <div className="mt-8 grid gap-4 md:grid-cols-3">
        {SENSORS.map((s) => (
          <SensorChart key={s.id} sensor={s} />
        ))}
      </div>
    </main>
  );
}
`;

const IOT_CHART_TSX = `"use client";
import { useEffect, useState } from "react";

export function SensorChart({ sensor }: { sensor: { id: string; label: string; unit: string } }) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    const i = setInterval(() => setValue(Math.random() * 40), 2000);
    return () => clearInterval(i);
  }, []);
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900 p-4">
      <p className="text-sm text-slate-400">{sensor.label}</p>
      <p className="mt-1 text-3xl font-semibold">
        {value.toFixed(1)} <span className="text-base text-slate-500">{sensor.unit}</span>
      </p>
    </div>
  );
}
`;

const IOT_FIRMWARE_PY = `"""
ESP32 firmware: read DHT22 sensor and post to API.
"""
import machine
import network
import urequests
import dht
import time

SENSOR = dht.DHT22(machine.Pin(4))
API_URL = "https://api.rplforge.local/iot/ingest"

def connect_wifi(ssid: str, password: str) -> None:
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.connect(ssid, password)
    while not wlan.isconnected():
        time.sleep(0.5)

def read_and_send() -> None:
    SENSOR.measure()
    payload = {
        "temperature": SENSOR.temperature(),
        "humidity": SENSOR.humidity(),
    }
    urequests.post(API_URL, json=payload)

def main() -> None:
    connect_wifi("RPLForge", "forge-secret")
    while True:
        try:
            read_and_send()
        except Exception as exc:
            print("sensor error:", exc)
        time.sleep(5)

if __name__ == "__main__":
    main()
`;

const IOT_README = `# IoT Temperature Monitor

Distributed temperature monitoring using ESP32 + DHT22 sensors, with a real-time Next.js dashboard.

## Hardware
- 3× ESP32 dev boards
- 3× DHT22 temperature/humidity sensors

## Software
- Next.js dashboard
- FastAPI ingestion endpoint
- MicroPython firmware on the ESP32

## Setup
1. Flash firmware to each ESP32 (edit WiFi credentials first).
2. Run the API: \`uvicorn api.main:app\`
3. Run the dashboard: \`npm run dev\`
`;

export function buildIotFiles(projectId: string): ProjectFile[] {
  const f = (path: string, content = "") => file(projectId, path, content);
  const d = (path: string) => folder(projectId, path);
  return [
    d("src"),
    d("src/app"),
    f("src/app/page.tsx", IOT_PAGE_TSX),
    d("src/components"),
    f("src/components/SensorChart.tsx", IOT_CHART_TSX),
    d("firmware"),
    f("firmware/main.py", IOT_FIRMWARE_PY),
    f("README.md", IOT_README),
  ];
}

/* AI Study Assistant files ----------------------------------------------- */

const AI_PAGE_TSX = `import { ChatBox } from "@/components/ChatBox";

export default function Home() {
  return (
    <main className="mx-auto max-w-3xl p-6">
      <h1 className="text-2xl font-bold">AI Study Assistant</h1>
      <p className="text-slate-600">Ask me anything about your course material.</p>
      <ChatBox />
    </main>
  );
}
`;

const AI_CHATBOX_TSX = `"use client";
import { useState } from "react";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const SAMPLE_REPLIES = [
  "Great question! Let's break it down step by step.",
  "Based on the textbook, the answer involves three key concepts...",
  "Here's a study tip: try to summarize the topic in your own words.",
];

export function ChatBox() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hi! What would you like to learn today?" },
  ]);
  const [input, setInput] = useState("");

  const send = () => {
    if (!input.trim()) return;
    const reply = SAMPLE_REPLIES[Math.floor(Math.random() * SAMPLE_REPLIES.length)];
    setMessages((m) => [
      ...m,
      { role: "user", content: input },
      { role: "assistant", content: reply },
    ]);
    setInput("");
  };

  return (
    <div className="mt-6 rounded-xl border">
      <div className="h-80 space-y-3 overflow-y-auto p-4">
        {messages.map((m, i) => (
          <div
            key={i}
            className={m.role === "user" ? "text-right" : "text-left"}
          >
            <span className={\`inline-block rounded-lg px-3 py-2 \${
              m.role === "user" ? "bg-slate-900 text-white" : "bg-slate-100"
            }\`}>{m.content}</span>
          </div>
        ))}
      </div>
      <div className="flex gap-2 border-t p-3">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Ask a question..."
          className="flex-1 rounded-md border px-3 py-2"
        />
        <button onClick={send} className="rounded-md bg-slate-900 px-4 py-2 text-white">
          Send
        </button>
      </div>
    </div>
  );
}
`;

const AI_BACKEND_PY = `"""
FastAPI backend that proxies requests to the LLM and tracks study sessions.
"""
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="AI Study Assistant API")

class AskRequest(BaseModel):
    question: str
    context: str | None = None

@app.post("/api/ask")
async def ask(req: AskRequest) -> dict:
    # In production this would call an LLM. For the prototype we echo.
    return {
        "answer": f"You asked: {req.question}. (LLM not wired in prototype.)",
        "tokens": 0,
    }
`;

const AI_README = `# AI Study Assistant

An AI-powered study companion that answers questions based on course material.

## Features
- Chat interface
- Course material context
- Study session tracking
- Quiz generation (planned)

## Stack
- Next.js frontend
- FastAPI backend
- OpenAI API (planned for production)
`;

export function buildAiStudyFiles(projectId: string): ProjectFile[] {
  const f = (path: string, content = "") => file(projectId, path, content);
  const d = (path: string) => folder(projectId, path);
  return [
    d("src"),
    d("src/app"),
    f("src/app/page.tsx", AI_PAGE_TSX),
    d("src/components"),
    f("src/components/ChatBox.tsx", AI_CHATBOX_TSX),
    d("backend"),
    f("backend/main.py", AI_BACKEND_PY),
    f("README.md", AI_README),
  ];
}

/* Portfolio files --------------------------------------------------------- */

const PORTFOLIO_PAGE_TSX = `export default function Home() {
  return (
    <main className="min-h-screen bg-white text-slate-900">
      <section className="mx-auto max-w-3xl px-6 py-24">
        <p className="text-sm uppercase tracking-widest text-slate-500">Hello, I am</p>
        <h1 className="mt-2 text-5xl font-bold tracking-tight">Citra Lestari.</h1>
        <p className="mt-4 text-lg text-slate-600">
          UI/UX design student who codes. Currently obsessed with motion design
          and accessible interfaces.
        </p>
        <div className="mt-8 flex gap-3">
          <a className="rounded-full bg-slate-900 px-5 py-2 text-white" href="#work">See my work</a>
          <a className="rounded-full border px-5 py-2" href="#contact">Contact</a>
        </div>
      </section>
    </main>
  );
}
`;

const PORTFOLIO_README = `# Student Portfolio

A simple, fast portfolio site built with Next.js.

## Stack
- Next.js (App Router)
- Tailwind CSS
- Framer Motion (planned)

## Deploy
\`npm run build && npm start\`
`;

export function buildPortfolioFiles(projectId: string): ProjectFile[] {
  const f = (path: string, content = "") => file(projectId, path, content);
  const d = (path: string) => folder(projectId, path);
  return [
    d("src"),
    d("src/app"),
    f("src/app/page.tsx", PORTFOLIO_PAGE_TSX),
    f("README.md", PORTFOLIO_README),
  ];
}

/* Event Platform files ---------------------------------------------------- */

const EVENT_PAGE_TSX = `import { EventCard } from "@/components/EventCard";

const EVENTS = [
  { id: 1, title: "Hackathon 2026", date: "2026-03-12", attendees: 124 },
  { id: 2, title: "Design Workshop", date: "2026-03-20", attendees: 32 },
  { id: 3, title: "Career Fair", date: "2026-04-05", attendees: 480 },
];

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-50 p-8">
      <h1 className="text-3xl font-bold">School Events</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {EVENTS.map((e) => <EventCard key={e.id} event={e} />)}
      </div>
    </main>
  );
}
`;

const EVENT_CARD_TSX = `interface EventCardProps {
  event: { id: number; title: string; date: string; attendees: number };
}

export function EventCard({ event }: EventCardProps) {
  return (
    <article className="rounded-xl border bg-white p-4 shadow-sm">
      <p className="text-xs uppercase text-slate-500">{event.date}</p>
      <h2 className="mt-1 text-lg font-semibold">{event.title}</h2>
      <p className="mt-2 text-sm text-slate-600">{event.attendees} attending</p>
      <button className="mt-4 w-full rounded-md border px-3 py-1.5 text-sm">RSVP</button>
    </article>
  );
}
`;

const EVENT_README = `# School Event Platform

Discover and RSVP to school events.

## Features
- Event listing
- RSVP system
- Calendar export
- Notifications
`;

export function buildEventFiles(projectId: string): ProjectFile[] {
  const f = (path: string, content = "") => file(projectId, path, content);
  const d = (path: string) => folder(projectId, path);
  return [
    d("src"),
    d("src/app"),
    f("src/app/page.tsx", EVENT_PAGE_TSX),
    d("src/components"),
    f("src/components/EventCard.tsx", EVENT_CARD_TSX),
    f("README.md", EVENT_README),
  ];
}

/* ----------------------------------------------------------------- */
/* Build seed projects                                               */
/* ----------------------------------------------------------------- */

function makeRepository(projectId: string, slug: string): Repository {
  return {
    id: `repo_${projectId}`,
    name: `rplforge-${slug}`,
    organization: "rpl-forge",
    url: `https://github.com/rpl-forge/rplforge-${slug}`,
    defaultBranch: "main",
    createdAt: new Date().toISOString(),
  };
}

function makeDeployment(
  projectId: string,
  slug: string,
  status: Deployment["status"],
  version = "v1.0.0"
): Deployment {
  return {
    id: `dep_${projectId}`,
    projectId,
    status,
    url: `https://${slug}.rplforge.local`,
    version,
    logs:
      status === "ready"
        ? [
            { id: "l1", message: "Installing dependencies...", level: "info", timestamp: new Date().toISOString() },
            { id: "l2", message: "Running build...", level: "info", timestamp: new Date().toISOString() },
            { id: "l3", message: "Compiling application...", level: "info", timestamp: new Date().toISOString() },
            { id: "l4", message: "Generating pages...", level: "info", timestamp: new Date().toISOString() },
            { id: "l5", message: "Optimizing assets...", level: "info", timestamp: new Date().toISOString() },
            { id: "l6", message: "Deployment completed.", level: "success", timestamp: new Date().toISOString() },
          ]
        : status === "failed"
        ? [
            { id: "l1", message: "Installing dependencies...", level: "info", timestamp: new Date().toISOString() },
            { id: "l2", message: "Running build...", level: "info", timestamp: new Date().toISOString() },
            { id: "l3", message: "Build failed. Error: Module not found: @/components/MissingButton", level: "error", timestamp: new Date().toISOString() },
          ]
        : [
            { id: "l1", message: "Queued for build...", level: "info", timestamp: new Date().toISOString() },
          ],
    startedAt: new Date().toISOString(),
    finishedAt: status === "ready" || status === "failed" ? new Date().toISOString() : undefined,
    error: status === "failed" ? "Build failed. Module not found: @/components/MissingButton" : undefined,
  };
}

function makeInitialCommit(projectId: string, ownerId: string): Commit {
  return {
    id: `commit_${projectId}_initial`,
    projectId,
    message: "Initial upload",
    authorId: ownerId,
    changedFiles: ["(all files)"],
    createdAt: new Date().toISOString(),
  };
}

function makeInitialVersion(commitId: string, authorId: string): Version {
  return {
    id: `ver_${commitId}`,
    tag: "v1.0.0",
    label: "Initial upload",
    authorId,
    commitId,
    createdAt: new Date().toISOString(),
  };
}

export function buildSeedProjects(): Project[] {
  const now = new Date();
  const iso = now.toISOString();

  const projects: Project[] = [
    {
      id: "proj_smart_attendance",
      name: "Smart Attendance",
      slug: "smart-attendance",
      description:
        "A student attendance platform powered by ESP32 + face recognition. Built for the RPL capstone project.",
      ownerId: "user_andi",
      category: "Web Application",
      technologies: ["Next.js", "Firebase", "ESP32", "TypeScript"],
      visibility: "public",
      status: "live",
      files: buildSmartAttendanceFiles("proj_smart_attendance"),
      members: [
        { userId: "user_andi", role: "owner", addedAt: iso },
        { userId: "user_budi", role: "editor", addedAt: iso },
      ],
      screenshots: [],
      createdAt: "2025-09-12T03:30:00.000Z",
      updatedAt: iso,
    },
    {
      id: "proj_library_system",
      name: "School Library System",
      slug: "library-system",
      description:
        "A modern library management system for the school library. Tracks books, borrowers, and overdue returns.",
      ownerId: "user_budi",
      category: "Web Application",
      technologies: ["Next.js", "Firebase", "Tailwind CSS"],
      visibility: "public",
      status: "live",
      files: buildLibraryFiles("proj_library_system"),
      members: [{ userId: "user_budi", role: "owner", addedAt: iso }],
      screenshots: [],
      createdAt: "2025-08-22T01:00:00.000Z",
      updatedAt: "2025-12-01T10:00:00.000Z",
    },
    {
      id: "proj_iot_monitor",
      name: "IoT Temperature Monitor",
      slug: "iot-temperature-monitor",
      description:
        "Distributed temperature monitoring using ESP32 + DHT22 sensors with a real-time Next.js dashboard.",
      ownerId: "user_andi",
      category: "IoT System",
      technologies: ["Next.js", "ESP32", "Python", "FastAPI"],
      visibility: "public",
      status: "live",
      files: buildIotFiles("proj_iot_monitor"),
      members: [
        { userId: "user_andi", role: "owner", addedAt: iso },
        { userId: "user_deni", role: "viewer", addedAt: iso },
      ],
      screenshots: [],
      createdAt: "2025-10-04T02:00:00.000Z",
      updatedAt: iso,
    },
    {
      id: "proj_ai_study",
      name: "AI Study Assistant",
      slug: "ai-study-assistant",
      description:
        "An AI-powered study companion that answers questions based on course material.",
      ownerId: "user_deni",
      category: "AI / Machine Learning",
      technologies: ["Next.js", "Python", "FastAPI", "TensorFlow"],
      visibility: "public",
      status: "deploying",
      files: buildAiStudyFiles("proj_ai_study"),
      members: [{ userId: "user_deni", role: "owner", addedAt: iso }],
      screenshots: [],
      createdAt: "2026-01-15T04:00:00.000Z",
      updatedAt: iso,
    },
    {
      id: "proj_portfolio",
      name: "Student Portfolio",
      slug: "student-portfolio",
      description:
        "A simple, fast portfolio site built with Next.js. Showcases projects and design work.",
      ownerId: "user_citra",
      category: "Web Application",
      technologies: ["Next.js", "Tailwind CSS"],
      visibility: "public",
      status: "live",
      files: buildPortfolioFiles("proj_portfolio"),
      members: [{ userId: "user_citra", role: "owner", addedAt: iso }],
      screenshots: [],
      createdAt: "2026-02-01T03:00:00.000Z",
      updatedAt: iso,
    },
    {
      id: "proj_event_platform",
      name: "School Event Platform",
      slug: "school-event-platform",
      description:
        "Discover and RSVP to school events. Calendar integration and notifications planned.",
      ownerId: "user_citra",
      category: "Web Application",
      technologies: ["Next.js", "Firebase"],
      visibility: "public",
      status: "failed",
      files: buildEventFiles("proj_event_platform"),
      members: [{ userId: "user_citra", role: "owner", addedAt: iso }],
      screenshots: [],
      createdAt: "2026-02-20T06:00:00.000Z",
      updatedAt: iso,
    },
  ];

  // Attach repository, deployment, commits, versions
  for (const p of projects) {
    p.repository = makeRepository(p.id, p.slug);
    const initialCommit = makeInitialCommit(p.id, p.ownerId);
    p.commits = [initialCommit];
    p.versions = [makeInitialVersion(initialCommit.id, p.ownerId)];
    if (p.id === "proj_ai_study") {
      p.deployment = makeDeployment(p.id, p.slug, "deploying", "v1.0.0");
    } else if (p.id === "proj_event_platform") {
      p.deployment = makeDeployment(p.id, p.slug, "failed", "v1.0.0");
    } else {
      p.deployment = makeDeployment(p.id, p.slug, "ready", "v1.0.0");
    }
  }

  return projects;
}

export interface ActivityEntry {
  id: string;
  type: "create" | "deploy" | "update" | "delete" | "commit";
  userId: string;
  projectId: string;
  message: string;
  timestamp: string;
}

export function buildSeedActivity(): ActivityEntry[] {
  const now = Date.now();
  return [
    {
      id: "act_1",
      type: "create",
      userId: "user_andi",
      projectId: "proj_smart_attendance",
      message: "Andi created Smart Attendance",
      timestamp: new Date(now - 1000 * 60 * 12).toISOString(),
    },
    {
      id: "act_2",
      type: "deploy",
      userId: "user_budi",
      projectId: "proj_library_system",
      message: "Budi deployed Library System",
      timestamp: new Date(now - 1000 * 60 * 60 * 2).toISOString(),
    },
    {
      id: "act_3",
      type: "update",
      userId: "user_citra",
      projectId: "proj_iot_monitor",
      message: "Citra updated IoT Monitor",
      timestamp: new Date(now - 1000 * 60 * 60 * 5).toISOString(),
    },
    {
      id: "act_4",
      type: "commit",
      userId: "user_deni",
      projectId: "proj_ai_study",
      message: "Deni committed to AI Study Assistant",
      timestamp: new Date(now - 1000 * 60 * 60 * 8).toISOString(),
    },
    {
      id: "act_5",
      type: "create",
      userId: "user_citra",
      projectId: "proj_portfolio",
      message: "Citra created Student Portfolio",
      timestamp: new Date(now - 1000 * 60 * 60 * 24).toISOString(),
    },
  ];
}
