import type { RepositoryService } from "./repositoryService";
import type {
  Commit,
  CreateFileInput,
  DeleteFileInput,
  RenameFileInput,
  Repository,
  UpdateFileInput,
} from "@/types/repository";
import type { ProjectFile } from "@/types/file";
import { detectLanguage } from "@/types/file";
import { projectRepository } from "./mockProjectService";

function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

export class MockRepositoryService implements RepositoryService {
  async createRepository(input: {
    name: string;
    organization?: string;
    defaultBranch?: string;
  }): Promise<Repository> {
    await new Promise((r) => setTimeout(r, 400));
    return {
      id: generateId("repo"),
      name: input.name,
      organization: input.organization ?? "rpl-forge",
      url: `https://github.com/${input.organization ?? "rpl-forge"}/${input.name}`,
      defaultBranch: input.defaultBranch ?? "main",
      createdAt: new Date().toISOString(),
    };
  }

  async getRepository(id: string): Promise<Repository> {
    await new Promise((r) => setTimeout(r, 100));
    // Repository is stored on the project — find by projectId
    const all = await projectRepository.listAll();
    const project = all.find((p) => p.repository?.id === id);
    if (!project?.repository) throw new Error("Repository not found");
    return project.repository;
  }

  async getFiles(repositoryId: string): Promise<ProjectFile[]> {
    await new Promise((r) => setTimeout(r, 150));
    const all = await projectRepository.listAll();
    const project = all.find((p) => p.repository?.id === repositoryId);
    return project?.files ?? [];
  }

  async getFile(repositoryId: string, path: string): Promise<ProjectFile | null> {
    const files = await this.getFiles(repositoryId);
    return files.find((f) => f.path === path) ?? null;
  }

  async updateFile(input: UpdateFileInput): Promise<Commit> {
    await new Promise((r) => setTimeout(r, 250));
    const all = await projectRepository.listAll();
    const project = all.find((p) => p.repository?.id === input.repositoryId);
    if (!project) throw new Error("Project not found");

    const files = project.files.map((f) =>
      f.path === input.path
        ? { ...f, content: input.content, size: input.content.length }
        : f
    );
    await projectRepository.setFiles(project.id, files);

    const commit: Commit = {
      id: generateId("commit"),
      projectId: project.id,
      message: input.message ?? `Update ${input.path}`,
      authorId: input.authorId,
      changedFiles: [input.path],
      createdAt: new Date().toISOString(),
    };
    const commits = [commit, ...project.commits];
    await projectRepository.update(project.id, { commits });
    return commit;
  }

  async createFile(input: CreateFileInput): Promise<Commit> {
    await new Promise((r) => setTimeout(r, 200));
    const all = await projectRepository.listAll();
    const project = all.find((p) => p.repository?.id === input.repositoryId);
    if (!project) throw new Error("Project not found");

    const name = input.path.split("/").filter(Boolean).pop() ?? input.path;
    const newFile: ProjectFile = {
      id: `${project.id}:${input.path}`,
      projectId: project.id,
      path: input.path,
      name,
      type: input.type,
      language: input.type === "file" ? detectLanguage(name) : undefined,
      content: input.type === "file" ? (input.content ?? "") : undefined,
      size: input.type === "file" ? (input.content ?? "").length : undefined,
    };
    const files = [...project.files.filter((f) => f.path !== input.path), newFile];
    await projectRepository.setFiles(project.id, files);

    const commit: Commit = {
      id: generateId("commit"),
      projectId: project.id,
      message: `Create ${input.path}`,
      authorId: input.authorId,
      changedFiles: [input.path],
      createdAt: new Date().toISOString(),
    };
    const commits = [commit, ...project.commits];
    await projectRepository.update(project.id, { commits });
    return commit;
  }

  async deleteFile(input: DeleteFileInput): Promise<Commit> {
    await new Promise((r) => setTimeout(r, 200));
    const all = await projectRepository.listAll();
    const project = all.find((p) => p.repository?.id === input.repositoryId);
    if (!project) throw new Error("Project not found");

    // Remove the file and any descendants (if folder)
    const files = project.files.filter(
      (f) => f.path !== input.path && !f.path.startsWith(`${input.path}/`)
    );
    await projectRepository.setFiles(project.id, files);

    const commit: Commit = {
      id: generateId("commit"),
      projectId: project.id,
      message: `Delete ${input.path}`,
      authorId: input.authorId,
      changedFiles: [input.path],
      createdAt: new Date().toISOString(),
    };
    const commits = [commit, ...project.commits];
    await projectRepository.update(project.id, { commits });
    return commit;
  }

  async renameFile(input: RenameFileInput): Promise<Commit> {
    await new Promise((r) => setTimeout(r, 200));
    const all = await projectRepository.listAll();
    const project = all.find((p) => p.repository?.id === input.repositoryId);
    if (!project) throw new Error("Project not found");

    const files = project.files.map((f) => {
      if (f.path === input.oldPath) {
        const name = input.newPath.split("/").filter(Boolean).pop() ?? input.newPath;
        return { ...f, path: input.newPath, name, language: detectLanguage(name) };
      }
      if (f.path.startsWith(`${input.oldPath}/`)) {
        const newPath = `${input.newPath}/${f.path.slice(input.oldPath.length + 1)}`;
        return { ...f, path: newPath };
      }
      return f;
    });
    await projectRepository.setFiles(project.id, files);

    const commit: Commit = {
      id: generateId("commit"),
      projectId: project.id,
      message: `Rename ${input.oldPath} → ${input.newPath}`,
      authorId: input.authorId,
      changedFiles: [input.oldPath, input.newPath],
      createdAt: new Date().toISOString(),
    };
    const commits = [commit, ...project.commits];
    await projectRepository.update(project.id, { commits });
    return commit;
  }

  async getCommits(repositoryId: string): Promise<Commit[]> {
    const all = await projectRepository.listAll();
    const project = all.find((p) => p.repository?.id === repositoryId);
    return project?.commits ?? [];
  }
}

export const repositoryService: RepositoryService = new MockRepositoryService();
