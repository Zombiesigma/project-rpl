import type { AuthService, AuthSession } from "./authService";
import { AuthError } from "./authService";
import type { User } from "@/types/user";
import { storage, STORAGE_KEYS } from "@/lib/storage";
import { DEMO_USERS } from "@/mock/seed";

const TOKEN_PREFIX = "rplforge.mock.token.";

function makeSession(user: User): AuthSession {
  return {
    user,
    token: `${TOKEN_PREFIX}${user.id}.${Date.now()}`,
    expiresAt: Date.now() + 1000 * 60 * 60 * 24 * 7, // 7 days
  };
}

export class MockAuthService implements AuthService {
  async listDemoUsers(): Promise<User[]> {
    return DEMO_USERS;
  }

  async signIn(email: string, password: string): Promise<AuthSession> {
    await new Promise((r) => setTimeout(r, 350));
    const user = DEMO_USERS.find((u) => u.email === email.toLowerCase());
    if (!user) {
      throw new AuthError("No account found with that email. Try a demo user.");
    }
    if (!password || password.length < 4) {
      throw new AuthError("Password must be at least 4 characters.");
    }
    const session = makeSession(user);
    storage.set(STORAGE_KEYS.auth, session);
    return session;
  }

  async signInWithGoogle(): Promise<AuthSession> {
    await new Promise((r) => setTimeout(r, 600));
    // Pretend Google returned the first demo user
    const user = DEMO_USERS[0];
    const session = makeSession(user);
    storage.set(STORAGE_KEYS.auth, session);
    return session;
  }

  async signInAs(userId: string): Promise<AuthSession> {
    await new Promise((r) => setTimeout(r, 200));
    const user = DEMO_USERS.find((u) => u.id === userId);
    if (!user) throw new AuthError("Unknown demo user.");
    const session = makeSession(user);
    storage.set(STORAGE_KEYS.auth, session);
    return session;
  }

  async signOut(): Promise<void> {
    storage.remove(STORAGE_KEYS.auth);
  }

  async getCurrentSession(): Promise<AuthSession | null> {
    const session = storage.get<AuthSession | null>(STORAGE_KEYS.auth, null);
    if (!session) return null;
    if (session.expiresAt < Date.now()) {
      storage.remove(STORAGE_KEYS.auth);
      return null;
    }
    return session;
  }
}

export const authService: AuthService = new MockAuthService();
