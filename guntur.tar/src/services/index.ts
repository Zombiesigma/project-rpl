export { authService, MockAuthService, type AuthService, type AuthSession, AuthError } from "./authService";
export { authService as defaultAuthService } from "./mockAuthService";

export { projectRepository, logActivity, readActivity, LocalProjectRepository, type ProjectRepository, ProjectRepositoryError } from "./projectService";
export { projectRepository as defaultProjectRepository } from "./mockProjectService";

export { repositoryService, MockRepositoryService, type RepositoryService, RepositoryError } from "./repositoryService";
export { repositoryService as defaultRepositoryService } from "./mockRepositoryService";

export { deploymentService, MockDeploymentService, type DeploymentService, DeploymentError } from "./deploymentService";
export { deploymentService as defaultDeploymentService } from "./mockDeploymentService";
