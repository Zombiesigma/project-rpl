import type { User } from "@/types/user";

export interface AuthSession {
  user: User;
  token: string;
  expiresAt: number;
}

export interface AuthService {
  signIn(email: string, password: string): Promise<AuthSession>;
  signInWithGoogle(): Promise<AuthSession>;
  signOut(): Promise<void>;
  getCurrentSession(): Promise<AuthSession | null>;
  listDemoUsers(): Promise<User[]>;
  signInAs(userId: string): Promise<AuthSession>;
}

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AuthError";
  }
}
