import type { ProjectFile } from "@/types/file";
import type {
  Commit,
  CreateFileInput,
  DeleteFileInput,
  RenameFileInput,
  Repository,
  UpdateFileInput,
} from "@/types/repository";

export interface RepositoryService {
  createRepository(input: {
    name: string;
    organization?: string;
    defaultBranch?: string;
  }): Promise<Repository>;
  getRepository(id: string): Promise<Repository>;
  getFiles(repositoryId: string): Promise<ProjectFile[]>;
  getFile(repositoryId: string, path: string): Promise<ProjectFile | null>;
  updateFile(input: UpdateFileInput): Promise<Commit>;
  createFile(input: CreateFileInput): Promise<Commit>;
  deleteFile(input: DeleteFileInput): Promise<Commit>;
  renameFile(input: RenameFileInput): Promise<Commit>;
  getCommits(repositoryId: string): Promise<Commit[]>;
}

export class RepositoryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "RepositoryError";
  }
}
