import type { DeploymentService } from "./deploymentService";
import type { Deployment, DeploymentLog } from "@/types/deployment";
import { projectRepository, logActivity } from "./mockProjectService";
import { repositoryService } from "./mockRepositoryService";

function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

function makeLog(message: string, level: DeploymentLog["level"] = "info"): DeploymentLog {
  return {
    id: generateId("log"),
    message,
    level,
    timestamp: new Date().toISOString(),
  };
}

const BUILD_LOG_STEPS: DeploymentLog["message"][] = [
  "Cloning repository...",
  "Installing dependencies...",
  "Running build...",
  "Compiling application...",
  "Generating pages...",
  "Optimizing assets...",
  "Uploading to edge network...",
  "Deployment completed.",
];

/**
 * MockDeploymentService simulates the Vercel-like deployment flow.
 * The flow advances automatically: queued → building → deploying → ready.
 * Listeners can poll getDeployment to observe state changes.
 */
export class MockDeploymentService implements DeploymentService {
  async createDeployment(projectId: string, commitId?: string): Promise<Deployment> {
    const project = await projectRepository.getById(projectId);
    if (!project) throw new Error("Project not found");

    const deployment: Deployment = {
      id: generateId("dep"),
      projectId,
      status: "queued",
      url: `https://${project.slug}.rplforge.local`,
      version: project.versions.length
        ? `v1.${project.versions.length}.0`
        : "v1.0.0",
      logs: [makeLog("Deployment queued.")],
      commitId,
      startedAt: new Date().toISOString(),
    };

    await projectRepository.update(projectId, {
      deployment,
      status: "deploying",
    });

    // Kick off the simulated flow in the background
    this.runFlow(deployment.id, projectId).catch((err) =>
      console.error("[MockDeploymentService] flow failed", err)
    );

    return deployment;
  }

  private async runFlow(deploymentId: string, projectId: string): Promise<void> {
    const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

    // QUEUED → BUILDING
    await wait(800);
    await this.transition(projectId, deploymentId, "building", [
      makeLog("Build started."),
    ]);

    // BUILDING — emit build logs over ~2.5s
    for (const step of BUILD_LOG_STEPS.slice(0, 4)) {
      await wait(550);
      await this.transition(projectId, deploymentId, "building", [makeLog(step)]);
    }

    // BUILDING → DEPLOYING
    await wait(400);
    await this.transition(projectId, deploymentId, "deploying", [
      makeLog("Publishing to edge network..."),
    ]);

    // DEPLOYING — emit publish logs
    for (const step of BUILD_LOG_STEPS.slice(4)) {
      await wait(450);
      await this.transition(projectId, deploymentId, "deploying", [makeLog(step)]);
    }

    // DEPLOYING → READY
    await wait(400);
    const project = await projectRepository.getById(projectId);
    if (!project?.deployment) return;
    const finalDeployment: Deployment = {
      ...project.deployment,
      status: "ready",
      finishedAt: new Date().toISOString(),
      logs: [
        ...project.deployment.logs,
        makeLog("Deployment ready.", "success"),
      ],
    };
    await projectRepository.update(projectId, {
      deployment: finalDeployment,
      status: "live",
    });
    logActivity({
      type: "deploy",
      userId: project.ownerId,
      projectId,
      message: `${project.name} deployment is live`,
    });
  }

  private async transition(
    projectId: string,
    deploymentId: string,
    status: Deployment["status"],
    newLogs: DeploymentLog[]
  ): Promise<void> {
    const project = await projectRepository.getById(projectId);
    if (!project?.deployment || project.deployment.id !== deploymentId) return;
    const updated: Deployment = {
      ...project.deployment,
      status,
      logs: [...project.deployment.logs, ...newLogs],
    };
    await projectRepository.update(projectId, { deployment: updated });
  }

  async getDeployment(id: string): Promise<Deployment | null> {
    const all = await projectRepository.listAll();
    return all.find((p) => p.deployment?.id === id)?.deployment ?? null;
  }

  async cancelDeployment(id: string): Promise<void> {
    const all = await projectRepository.listAll();
    const project = all.find((p) => p.deployment?.id === id);
    if (!project?.deployment) return;
    const canceled: Deployment = {
      ...project.deployment,
      status: "canceled",
      finishedAt: new Date().toISOString(),
      logs: [...project.deployment.logs, makeLog("Deployment canceled by user.", "warn")],
    };
    await projectRepository.update(project.id, { deployment: canceled });
  }

  async getDeploymentLogs(id: string): Promise<Deployment["logs"]> {
    const dep = await this.getDeployment(id);
    return dep?.logs ?? [];
  }

  async redeploy(projectId: string): Promise<Deployment> {
    return this.createDeployment(projectId);
  }
}

export const deploymentService: DeploymentService = new MockDeploymentService();
