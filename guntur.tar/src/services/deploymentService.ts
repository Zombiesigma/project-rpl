import type { Deployment } from "@/types/deployment";

export interface DeploymentService {
  createDeployment(projectId: string, commitId?: string): Promise<Deployment>;
  getDeployment(id: string): Promise<Deployment | null>;
  cancelDeployment(id: string): Promise<void>;
  getDeploymentLogs(id: string): Promise<Deployment["logs"]>;
  redeploy(projectId: string): Promise<Deployment>;
}

export class DeploymentError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "DeploymentError";
  }
}
