import type { Project } from "@/types/project";
import type { ProjectFile } from "@/types/file";

export interface ProjectRepository {
  create(project: Project): Promise<Project>;
  getById(id: string): Promise<Project | null>;
  listByUser(userId: string): Promise<Project[]>;
  listAll(): Promise<Project[]>;
  listPublic(): Promise<Project[]>;
  update(id: string, data: Partial<Project>): Promise<Project>;
  remove(id: string): Promise<void>;
  setFiles(id: string, files: ProjectFile[]): Promise<void>;
}

export class ProjectRepositoryError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ProjectRepositoryError";
  }
}
