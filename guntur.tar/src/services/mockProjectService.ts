import type {
  ProjectRepository,
} from "./projectService";
import type { Project } from "@/types/project";
import type { ProjectFile } from "@/types/file";
import { storage, STORAGE_KEYS } from "@/lib/storage";
import { buildSeedProjects, buildSeedActivity, type ActivityEntry } from "@/mock/seed";

function ensureSeeded(): void {
  if (!storage.has(STORAGE_KEYS.seeded)) {
    storage.set(STORAGE_KEYS.projects, buildSeedProjects());
    storage.set(STORAGE_KEYS.activity, buildSeedActivity());
    storage.set(STORAGE_KEYS.seeded, true);
  }
}

function readAll(): Project[] {
  ensureSeeded();
  return storage.get<Project[]>(STORAGE_KEYS.projects, []);
}

function writeAll(projects: Project[]): void {
  storage.set(STORAGE_KEYS.projects, projects);
}

export class LocalProjectRepository implements ProjectRepository {
  async create(project: Project): Promise<Project> {
    await new Promise((r) => setTimeout(r, 100));
    const projects = readAll();
    projects.push(project);
    writeAll(projects);
    return project;
  }

  async getById(id: string): Promise<Project | null> {
    const projects = readAll();
    return projects.find((p) => p.id === id) ?? null;
  }

  async listByUser(userId: string): Promise<Project[]> {
    const projects = readAll();
    return projects
      .filter(
        (p) =>
          p.ownerId === userId ||
          p.members.some((m) => m.userId === userId)
      )
      .sort((a, b) => (b.updatedAt > a.updatedAt ? 1 : -1));
  }

  async listAll(): Promise<Project[]> {
    return readAll().sort((a, b) =>
      b.updatedAt > a.updatedAt ? 1 : -1
    );
  }

  async listPublic(): Promise<Project[]> {
    return readAll()
      .filter((p) => p.visibility === "public")
      .sort((a, b) => (b.updatedAt > a.updatedAt ? 1 : -1));
  }

  async update(id: string, data: Partial<Project>): Promise<Project> {
    const projects = readAll();
    const idx = projects.findIndex((p) => p.id === id);
    if (idx === -1) throw new Error(`Project ${id} not found`);
    projects[idx] = {
      ...projects[idx],
      ...data,
      updatedAt: new Date().toISOString(),
    };
    writeAll(projects);
    return projects[idx];
  }

  async remove(id: string): Promise<void> {
    const projects = readAll().filter((p) => p.id !== id);
    writeAll(projects);
  }

  async setFiles(id: string, files: ProjectFile[]): Promise<void> {
    const projects = readAll();
    const idx = projects.findIndex((p) => p.id === id);
    if (idx === -1) throw new Error(`Project ${id} not found`);
    projects[idx].files = files;
    projects[idx].updatedAt = new Date().toISOString();
    writeAll(projects);
  }
}

export const projectRepository: ProjectRepository =
  new LocalProjectRepository();

export function logActivity(entry: Omit<ActivityEntry, "id" | "timestamp">): void {
  const activities = storage.get<ActivityEntry[]>(STORAGE_KEYS.activity, []);
  activities.unshift({
    ...entry,
    id: `act_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    timestamp: new Date().toISOString(),
  });
  // keep only the latest 50
  storage.set(STORAGE_KEYS.activity, activities.slice(0, 50));
}

export function readActivity(): ActivityEntry[] {
  ensureSeeded();
  return storage.get<ActivityEntry[]>(STORAGE_KEYS.activity, []);
}
