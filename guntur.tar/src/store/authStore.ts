"use client";

import { create } from "zustand";
import type { AuthSession } from "@/services/authService";
import { authService } from "@/services/mockAuthService";

interface AuthState {
  session: AuthSession | null;
  loading: boolean;
  initialized: boolean;
  error: string | null;
  init: () => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  signInAs: (userId: string) => Promise<void>;
  signOut: () => Promise<void>;
  clearError: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  session: null,
  loading: false,
  initialized: false,
  error: null,

  init: async () => {
    const session = await authService.getCurrentSession();
    set({ session, initialized: true });
  },

  signIn: async (email, password) => {
    set({ loading: true, error: null });
    try {
      const session = await authService.signIn(email, password);
      set({ session, loading: false });
    } catch (err) {
      set({
        loading: false,
        error: err instanceof Error ? err.message : "Sign in failed",
      });
      throw err;
    }
  },

  signInWithGoogle: async () => {
    set({ loading: true, error: null });
    try {
      const session = await authService.signInWithGoogle();
      set({ session, loading: false });
    } catch (err) {
      set({
        loading: false,
        error: err instanceof Error ? err.message : "Google sign in failed",
      });
      throw err;
    }
  },

  signInAs: async (userId) => {
    set({ loading: true, error: null });
    try {
      const session = await authService.signInAs(userId);
      set({ session, loading: false });
    } catch (err) {
      set({
        loading: false,
        error: err instanceof Error ? err.message : "Demo sign in failed",
      });
      throw err;
    }
  },

  signOut: async () => {
    await authService.signOut();
    set({ session: null });
  },

  clearError: () => set({ error: null }),
}));
