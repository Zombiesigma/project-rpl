"use client";

import { create } from "zustand";

export type RouteName =
  | "landing"
  | "login"
  | "dashboard"
  | "projects_new"
  | "project_detail"
  | "project_settings"
  | "workspace"
  | "explore"
  | "profile"
  | "admin"
  | "settings";

export interface RouteParams {
  projectId?: string;
  userId?: string;
  /** Optional path of file to open in workspace */
  filePath?: string;
}

interface RouterState {
  route: RouteName;
  params: RouteParams;
  /** Monotonic counter that increments on each navigation — useful for re-mounting. */
  navKey: number;
  push: (route: RouteName, params?: RouteParams) => void;
  replace: (route: RouteName, params?: RouteParams) => void;
  back: () => void;
  /** History stack for back navigation. */
  history: { route: RouteName; params: RouteParams }[];
}

export const useRouterStore = create<RouterState>((set, get) => ({
  route: "landing",
  params: {},
  navKey: 0,
  history: [],

  push: (route, params = {}) => {
    const current = { route: get().route, params: get().params };
    if (current.route === route && JSON.stringify(current.params) === JSON.stringify(params)) return;
    set((state) => ({
      history: [...state.history, current].slice(-30),
      route,
      params,
      navKey: state.navKey + 1,
    }));
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "auto" });
    }
  },

  replace: (route, params = {}) => {
    set((state) => ({
      route,
      params,
      navKey: state.navKey + 1,
    }));
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "auto" });
    }
  },

  back: () => {
    const history = get().history;
    if (history.length === 0) {
      set({ route: "dashboard", params: {}, navKey: get().navKey + 1 });
      return;
    }
    const prev = history[history.length - 1];
    set((state) => ({
      route: prev.route,
      params: prev.params,
      history: state.history.slice(0, -1),
      navKey: state.navKey + 1,
    }));
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "auto" });
    }
  },
}));
