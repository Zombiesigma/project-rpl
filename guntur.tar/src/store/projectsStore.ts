"use client";

import { create } from "zustand";
import type { Project, ProjectStatus } from "@/types/project";
import type { ProjectFile } from "@/types/file";
import type { Commit, Repository } from "@/types/repository";
import type { Deployment } from "@/types/deployment";
import {
  projectRepository,
  logActivity,
  readActivity,
} from "@/services/mockProjectService";
import { repositoryService } from "@/services/mockRepositoryService";
import { deploymentService } from "@/services/mockDeploymentService";
import type { ActivityEntry } from "@/mock/seed";

interface ProjectsState {
  projects: Project[];
  activity: ActivityEntry[];
  loading: boolean;
  error: string | null;

  loadForUser: (userId: string) => Promise<void>;
  loadAll: () => Promise<void>;
  loadPublic: () => Promise<void>;
  refresh: () => Promise<void>;
  getProject: (id: string) => Project | undefined;
  createProject: (input: {
    name: string;
    description: string;
    category: string;
    technologies: string[];
    visibility: "public" | "private";
    ownerId: string;
    files: ProjectFile[];
    coverImage?: string;
  }) => Promise<Project>;
  updateProject: (id: string, data: Partial<Project>) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  saveFile: (
    projectId: string,
    path: string,
    content: string,
    message: string,
    authorId: string
  ) => Promise<Commit>;
  createFile: (
    projectId: string,
    path: string,
    type: "file" | "folder",
    content: string,
    authorId: string
  ) => Promise<Commit>;
  deleteFile: (projectId: string, path: string, authorId: string) => Promise<Commit>;
  renameFile: (
    projectId: string,
    oldPath: string,
    newPath: string,
    authorId: string
  ) => Promise<Commit>;
  deployProject: (projectId: string, commitId?: string) => Promise<Deployment>;
}

function generateProjectId(): string {
  return `proj_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export const useProjectsStore = create<ProjectsState>((set, get) => ({
  projects: [],
  activity: [],
  loading: false,
  error: null,

  loadForUser: async (userId) => {
    set({ loading: true, error: null });
    try {
      const [projects, activity] = await Promise.all([
        projectRepository.listByUser(userId),
        Promise.resolve(readActivity()),
      ]);
      set({ projects, activity, loading: false });
    } catch (err) {
      set({
        loading: false,
        error: err instanceof Error ? err.message : "Failed to load projects",
      });
    }
  },

  loadAll: async () => {
    set({ loading: true, error: null });
    try {
      const [projects, activity] = await Promise.all([
        projectRepository.listAll(),
        Promise.resolve(readActivity()),
      ]);
      set({ projects, activity, loading: false });
    } catch (err) {
      set({
        loading: false,
        error: err instanceof Error ? err.message : "Failed to load projects",
      });
    }
  },

  loadPublic: async () => {
    set({ loading: true, error: null });
    try {
      const projects = await projectRepository.listPublic();
      set({ projects, loading: false });
    } catch (err) {
      set({
        loading: false,
        error: err instanceof Error ? err.message : "Failed to load projects",
      });
    }
  },

  refresh: async () => {
    const current = get().projects;
    if (current.length === 0) return;
    // Refresh all projects so workspace updates are reflected everywhere
    const all = await projectRepository.listAll();
    set({ projects: all });
  },

  getProject: (id) => get().projects.find((p) => p.id === id),

  createProject: async (input) => {
    const id = generateProjectId();
    const slug = slugify(input.name);
    const now = new Date().toISOString();

    const initialCommit: Commit = {
      id: `commit_${id}_initial`,
      projectId: id,
      message: "Initial upload",
      authorId: input.ownerId,
      changedFiles: ["(all files)"],
      createdAt: now,
    };

    const project: Project = {
      id,
      name: input.name,
      slug,
      description: input.description,
      ownerId: input.ownerId,
      category: input.category,
      technologies: input.technologies,
      visibility: input.visibility,
      status: "draft" as ProjectStatus,
      repository: undefined,
      deployment: undefined,
      files: input.files,
      versions: [
        {
          id: `ver_${initialCommit.id}`,
          tag: "v1.0.0",
          label: "Initial upload",
          authorId: input.ownerId,
          commitId: initialCommit.id,
          createdAt: now,
        },
      ],
      commits: [initialCommit],
      members: [
        { userId: input.ownerId, role: "owner", addedAt: now },
      ],
      screenshots: [],
      coverImage: input.coverImage,
      createdAt: now,
      updatedAt: now,
    };

    await projectRepository.create(project);
    logActivity({
      type: "create",
      userId: input.ownerId,
      projectId: id,
      message: `Created ${input.name}`,
    });

    set((state) => ({
      projects: [project, ...state.projects.filter((p) => p.id !== id)],
      activity: readActivity(),
    }));

    return project;
  },

  updateProject: async (id, data) => {
    const updated = await projectRepository.update(id, data);
    set((state) => ({
      projects: state.projects.map((p) => (p.id === id ? updated : p)),
    }));
  },

  deleteProject: async (id) => {
    await projectRepository.remove(id);
    set((state) => ({
      projects: state.projects.filter((p) => p.id !== id),
    }));
  },

  saveFile: async (projectId, path, content, message, authorId) => {
    const project = get().getProject(projectId);
    if (!project?.repository) throw new Error("Project has no repository");
    const commit = await repositoryService.updateFile({
      repositoryId: project.repository.id,
      path,
      content,
      message,
      authorId,
    });
    await get().refresh();
    return commit;
  },

  createFile: async (projectId, path, type, content, authorId) => {
    const project = get().getProject(projectId);
    if (!project?.repository) throw new Error("Project has no repository");
    const commit = await repositoryService.createFile({
      repositoryId: project.repository.id,
      path,
      type,
      content,
      authorId,
    });
    await get().refresh();
    return commit;
  },

  deleteFile: async (projectId, path, authorId) => {
    const project = get().getProject(projectId);
    if (!project?.repository) throw new Error("Project has no repository");
    const commit = await repositoryService.deleteFile({
      repositoryId: project.repository.id,
      path,
      authorId,
    });
    await get().refresh();
    return commit;
  },

  renameFile: async (projectId, oldPath, newPath, authorId) => {
    const project = get().getProject(projectId);
    if (!project?.repository) throw new Error("Project has no repository");
    const commit = await repositoryService.renameFile({
      repositoryId: project.repository.id,
      oldPath,
      newPath,
      authorId,
    });
    await get().refresh();
    return commit;
  },

  deployProject: async (projectId, commitId) => {
    const project = get().getProject(projectId);
    if (!project) throw new Error("Project not found");
    const deployment = await deploymentService.createDeployment(projectId, commitId);
    await get().refresh();
    return deployment;
  },
}));

/** Helper: attach a freshly-created repository to a project. */
export async function attachRepository(
  projectId: string,
  slug: string
): Promise<Repository> {
  const repo = await repositoryService.createRepository({
    name: `rplforge-${slug}`,
    organization: "rpl-forge",
  });
  await projectRepository.update(projectId, { repository: repo });
  await useProjectsStore.getState().refresh();
  return repo;
}
