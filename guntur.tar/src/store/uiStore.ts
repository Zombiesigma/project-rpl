"use client";

import { create } from "zustand";

export interface Toast {
  id: string;
  title: string;
  description?: string;
  variant?: "default" | "success" | "error" | "warning";
}

interface UIState {
  toasts: Toast[];
  theme: "light" | "dark";
  pushToast: (toast: Omit<Toast, "id">) => void;
  dismissToast: (id: string) => void;
  toggleTheme: () => void;
  setTheme: (theme: "light" | "dark") => void;
}

function generateToastId(): string {
  return `toast_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

export const useUIStore = create<UIState>((set, get) => ({
  toasts: [],
  theme: "light",

  pushToast: (toast) => {
    const id = generateToastId();
    set((state) => ({
      toasts: [...state.toasts, { ...toast, id }],
    }));
    // Auto-dismiss after 4 seconds
    setTimeout(() => {
      get().dismissToast(id);
    }, 4000);
  },

  dismissToast: (id) => {
    set((state) => ({
      toasts: state.toasts.filter((t) => t.id !== id),
    }));
  },

  toggleTheme: () => {
    set((state) => {
      const next = state.theme === "light" ? "dark" : "light";
      if (typeof document !== "undefined") {
        document.documentElement.classList.toggle("dark", next === "dark");
      }
      return { theme: next };
    });
  },

  setTheme: (theme) => {
    set({ theme });
    if (typeof document !== "undefined") {
      document.documentElement.classList.toggle("dark", theme === "dark");
    }
  },
}));

/** Convenience helper. */
export const toast = {
  success: (title: string, description?: string) =>
    useUIStore.getState().pushToast({ title, description, variant: "success" }),
  error: (title: string, description?: string) =>
    useUIStore.getState().pushToast({ title, description, variant: "error" }),
  warning: (title: string, description?: string) =>
    useUIStore.getState().pushToast({ title, description, variant: "warning" }),
  info: (title: string, description?: string) =>
    useUIStore.getState().pushToast({ title, description, variant: "default" }),
};
