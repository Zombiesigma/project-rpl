export type DeploymentStatus =
  | "queued"
  | "building"
  | "deploying"
  | "ready"
  | "failed"
  | "canceled";

export interface Deployment {
  id: string;
  projectId: string;
  status: DeploymentStatus;
  url: string;
  version: string;
  logs: DeploymentLog[];
  commitId?: string;
  startedAt: string;
  finishedAt?: string;
  error?: string;
}

export interface DeploymentLog {
  id: string;
  message: string;
  level: "info" | "warn" | "error" | "success";
  timestamp: string;
}

export const DEPLOYMENT_STATUS_META: Record<
  DeploymentStatus,
  { label: string; dot: string; badge: string; description: string }
> = {
  queued: {
    label: "Queued",
    dot: "bg-amber-400",
    badge: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30",
    description: "Deployment is waiting to start.",
  },
  building: {
    label: "Building",
    dot: "bg-sky-400 animate-pulse",
    badge: "bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30",
    description: "Compiling the project.",
  },
  deploying: {
    label: "Deploying",
    dot: "bg-sky-500 animate-pulse",
    badge: "bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30",
    description: "Publishing to the edge network.",
  },
  ready: {
    label: "Live",
    dot: "bg-emerald-500",
    badge:
      "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
    description: "Project is live.",
  },
  failed: {
    label: "Failed",
    dot: "bg-rose-500",
    badge: "bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30",
    description: "Deployment failed.",
  },
  canceled: {
    label: "Canceled",
    dot: "bg-zinc-400",
    badge:
      "bg-zinc-500/10 text-zinc-600 dark:text-zinc-400 border-zinc-500/30",
    description: "Deployment was canceled.",
  },
};
