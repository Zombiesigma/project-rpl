import type { Repository, Commit, Version } from "./repository";
import type { Deployment } from "./deployment";
import type { ProjectFile } from "./file";
import type { ProjectMember } from "./user";

export type ProjectStatus =
  | "draft"
  | "uploading"
  | "validating"
  | "creating_repository"
  | "deploying"
  | "live"
  | "failed"
  | "suspended"
  | "archived";

export type ProjectVisibility = "public" | "private";

export interface Project {
  id: string;
  name: string;
  slug: string;
  description: string;
  ownerId: string;
  category: string;
  technologies: string[];
  visibility: ProjectVisibility;
  status: ProjectStatus;
  repository?: Repository;
  deployment?: Deployment;
  files: ProjectFile[];
  versions: Version[];
  commits: Commit[];
  members: ProjectMember[];
  screenshots?: string[];
  /** Optional cover image as a base64 data URL. */
  coverImage?: string;
  createdAt: string;
  updatedAt: string;
}

export const PROJECT_STATUS_META: Record<
  ProjectStatus,
  { label: string; dot: string; badge: string; description: string }
> = {
  draft: {
    label: "Draft",
    dot: "bg-zinc-400",
    badge: "bg-zinc-500/10 text-zinc-600 dark:text-zinc-300 border-zinc-500/30",
    description: "Project is being prepared.",
  },
  uploading: {
    label: "Uploading",
    dot: "bg-sky-400 animate-pulse",
    badge: "bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30",
    description: "Files are being uploaded.",
  },
  validating: {
    label: "Validating",
    dot: "bg-amber-400 animate-pulse",
    badge: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30",
    description: "Validating project structure.",
  },
  creating_repository: {
    label: "Creating Repo",
    dot: "bg-violet-400 animate-pulse",
    badge: "bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/30",
    description: "Creating mock repository.",
  },
  deploying: {
    label: "Deploying",
    dot: "bg-sky-500 animate-pulse",
    badge: "bg-sky-500/10 text-sky-600 dark:text-sky-400 border-sky-500/30",
    description: "Deployment in progress.",
  },
  live: {
    label: "Live",
    dot: "bg-emerald-500",
    badge:
      "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
    description: "Project is live.",
  },
  failed: {
    label: "Failed",
    dot: "bg-rose-500",
    badge: "bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/30",
    description: "Deployment failed.",
  },
  suspended: {
    label: "Suspended",
    dot: "bg-zinc-500",
    badge: "bg-zinc-500/10 text-zinc-600 dark:text-zinc-300 border-zinc-500/30",
    description: "Project has been suspended.",
  },
  archived: {
    label: "Archived",
    dot: "bg-zinc-500",
    badge: "bg-zinc-500/10 text-zinc-600 dark:text-zinc-300 border-zinc-500/30",
    description: "Project is archived.",
  },
};

export const PROJECT_CATEGORIES = [
  "Web Application",
  "Mobile App",
  "IoT System",
  "AI / Machine Learning",
  "Game",
  "Desktop App",
  "CLI Tool",
  "Other",
] as const;

export const PROJECT_TECHNOLOGY_SUGGESTIONS = [
  "Next.js",
  "React",
  "TypeScript",
  "JavaScript",
  "Tailwind CSS",
  "Firebase",
  "Node.js",
  "Express",
  "PostgreSQL",
  "MongoDB",
  "ESP32",
  "Arduino",
  "Python",
  "FastAPI",
  "Flutter",
  "Kotlin",
  "Swift",
  "Vue",
  "Svelte",
  "Three.js",
];
