export interface Repository {
  id: string;
  name: string;
  organization: string;
  url: string;
  defaultBranch: string;
  createdAt: string;
}

export interface Commit {
  id: string;
  projectId: string;
  message: string;
  authorId: string;
  changedFiles: string[];
  createdAt: string;
}

export interface Version {
  id: string;
  tag: string;
  label: string;
  authorId: string;
  commitId: string;
  createdAt: string;
}

export interface CreateRepositoryInput {
  name: string;
  organization?: string;
  defaultBranch?: string;
}

export interface UpdateFileInput {
  repositoryId: string;
  path: string;
  content: string;
  message?: string;
  authorId: string;
}

export interface CreateFileInput {
  repositoryId: string;
  path: string;
  content?: string;
  type: "file" | "folder";
  authorId: string;
}

export interface DeleteFileInput {
  repositoryId: string;
  path: string;
  authorId: string;
}

export interface RenameFileInput {
  repositoryId: string;
  oldPath: string;
  newPath: string;
  authorId: string;
}
