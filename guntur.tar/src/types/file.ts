export type FileType = "file" | "folder";

export interface ProjectFile {
  id: string;
  projectId: string;
  path: string;
  name: string;
  type: FileType;
  language?: string;
  content?: string;
  size?: number;
  children?: ProjectFile[];
}

export const LANGUAGE_BY_EXTENSION: Record<string, string> = {
  ts: "typescript",
  tsx: "typescript",
  js: "javascript",
  jsx: "javascript",
  mjs: "javascript",
  cjs: "javascript",
  json: "json",
  css: "css",
  scss: "scss",
  html: "html",
  md: "markdown",
  mdx: "markdown",
  yaml: "yaml",
  yml: "yaml",
  txt: "plaintext",
  svg: "xml",
  xml: "xml",
  py: "python",
  go: "go",
  rs: "rust",
  sh: "shell",
  env: "plaintext",
  gitignore: "plaintext",
};

export function detectLanguage(filename: string): string {
  const lower = filename.toLowerCase();
  if (lower === "package.json") return "json";
  if (lower === "tsconfig.json") return "json";
  if (lower.startsWith(".")) {
    const ext = lower.slice(1).split(".").pop();
    if (ext && LANGUAGE_BY_EXTENSION[ext]) return LANGUAGE_BY_EXTENSION[ext];
    return "plaintext";
  }
  const ext = lower.split(".").pop();
  return (ext && LANGUAGE_BY_EXTENSION[ext]) || "plaintext";
}
