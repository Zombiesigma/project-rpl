export type UserRole = "student" | "mentor" | "admin";

export type ProjectRole = "owner" | "editor" | "viewer" | "admin" | "mentor";

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  avatar?: string;
  bio?: string;
  classLevel?: string;
  generation?: string;
  role: UserRole;
  skills?: string[];
  createdAt: string;
}

export interface ProjectMember {
  userId: string;
  role: ProjectRole;
  addedAt: string;
}
